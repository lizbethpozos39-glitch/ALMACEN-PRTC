<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();


/*
|--------------------------------------------------------------------------
| CONTROL DE ACCESO
|--------------------------------------------------------------------------
*/

$rol_usuario = strtoupper($_SESSION['rol'] ?? '');

$roles_permitidos = [
    'ADMIN',
    'GERENCIA',
    'CONSULTA'
];

if (!in_array($rol_usuario, $roles_permitidos, true)) {

    header("Location: index.php");
    exit;

}


/*
|--------------------------------------------------------------------------
| DATOS DEL USUARIO
|--------------------------------------------------------------------------
*/

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';


/*
|--------------------------------------------------------------------------
| FILTROS
|--------------------------------------------------------------------------
*/

$descripcion = $_GET["descripcion"] ?? "";
$cantidad    = $_GET["cantidad"] ?? "";
$ubicacion   = $_GET["ubicacion"] ?? "";
$maximo      = $_GET["maximo"] ?? "";
$minimo      = $_GET["minimo"] ?? "";
$proveedor   = $_GET["proveedor"] ?? "";


/*
|--------------------------------------------------------------------------
| CONSULTA DE INVENTARIO
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        ubicacion,
        maximo,
        minimo,
        proveedor_marca
    FROM inventario
    WHERE 1=1
";

$tipos = "";
$valores = [];


/*
|--------------------------------------------------------------------------
| FILTRO DESCRIPCIÓN
|--------------------------------------------------------------------------
*/

if ($descripcion !== "") {

    $sql .= " AND articulo_descripcion LIKE ?";
    $tipos .= "s";
    $valores[] = "%" . $descripcion . "%";

}


/*
|--------------------------------------------------------------------------
| FILTRO CANTIDAD
|--------------------------------------------------------------------------
*/

if ($cantidad !== "") {

    $sql .= " AND cantidad = ?";
    $tipos .= "i";
    $valores[] = (int)$cantidad;

}


/*
|--------------------------------------------------------------------------
| FILTRO UBICACIÓN
|--------------------------------------------------------------------------
*/

if ($ubicacion !== "") {

    $sql .= " AND ubicacion LIKE ?";
    $tipos .= "s";
    $valores[] = "%" . $ubicacion . "%";

}


/*
|--------------------------------------------------------------------------
| FILTRO MÁXIMO
|--------------------------------------------------------------------------
*/

if ($maximo !== "") {

    $sql .= " AND maximo = ?";
    $tipos .= "i";
    $valores[] = (int)$maximo;

}


/*
|--------------------------------------------------------------------------
| FILTRO MÍNIMO
|--------------------------------------------------------------------------
*/

if ($minimo !== "") {

    $sql .= " AND minimo = ?";
    $tipos .= "i";
    $valores[] = (int)$minimo;

}


/*
|--------------------------------------------------------------------------
| FILTRO PROVEEDOR / MARCA
|--------------------------------------------------------------------------
*/

if ($proveedor !== "") {

    $sql .= " AND proveedor_marca LIKE ?";
    $tipos .= "s";
    $valores[] = "%" . $proveedor . "%";

}


/*
|--------------------------------------------------------------------------
| ORDEN
|--------------------------------------------------------------------------
*/

$sql .= " ORDER BY id DESC";


/*
|--------------------------------------------------------------------------
| PREPARAR CONSULTA
|--------------------------------------------------------------------------
*/

$stmt = $conexion->prepare($sql);

if (!$stmt) {

    die(
        "Error al preparar la consulta: " .
        $conexion->error
    );

}


/*
|--------------------------------------------------------------------------
| ASIGNAR PARÁMETROS
|--------------------------------------------------------------------------
*/

if (!empty($valores)) {

    $stmt->bind_param(
        $tipos,
        ...$valores
    );

}


/*
|--------------------------------------------------------------------------
| EJECUTAR CONSULTA
|--------------------------------------------------------------------------
*/

if (!$stmt->execute()) {

    die(
        "Error al ejecutar la consulta: " .
        $stmt->error
    );

}

$resultado = $stmt->get_result();

$total_registros = $resultado->num_rows;

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Consulta de Inventario</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #212529;
        }

        .contenedor {
            margin-left: 240px;
            padding: 25px;
            min-height: 100vh;
        }

        .encabezado {
            background: white;
            padding: 20px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }

        .encabezado h1 {
            margin: 0 0 8px 0;
            font-size: 26px;
        }

        .encabezado p {
            margin: 0;
            color: #6c757d;
        }

        .filtros {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }

        .filtros h2 {
            margin-top: 0;
            font-size: 20px;
        }

        .formulario-filtros {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }

        .campo {
            display: flex;
            flex-direction: column;
        }

        .campo label {
            font-weight: bold;
            margin-bottom: 6px;
            font-size: 14px;
        }

        .campo input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            font-size: 14px;
        }

        .botones {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-top: 18px;
            flex-wrap: wrap;
        }

        .boton,
        .buscar {
            border: none;
            border-radius: 5px;
            padding: 11px 18px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
            display: inline-block;
        }

        .buscar {
            background: #0d6efd;
            color: white;
        }

        .buscar:hover {
            background: #0b5ed7;
        }

        .limpiar {
            background: #6c757d;
            color: white;
        }

        .limpiar:hover {
            background: #5c636a;
        }

        .exportar {
            background: #198754;
            color: white;
        }

        .exportar:hover {
            background: #157347;
        }

        .resumen {
            background: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
            font-weight: bold;
        }

        .tabla-contenedor {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 950px;
        }

        thead {
            background: #212529;
            color: white;
        }

        th,
        td {
            padding: 12px 10px;
            border-bottom: 1px solid #dee2e6;
            text-align: left;
            font-size: 14px;
        }

        th {
            white-space: nowrap;
        }

        tbody tr:hover {
            background: #f8f9fa;
        }

        .cantidad {
            font-weight: bold;
            text-align: center;
        }

        .sin-registros {
            text-align: center;
            padding: 30px;
            color: #6c757d;
        }

        .etiqueta-consulta {
            display: inline-block;
            background: #e9ecef;
            color: #495057;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            margin-top: 8px;
        }

        @media (max-width: 1000px) {

            .contenedor {
                margin-left: 0;
                padding: 15px;
            }

            .formulario-filtros {
                grid-template-columns: 1fr 1fr;
            }

        }

        @media (max-width: 600px) {

            .formulario-filtros {
                grid-template-columns: 1fr;
            }

            .encabezado h1 {
                font-size: 22px;
            }

        }

    </style>

</head>

<body>


<?php

/*
|--------------------------------------------------------------------------
| MENÚ
|--------------------------------------------------------------------------
|
| Se utiliza el menú general del sistema.
|
*/

require_once __DIR__ . '/menu.php';

?>


<div class="contenedor">


    <div class="encabezado">

        <h1>Consulta de Inventario</h1>

        <p>
            Bienvenido, <?= htmlspecialchars($nombre_empleado, ENT_QUOTES, 'UTF-8') ?>
        </p>

        <span class="etiqueta-consulta">
            Modo de solo lectura
        </span>

    </div>


    <div class="filtros">

        <h2>Filtros de búsqueda</h2>

        <form
            method="GET"
            action="inventario.php"
        >

            <div class="formulario-filtros">


                <div class="campo">

                    <label for="descripcion">
                        Descripción
                    </label>

                    <input
                        type="text"
                        id="descripcion"
                        name="descripcion"
                        value="<?= htmlspecialchars($descripcion, ENT_QUOTES, 'UTF-8') ?>"
                        placeholder="Buscar artículo"
                    >

                </div>


                <div class="campo">

                    <label for="cantidad">
                        Cantidad
                    </label>

                    <input
                        type="number"
                        id="cantidad"
                        name="cantidad"
                        value="<?= htmlspecialchars($cantidad, ENT_QUOTES, 'UTF-8') ?>"
                        placeholder="Cantidad exacta"
                    >

                </div>


                <div class="campo">

                    <label for="ubicacion">
                        Ubicación
                    </label>

                    <input
                        type="text"
                        id="ubicacion"
                        name="ubicacion"
                        value="<?= htmlspecialchars($ubicacion, ENT_QUOTES, 'UTF-8') ?>"
                        placeholder="Ubicación"
                    >

                </div>


                <div class="campo">

                    <label for="maximo">
                        Máximo
                    </label>

                    <input
                        type="number"
                        id="maximo"
                        name="maximo"
                        value="<?= htmlspecialchars($maximo, ENT_QUOTES, 'UTF-8') ?>"
                        placeholder="Máximo"
                    >

                </div>


                <div class="campo">

                    <label for="minimo">
                        Mínimo
                    </label>

                    <input
                        type="number"
                        id="minimo"
                        name="minimo"
                        value="<?= htmlspecialchars($minimo, ENT_QUOTES, 'UTF-8') ?>"
                        placeholder="Mínimo"
                    >

                </div>


                <div class="campo">

                    <label for="proveedor">
                        Proveedor / Marca
                    </label>

                    <input
                        type="text"
                        id="proveedor"
                        name="proveedor"
                        value="<?= htmlspecialchars($proveedor, ENT_QUOTES, 'UTF-8') ?>"
                        placeholder="Proveedor o marca"
                    >

                </div>


            </div>


            <div class="botones">


                <button
                    type="submit"
                    class="buscar"
                >
                    🔎 Buscar
                </button>


                <a
                    href="inventario.php"
                    class="boton limpiar"
                >
                    🔄 Limpiar
                </a>


                <button
                    type="submit"
                    formaction="exportar_excel.php"
                    formmethod="GET"
                    class="boton exportar"
                >
                    📤 Exportar Excel
                </button>


            </div>

        </form>

    </div>


    <div class="resumen">

        Registros encontrados:
        <?= (int)$total_registros ?>

    </div>


    <div class="tabla-contenedor">

        <table>

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Código</th>

                    <th>Descripción</th>

                    <th>Cantidad</th>

                    <th>Ubicación</th>

                    <th>Máximo</th>

                    <th>Mínimo</th>

                    <th>Proveedor / Marca</th>

                </tr>

            </thead>


            <tbody>

            <?php if ($total_registros > 0): ?>

                <?php while ($row = $resultado->fetch_assoc()): ?>

                    <tr>

                        <td>
                            <?= (int)$row['id'] ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['codigo'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['articulo_descripcion'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </td>

                        <td class="cantidad">
                            <?= (int)$row['cantidad'] ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['ubicacion'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </td>

                        <td class="cantidad">
                            <?= (int)$row['maximo'] ?>
                        </td>

                        <td class="cantidad">
                            <?= (int)$row['minimo'] ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['proveedor_marca'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td
                        colspan="8"
                        class="sin-registros"
                    >
                        No se encontraron registros.
                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>


</div>


</body>

</html>

<?php

$stmt->close();

$conexion->close();

?>