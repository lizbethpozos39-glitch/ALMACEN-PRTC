
<?php

// ==========================================
// CONFIGURACIÓN
// ==========================================

$archivoSalida = __DIR__ . '/reporte_ips.csv';

// Cambia esto por las IP que quieras consultar.
// En la práctica las puedes obtener directamente de MySQL.
$ips = [
    '8.8.8.8',
    '1.1.1.1',
    '187.123.45.67'
];


// ==========================================
// FUNCIÓN PARA CONSULTAR UNA IP
// ==========================================

function geolocalizarIP($ip)
{
    // No consultar IPs locales/privadas
    if (
        $ip === '127.0.0.1' ||
        $ip === '::1' ||
        filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        ) === false
    ) {
        return [
            'ip' => $ip,
            'ciudad' => 'IP privada/local',
            'region' => '',
            'pais' => '',
            'codigo_pais' => '',
            'codigo_postal' => '',
            'latitud' => '',
            'longitud' => '',
            'zona_horaria' => '',
            'asn' => '',
            'organizacion' => ''
        ];
    }

    $url = 'https://ipapi.co/' . rawurlencode($ip) . '/json/';

    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_USERAGENT => 'Sistema-Auditoria-IP/1.0'
    ]);

    $respuesta = curl_exec($ch);

    if ($respuesta === false) {
        curl_close($ch);

        return [
            'ip' => $ip,
            'ciudad' => 'ERROR',
            'region' => '',
            'pais' => '',
            'codigo_pais' => '',
            'codigo_postal' => '',
            'latitud' => '',
            'longitud' => '',
            'zona_horaria' => '',
            'asn' => '',
            'organizacion' => ''
        ];
    }

    curl_close($ch);

    $datos = json_decode($respuesta, true);

    if (!is_array($datos)) {
        return [
            'ip' => $ip,
            'ciudad' => 'RESPUESTA INVÁLIDA',
            'region' => '',
            'pais' => '',
            'codigo_pais' => '',
            'codigo_postal' => '',
            'latitud' => '',
            'longitud' => '',
            'zona_horaria' => '',
            'asn' => '',
            'organizacion' => ''
        ];
    }

    return [
        'ip' => $ip,
        'ciudad' => $datos['city'] ?? '',
        'region' => $datos['region'] ?? '',
        'pais' => $datos['country_name'] ?? '',
        'codigo_pais' => $datos['country_code'] ?? '',
        'codigo_postal' => $datos['postal'] ?? '',
        'latitud' => $datos['latitude'] ?? '',
        'longitud' => $datos['longitude'] ?? '',
        'zona_horaria' => $datos['timezone'] ?? '',
        'asn' => $datos['asn'] ?? '',
        'organizacion' => $datos['org'] ?? ''
    ];
}


// ==========================================
// GENERAR REPORTE
// ==========================================

$archivo = fopen($archivoSalida, 'w');

fputcsv($archivo, [
    'IP',
    'Ciudad',
    'Region',
    'Pais',
    'Codigo Pais',
    'Codigo Postal',
    'Latitud',
    'Longitud',
    'Zona Horaria',
    'ASN',
    'Organizacion'
]);

foreach ($ips as $ip) {

    echo "Consultando: $ip\n";

    $resultado = geolocalizarIP($ip);

    fputcsv($archivo, [
        $resultado['ip'],
        $resultado['ciudad'],
        $resultado['region'],
        $resultado['pais'],
        $resultado['codigo_pais'],
        $resultado['codigo_postal'],
        $resultado['latitud'],
        $resultado['longitud'],
        $resultado['zona_horaria'],
        $resultado['asn'],
        $resultado['organizacion']
    ]);

    // Evita hacer demasiadas peticiones seguidas
    sleep(1);
}

fclose($archivo);

echo "\nReporte generado en:\n";
echo $archivoSalida . "\n";
