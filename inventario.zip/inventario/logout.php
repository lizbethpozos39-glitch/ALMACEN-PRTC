<?php

session_start();

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/auditoria.php';


/*
|--------------------------------------------------------------------------
| Registrar cierre de sesión
|--------------------------------------------------------------------------
|
| IMPORTANTE:
| Esto debe hacerse ANTES de destruir la sesión,
| porque auditoria.php necesita los datos del usuario.
|
*/

if (isset($_SESSION['usuario_id'])) {

    registrar_auditoria(
        $conexion,
        'LOGOUT',
        'Sistema',
        'Cierre de sesión'
    );
}


/*
|--------------------------------------------------------------------------
| Limpiar sesión
|--------------------------------------------------------------------------
*/

$_SESSION = [];


/*
|--------------------------------------------------------------------------
| Eliminar cookie de sesión
|--------------------------------------------------------------------------
*/

if (ini_get("session.use_cookies")) {

    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}


/*
|--------------------------------------------------------------------------
| Destruir sesión
|--------------------------------------------------------------------------
*/

session_destroy();


/*
|--------------------------------------------------------------------------
| Regresar al login
|--------------------------------------------------------------------------
*/

header("Location: login.php");

exit;
