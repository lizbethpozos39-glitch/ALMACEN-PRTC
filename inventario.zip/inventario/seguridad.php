<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Verificar sesión
|--------------------------------------------------------------------------
*/

function verificar_sesion()
{
    if (
        !isset($_SESSION['usuario_id']) ||
        !isset($_SESSION['empleado_id'])
    ) {
        header("Location: login.php");
        exit;
    }
}


/*
|--------------------------------------------------------------------------
| Verificar administrador
|--------------------------------------------------------------------------
*/

function verificar_admin()
{
    verificar_sesion();

    if (
        !isset($_SESSION['rol']) ||
        $_SESSION['rol'] !== 'ADMIN'
    ) {
        http_response_code(403);

        die("
            <div style='
                font-family: Arial;
                text-align:center;
                margin-top:100px;
            '>
                <h1>⛔ Acceso denegado</h1>
                <p>No tienes permisos para acceder a esta sección.</p>
                <a href='index.php'>Regresar al sistema</a>
            </div>
        ");
    }
}


/*
|--------------------------------------------------------------------------
| Verificar acceso a Gerencia
|--------------------------------------------------------------------------
| Pueden acceder:
| - ADMIN
| - GERENCIA
|--------------------------------------------------------------------------
*/

function verificar_gerencia()
{
    verificar_sesion();

    if (
        !isset($_SESSION['rol']) ||
        (
            $_SESSION['rol'] !== 'ADMIN' &&
            $_SESSION['rol'] !== 'GERENCIA'
        )
    ) {
        http_response_code(403);

        die("
            <div style='
                font-family: Arial;
                text-align:center;
                margin-top:100px;
            '>
                <h1>⛔ Acceso denegado</h1>
                <p>No tienes permisos para acceder al Portal de Gerencia.</p>
                <a href='index.php'>Regresar al sistema</a>
            </div>
        ");
    }
}


/*
|--------------------------------------------------------------------------
| Información del usuario actual
|--------------------------------------------------------------------------
*/

function usuario_actual()
{
    return $_SESSION['nombre_usuario'] ?? '';
}

function empleado_actual()
{
    return $_SESSION['nombre_empleado'] ?? '';
}

function rol_actual()
{
    return $_SESSION['rol'] ?? '';
}