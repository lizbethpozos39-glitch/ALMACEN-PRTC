<?php

require "conexion.php";

$error = "";

/* =====================================================
   FUNCIONES AUXILIARES
===================================================== */

function limpiar($valor)
{
    return trim((string)$valor);
}


/* =====================================================
   GUARDAR ENTRADA
===================================================== */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $rfc_emisor = limpiar($_POST["rfc_emisor"] ?? "");

    $nombre_emisor = limpiar($_POST["nombre_emisor"] ?? "");

    $rfc_receptor = limpiar($_POST["rfc_receptor"] ?? "");

    $nombre_receptor = limpiar($_POST["nombre_receptor"] ?? "");

    $numero_factura = limpiar($_POST["numero_factura"] ?? "");

    $fecha_factura = $_POST["fecha_factura"] ?? null;

    $subtotal = floatval($_POST["subtotal"] ?? 0);

    $iva = floatval($_POST["iva"] ?? 0);

    $total = floatval($_POST["total"] ?? 0);

    $moneda_factura = strtoupper(
        limpiar($_POST["moneda_factura"] ?? "MXN")
    );

    $productos = $_POST["producto"] ?? [];


    /* =================================================
       VALIDACIONES GENERALES
    ================================================= */

    if ($rfc_emisor === "") {

        $error = "Debes ingresar el RFC del emisor.";

    } elseif ($nombre_emisor === "") {

        $error = "Debes ingresar el nombre del proveedor.";

    } elseif ($numero_factura === "") {

        $error = "Debes ingresar el número de factura.";

    } elseif (empty($productos)) {

        $error = "Debes agregar al menos un producto.";

    } else {

        try {

            /* =============================================
               VALIDAR MONEDA
            ============================================= */

            if (
                $moneda_factura !== "MXN" &&
                $moneda_factura !== "USD"
            ) {

                $moneda_factura = "MXN";
            }


            /* =============================================
               RECALCULAR IMPORTES EN PHP
               PARA MAYOR SEGURIDAD
            ============================================= */

            $subtotal_calculado = 0;


            foreach ($productos as $producto) {

                $codigo_tmp = limpiar(
                    $producto["codigo"] ?? ""
                );

                $descripcion_tmp = limpiar(
                    $producto["descripcion"] ?? ""
                );

                if (
                    $codigo_tmp === "" &&
                    $descripcion_tmp === ""
                ) {
                    continue;
                }


                $cantidad_tmp = floatval(
                    $producto["cantidad"] ?? 0
                );

                $valor_tmp = floatval(
                    $producto["valor"] ?? 0
                );


                $importe_tmp = round(
                    $cantidad_tmp * $valor_tmp,
                    2
                );


                $subtotal_calculado += $importe_tmp;
            }


            $subtotal_calculado =
                round($subtotal_calculado, 2);


            /* =============================================
               IVA MANUAL
            ============================================= */

            $iva = max(0, $iva);


            /* =============================================
               TOTAL
            ============================================= */

            $total_calculado =
                round(
                    $subtotal_calculado + $iva,
                    2
                );


            /* =============================================
               USAR LOS VALORES CALCULADOS
            ============================================= */

            $subtotal = $subtotal_calculado;

            $total = $total_calculado;


            /* =============================================
               INICIAR TRANSACCIÓN
            ============================================= */

            $conexion->begin_transaction();


            /* =============================================
               GUARDAR FACTURA
            ============================================= */

            $sqlFactura = "
                INSERT INTO facturas
                (
                    rfc_emisor,
                    nombre_emisor,
                    rfc_receptor,
                    nombre_receptor,
                    numero_factura,
                    fecha_factura,
                    subtotal,
                    iva,
                    total,
                    moneda
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ";


            $stmtFactura =
                $conexion->prepare($sqlFactura);


            if (!$stmtFactura) {

                throw new Exception(
                    "Error preparando factura: "
                    . $conexion->error
                );
            }


            $stmtFactura->bind_param(
                "ssssssddds",
                $rfc_emisor,
                $nombre_emisor,
                $rfc_receptor,
                $nombre_receptor,
                $numero_factura,
                $fecha_factura,
                $subtotal,
                $iva,
                $total,
                $moneda_factura
            );


            if (!$stmtFactura->execute()) {

                $errorSql =
                    $stmtFactura->error;

                $stmtFactura->close();

                throw new Exception(
                    "Error guardando factura: "
                    . $errorSql
                );
            }


            $factura_id =
                $conexion->insert_id;


            $stmtFactura->close();


            /* =============================================
               PREPARAR DETALLE FACTURA
            ============================================= */

            $sqlDetalle = "
                INSERT INTO factura_detalles
                (
                    factura_id,
                    clave_producto,
                    descripcion,
                    unidad,
                    cantidad,
                    valor_unitario,
                    moneda,
                    importe,
                    inventario_id
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ";


            $stmtDetalle =
                $conexion->prepare($sqlDetalle);


            if (!$stmtDetalle) {

                throw new Exception(
                    "Error preparando detalle: "
                    . $conexion->error
                );
            }


            /* =============================================
               PREPARAR MOVIMIENTO
            ============================================= */

            $sqlMovimiento = "
                INSERT INTO movimientos_inventario
                (
                    inventario_id,
                    tipo,
                    cantidad,
                    cantidad_anterior,
                    cantidad_nueva,
                    factura_id,
                    observaciones
                )
                VALUES (?, 'ENTRADA', ?, ?, ?, ?, ?)
            ";


            $stmtMovimiento =
                $conexion->prepare($sqlMovimiento);


            if (!$stmtMovimiento) {

                $stmtDetalle->close();

                throw new Exception(
                    "Error preparando movimiento: "
                    . $conexion->error
                );
            }


            $productosProcesados = 0;


            /* =============================================
               PROCESAR PRODUCTOS
            ============================================= */

            foreach ($productos as $producto) {

                $codigo = limpiar(
                    $producto["codigo"] ?? ""
                );

                $descripcion = limpiar(
                    $producto["descripcion"] ?? ""
                );

                $unidad = limpiar(
                    $producto["unidad"] ?? ""
                );

                $cantidad = floatval(
                    $producto["cantidad"] ?? 0
                );

                $valor = floatval(
                    $producto["valor"] ?? 0
                );

                $moneda = strtoupper(
                    limpiar(
                        $producto["moneda"]
                        ?? $moneda_factura
                    )
                );


                /* =========================================
                   IGNORAR FILAS VACÍAS
                ========================================= */

                if (
                    $codigo === "" &&
                    $descripcion === ""
                ) {

                    continue;
                }


                /* =========================================
                   VALIDAR
                ========================================= */

                if ($codigo === "") {

                    throw new Exception(
                        "Hay un producto sin código."
                    );
                }


                if ($descripcion === "") {

                    throw new Exception(
                        "El producto "
                        . $codigo
                        . " no tiene descripción."
                    );
                }


                if ($cantidad <= 0) {

                    throw new Exception(
                        "La cantidad del producto "
                        . $codigo
                        . " debe ser mayor que cero."
                    );
                }


                if ($valor < 0) {

                    throw new Exception(
                        "El valor/costo del producto "
                        . $codigo
                        . " no puede ser negativo."
                    );
                }


                /* =========================================
                   VALIDAR MONEDA
                ========================================= */

                if (
                    $moneda !== "MXN" &&
                    $moneda !== "USD"
                ) {

                    $moneda =
                        $moneda_factura;
                }


                /* =========================================
                   CALCULAR IMPORTE
                ========================================= */

                $importe = round(
                    $cantidad * $valor,
                    2
                );


                /* =========================================
                   BUSCAR PRODUCTO
                ========================================= */

                $sqlBuscar = "
                    SELECT
                        id,
                        cantidad
                    FROM inventario
                    WHERE codigo = ?
                    LIMIT 1
                    FOR UPDATE
                ";


                $buscar =
                    $conexion->prepare(
                        $sqlBuscar
                    );


                if (!$buscar) {

                    throw new Exception(
                        "Error buscando producto "
                        . $codigo
                        . ": "
                        . $conexion->error
                    );
                }


                $buscar->bind_param(
                    "s",
                    $codigo
                );


                if (!$buscar->execute()) {

                    $errorSql =
                        $buscar->error;

                    $buscar->close();

                    throw new Exception(
                        "Error consultando producto "
                        . $codigo
                        . ": "
                        . $errorSql
                    );
                }


                $resultado =
                    $buscar->get_result();


                /* =========================================
                   PRODUCTO EXISTENTE
                ========================================= */

                if ($resultado->num_rows > 0) {

                    $inventario =
                        $resultado->fetch_assoc();


                    $inventario_id =
                        intval(
                            $inventario["id"]
                        );


                    $cantidad_anterior =
                        floatval(
                            $inventario["cantidad"]
                        );


                    $cantidad_nueva =
                        round(
                            $cantidad_anterior
                            + $cantidad,
                            3
                        );


                    /* =====================================
                       ACTUALIZAR INVENTARIO
                    ===================================== */

                    $actualizar =
                        $conexion->prepare(
                            "
                            UPDATE inventario
                            SET cantidad = ?
                            WHERE id = ?
                            "
                        );


                    if (!$actualizar) {

                        $buscar->close();

                        throw new Exception(
                            "Error preparando actualización de "
                            . $codigo
                        );
                    }


                    $actualizar->bind_param(
                        "di",
                        $cantidad_nueva,
                        $inventario_id
                    );


                    if (!$actualizar->execute()) {

                        $errorSql =
                            $actualizar->error;

                        $actualizar->close();
                        $buscar->close();

                        throw new Exception(
                            "No se pudo actualizar "
                            . $codigo
                            . ": "
                            . $errorSql
                        );
                    }


                    $actualizar->close();

                }


                /* =========================================
                   PRODUCTO NUEVO
                ========================================= */

                else {

                    $cantidad_anterior = 0;

                    $cantidad_nueva =
                        round(
                            $cantidad,
                            3
                        );


                    $ubicacion = "";

                    $maximo = 0;

                    $minimo = 0;

                    $proveedor_marca =
                        $nombre_emisor;


                    /* =====================================
                       CREAR PRODUCTO
                    ===================================== */

                    $crear =
                        $conexion->prepare(
                            "
                            INSERT INTO inventario
                            (
                                codigo,
                                articulo_descripcion,
                                cantidad,
                                ubicacion,
                                maximo,
                                minimo,
                                proveedor_marca
                            )
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                            "
                        );


                    if (!$crear) {

                        $buscar->close();

                        throw new Exception(
                            "Error preparando creación de "
                            . $codigo
                            . ": "
                            . $conexion->error
                        );
                    }


                    $crear->bind_param(
                        "ssdsiis",
                        $codigo,
                        $descripcion,
                        $cantidad_nueva,
                        $ubicacion,
                        $maximo,
                        $minimo,
                        $proveedor_marca
                    );


                    if (!$crear->execute()) {

                        $errorSql =
                            $crear->error;

                        $crear->close();
                        $buscar->close();

                        throw new Exception(
                            "No se pudo crear el producto "
                            . $codigo
                            . ": "
                            . $errorSql
                        );
                    }


                    $inventario_id =
                        $conexion->insert_id;


                    $crear->close();
                }


                $buscar->close();


                /* =========================================
                   GUARDAR DETALLE DE FACTURA
                ========================================= */

                $stmtDetalle->bind_param(
                    "isssdsdii",
                    $factura_id,
                    $codigo,
                    $descripcion,
                    $unidad,
                    $cantidad,
                    $valor,
                    $moneda,
                    $importe,
                    $inventario_id
                );


                if (!$stmtDetalle->execute()) {

                    throw new Exception(
                        "No se pudo guardar el detalle del producto "
                        . $codigo
                        . ": "
                        . $stmtDetalle->error
                    );
                }


                /* =========================================
                   GUARDAR MOVIMIENTO
                ========================================= */

                $observaciones =
                    "Entrada por factura "
                    . $numero_factura;


                $stmtMovimiento->bind_param(
                    "idddis",
                    $inventario_id,
                    $cantidad,
                    $cantidad_anterior,
                    $cantidad_nueva,
                    $factura_id,
                    $observaciones
                );


                if (!$stmtMovimiento->execute()) {

                    throw new Exception(
                        "No se pudo registrar el movimiento de "
                        . $codigo
                        . ": "
                        . $stmtMovimiento->error
                    );
                }


                $productosProcesados++;
            }


            /* =============================================
               CERRAR STATEMENTS
            ============================================= */

            $stmtDetalle->close();

            $stmtMovimiento->close();


            /* =============================================
               VALIDAR PRODUCTOS
            ============================================= */

            if ($productosProcesados === 0) {

                throw new Exception(
                    "No se encontró ningún producto válido."
                );
            }


            /* =============================================
               CONFIRMAR
            ============================================= */

            $conexion->commit();


            /* =============================================
               REGRESAR INVENTARIO
            ============================================= */

            header(
                "Location: index.php?entrada=ok"
            );

            exit;


        } catch (Throwable $e) {

            if (
                isset($conexion) &&
                $conexion->errno === 0
            ) {

                $conexion->rollback();

            } else {

                $conexion->rollback();

            }


            $error =
                "❌ No se pudo registrar la entrada: "
                . $e->getMessage();
        }
    }
}

?>


<?php require "header.php"; ?>


<style>

/* =====================================================
   FORMULARIO
===================================================== */

.formulario {

    background: white;

    padding: 25px;

    border-radius: 10px;

    box-shadow:
        0 2px 10px rgba(0,0,0,.10);

}


/* =====================================================
   GRID
===================================================== */

.grid {

    display: grid;

    grid-template-columns:
        repeat(auto-fit, minmax(220px, 1fr));

    gap: 15px;

}


/* =====================================================
   CAMPOS
===================================================== */

.campo {

    display: flex;

    flex-direction: column;

}


.campo label {

    font-weight: bold;

    margin-bottom: 5px;

}


.campo input,
.campo select {

    width: 100%;

    box-sizing: border-box;

    padding: 10px;

    border: 1px solid #ccc;

    border-radius: 5px;

    font-size: 14px;

}


/* =====================================================
   SECCIONES
===================================================== */

.seccion {

    margin-top: 30px;

    margin-bottom: 15px;

    padding-bottom: 8px;

    border-bottom: 2px solid #007bff;

}


/* =====================================================
   TABLA
===================================================== */

.productos {

    width: 100%;

    overflow-x: auto;

}


.productos table {

    width: 100%;

    min-width: 1100px;

    border-collapse: collapse;

}


.productos th {

    background: #212529;

    color: white;

    padding: 10px;

    text-align: left;

}


.productos td {

    padding: 7px;

    border-bottom: 1px solid #ddd;

}


.productos td input,
.productos td select {

    width: 100%;

    box-sizing: border-box;

    padding: 8px;

    border: 1px solid #ccc;

    border-radius: 4px;

}


/* =====================================================
   IMPORTE
===================================================== */

.importe {

    background: #f1f3f5;

    font-weight: bold;

}


/* =====================================================
   CAMPOS CALCULADOS
===================================================== */

.calculado {

    background: #e9ecef;

    cursor: not-allowed;

}


/* =====================================================
   BOTONES
===================================================== */

.boton {

    border: none;

    padding: 10px 15px;

    border-radius: 5px;

    cursor: pointer;

    text-decoration: none;

    display: inline-block;

    font-size: 14px;

}


.agregar {

    background: #0d6efd;

    color: white;

}


.guardar {

    background: #198754;

    color: white;

    font-size: 16px;

}


.duplicar {

    background: #6f42c1;

    color: white;

}


.eliminar {

    background: #dc3545;

    color: white;

}


.inventario {

    background: #6c757d;

    color: white;

}


/* =====================================================
   ERROR
===================================================== */

.error {

    background: #f8d7da;

    color: #842029;

    padding: 15px;

    border-radius: 5px;

    margin-bottom: 20px;

}


/* =====================================================
   AYUDA
===================================================== */

.ayuda {

    background: #cff4fc;

    color: #055160;

    padding: 12px;

    border-radius: 5px;

    margin-bottom: 20px;

}


/* =====================================================
   TOTALES
===================================================== */

.totales {

    max-width: 450px;

    margin-left: auto;

    margin-top: 25px;

}


.totales .campo {

    margin-bottom: 12px;

}


/* =====================================================
   ACCIONES
===================================================== */

.acciones {

    margin-top: 20px;

    display: flex;

    gap: 10px;

    flex-wrap: wrap;

}


</style>


<h1>
    📥 Entrada de almacén
</h1>


<div class="ayuda">

    💡 Si el código ya existe en el inventario,
    se sumará la cantidad recibida.

    Si el código no existe,
    se creará automáticamente.

    <br><br>

    💰 El importe se calcula automáticamente como:

    <strong>
        Cantidad × Valor / Costo
    </strong>

    <br>

    🧾 El IVA se captura manualmente,
    ya que depende de cada proveedor.

</div>


<?php if ($error !== ""): ?>

    <div class="error">

        <?= htmlspecialchars($error) ?>

    </div>

<?php endif; ?>


<form
    method="POST"
    class="formulario"
    id="formEntrada">


    <!-- =================================================
         DATOS DE FACTURA
    ================================================== -->

    <h2 class="seccion">

        📄 Datos de la factura

    </h2>


    <div class="grid">


        <div class="campo">

            <label>
                RFC del emisor *
            </label>

            <input
                type="text"
                name="rfc_emisor"
                maxlength="20"
                value="<?= htmlspecialchars(
                    $_POST["rfc_emisor"] ?? ""
                ) ?>"
                required>

        </div>


        <div class="campo">

            <label>
                Nombre del emisor / proveedor *
            </label>

            <input
                type="text"
                name="nombre_emisor"
                value="<?= htmlspecialchars(
                    $_POST["nombre_emisor"] ?? ""
                ) ?>"
                required>

        </div>


        <div class="campo">

            <label>
                RFC del receptor
            </label>

            <input
                type="text"
                name="rfc_receptor"
                maxlength="20"
                value="<?= htmlspecialchars(
                    $_POST["rfc_receptor"] ?? ""
                ) ?>">

        </div>


        <div class="campo">

            <label>
                Nombre del receptor
            </label>

            <input
                type="text"
                name="nombre_receptor"
                value="<?= htmlspecialchars(
                    $_POST["nombre_receptor"] ?? ""
                ) ?>">

        </div>


        <div class="campo">

            <label>
                Número de factura / folio *
            </label>

            <input
                type="text"
                name="numero_factura"
                value="<?= htmlspecialchars(
                    $_POST["numero_factura"] ?? ""
                ) ?>"
                required>

        </div>


        <div class="campo">

            <label>
                Fecha de factura
            </label>

            <input
                type="date"
                name="fecha_factura"
                value="<?= htmlspecialchars(
                    $_POST["fecha_factura"] ?? ""
                ) ?>">

        </div>


        <div class="campo">

            <label>
                Moneda de la factura
            </label>

            <select name="moneda_factura">

                <option
                    value="MXN"
                    <?= (
                        $_POST["moneda_factura"]
                        ?? "MXN"
                    ) === "MXN"
                        ? "selected"
                        : ""
                    ?>>

                    MXN - Peso mexicano

                </option>

                <option
                    value="USD"
                    <?= (
                        $_POST["moneda_factura"]
                        ?? ""
                    ) === "USD"
                        ? "selected"
                        : ""
                    ?>>

                    USD - Dólar estadounidense

                </option>

            </select>

        </div>

    </div>


    <!-- =================================================
         PRODUCTOS
    ================================================== -->

    <h2 class="seccion">

        📦 Productos recibidos

    </h2>


    <div class="productos">

        <table>

            <thead>

                <tr>

                    <th>
                        Código
                    </th>

                    <th>
                        Descripción
                    </th>

                    <th>
                        Unidad
                    </th>

                    <th>
                        Cantidad
                    </th>

                    <th>
                        Valor / Costo
                    </th>

                    <th>
                        Moneda
                    </th>

                    <th>
                        Importe
                    </th>

                    <th>
                        Acciones
                    </th>

                </tr>

            </thead>


            <tbody id="productos">


                <tr class="producto-fila">


                    <td>

                        <input
                            type="text"
                            name="producto[0][codigo]"
                            autocomplete="off"
                            required>

                    </td>


                    <td>

                        <input
                            type="text"
                            name="producto[0][descripcion]"
                            autocomplete="off"
                            required>

                    </td>


                    <td>

                        <input
                            type="text"
                            name="producto[0][unidad]"
                            placeholder="PZA"
                            autocomplete="off">

                    </td>


                    <td>

                        <input
                            type="number"
                            step="0.001"
                            min="0"
                            name="producto[0][cantidad]"
                            value=""
                            placeholder="0.000"
                            inputmode="decimal"
                            class="cantidad">

                    </td>


                    <td>

                        <input
                            type="number"
                            step="0.01"
                            min="0"
                            name="producto[0][valor]"
                            value=""
                            placeholder="0.00"
                            inputmode="decimal"
                            class="valor">

                    </td>


                    <td>

                        <select
                            name="producto[0][moneda]"
                            class="moneda">

                            <option value="MXN">
                                MXN
                            </option>

                            <option value="USD">
                                USD
                            </option>

                        </select>

                    </td>


                    <td>

                        <input
                            type="number"
                            step="0.01"
                            name="producto[0][importe]"
                            value="0.00"
                            class="importe calculado"
                            readonly>

                    </td>


                    <td>

                        <button
                            type="button"
                            class="boton duplicar"
                            onclick="duplicarProducto(this)">

                            📋 Duplicar

                        </button>


                        <button
                            type="button"
                            class="boton eliminar"
                            onclick="eliminarFila(this)">

                            🗑️

                        </button>

                    </td>

                </tr>


            </tbody>

        </table>

    </div>


    <br>


    <button
        type="button"
        class="boton agregar"
        onclick="agregarProducto()">

        ➕ Agregar producto

    </button>


    <!-- =================================================
         TOTALES
    ================================================== -->

    <div class="totales">


        <div class="campo">

            <label>
                Subtotal
            </label>

            <input
                type="number"
                step="0.01"
                name="subtotal"
                id="subtotal"
                value="0.00"
                class="calculado"
                readonly>

        </div>


        <div class="campo">

            <label>
                IVA
                <small>
                    (captura manual)
                </small>
            </label>

            <input
                type="number"
                step="0.01"
                min="0"
                name="iva"
                id="iva"
                value="<?= htmlspecialchars(
                    $_POST["iva"] ?? "0.00"
                ) ?>"
                placeholder="0.00"
                inputmode="decimal">

        </div>


        <div class="campo">

            <label>
                Total
            </label>

            <input
                type="number"
                step="0.01"
                name="total"
                id="total"
                value="0.00"
                class="calculado"
                readonly>

        </div>


    </div>


    <!-- =================================================
         ACCIONES
    ================================================== -->

    <div class="acciones">


        <button
            type="submit"
            class="boton guardar">

            💾 Registrar entrada de almacén

        </button>


        <a
            href="index.php"
            class="boton inventario">

            ↩️ Volver al inventario

        </a>


    </div>


</form>


<script>

/* =====================================================
   CONTADOR
===================================================== */

let numeroProducto = 1;


/* =====================================================
   ESCAPAR HTML
===================================================== */

function escaparHTML(texto) {

    return String(texto)

        .replace(/&/g, "&amp;")

        .replace(/</g, "&lt;")

        .replace(/>/g, "&gt;")

        .replace(/"/g, "&quot;")

        .replace(/'/g, "&#039;");

}


/* =====================================================
   AGREGAR PRODUCTO
===================================================== */

function agregarProducto() {

    crearFilaProducto();

}


/* =====================================================
   CREAR FILA
===================================================== */

function crearFilaProducto(datos = {}) {

    const tabla =
        document.getElementById("productos");


    const fila =
        document.createElement("tr");


    fila.className =
        "producto-fila";


    const codigo =
        datos.codigo || "";


    const descripcion =
        datos.descripcion || "";


    const unidad =
        datos.unidad || "";


    const cantidad =
        datos.cantidad || "";


    const valor =
        datos.valor || "";


    const moneda =
        datos.moneda || "MXN";


    fila.innerHTML = `

        <td>

            <input
                type="text"
                name="producto[${numeroProducto}][codigo]"
                value="${escaparHTML(codigo)}"
                autocomplete="off"
                required>

        </td>

        <td>

            <input
                type="text"
                name="producto[${numeroProducto}][descripcion]"
                value="${escaparHTML(descripcion)}"
                autocomplete="off"
                required>

        </td>

        <td>

            <input
                type="text"
                name="producto[${numeroProducto}][unidad]"
                value="${escaparHTML(unidad)}"
                placeholder="PZA"
                autocomplete="off">

        </td>

        <td>

            <input
                type="number"
                step="0.001"
                min="0"
                name="producto[${numeroProducto}][cantidad]"
                value="${escaparHTML(cantidad)}"
                placeholder="0.000"
                inputmode="decimal"
                class="cantidad">

        </td>

        <td>

            <input
                type="number"
                step="0.01"
                min="0"
                name="producto[${numeroProducto}][valor]"
                value="${escaparHTML(valor)}"
                placeholder="0.00"
                inputmode="decimal"
                class="valor">

        </td>

        <td>

            <select
                name="producto[${numeroProducto}][moneda]"
                class="moneda">

                <option
                    value="MXN"
                    ${moneda === "MXN"
                        ? "selected"
                        : ""}>

                    MXN

                </option>

                <option
                    value="USD"
                    ${moneda === "USD"
                        ? "selected"
                        : ""}>

                    USD

                </option>

            </select>

        </td>

        <td>

            <input
                type="number"
                step="0.01"
                name="producto[${numeroProducto}][importe]"
                value="0.00"
                class="importe calculado"
                readonly>

        </td>

        <td>

            <button
                type="button"
                class="boton duplicar"
                onclick="duplicarProducto(this)">

                📋 Duplicar

            </button>

            <button
                type="button"
                class="boton eliminar"
                onclick="eliminarFila(this)">

                🗑️

            </button>

        </td>

    `;


    tabla.appendChild(fila);


    numeroProducto++;


    calcularImporte(
        fila.querySelector(".cantidad")
    );

}


/* =====================================================
   DUPLICAR PRODUCTO
===================================================== */

function duplicarProducto(boton) {

    const fila =
        boton.closest(".producto-fila");


    if (!fila) {
        return;
    }


    const datos = {

        codigo:
            fila.querySelector(
                ".cantidad"
            )
            ? fila.querySelector(
                'input[name*="[codigo]"]'
            ).value
            : "",


        descripcion:
            fila.querySelector(
                'input[name*="[descripcion]"]'
            ).value,


        unidad:
            fila.querySelector(
                'input[name*="[unidad]"]'
            ).value,


        cantidad:
            fila.querySelector(
                ".cantidad"
            ).value,


        valor:
            fila.querySelector(
                ".valor"
            ).value,


        moneda:
            fila.querySelector(
                ".moneda"
            ).value

    };


    crearFilaProducto(datos);


    const filas =
        document.querySelectorAll(
            "#productos .producto-fila"
        );


    const nuevaFila =
        filas[filas.length - 1];


    const campoDescripcion =
        nuevaFila.querySelector(
            'input[name*="[descripcion]"]'
        );


    if (campoDescripcion) {

        campoDescripcion.focus();

        campoDescripcion.select();

    }

}


/* =====================================================
   ELIMINAR FILA
===================================================== */

function eliminarFila(boton) {

    const filas =
        document.querySelectorAll(
            "#productos .producto-fila"
        );


    if (filas.length <= 1) {

        alert(
            "Debe existir al menos un producto."
        );

        return;
    }


    const fila =
        boton.closest(".producto-fila");


    if (fila) {

        fila.remove();

    }


    calcularTotales();

}


/* =====================================================
   CALCULAR IMPORTE
===================================================== */

function calcularImporte(elemento) {

    const fila =
        elemento.closest(".producto-fila");


    if (!fila) {
        return;
    }


    const campoCantidad =
        fila.querySelector(".cantidad");


    const campoValor =
        fila.querySelector(".valor");


    const campoImporte =
        fila.querySelector(".importe");


    if (
        !campoCantidad ||
        !campoValor ||
        !campoImporte
    ) {

        return;

    }


    const cantidad =
        parseFloat(
            campoCantidad.value
        ) || 0;


    const valor =
        parseFloat(
            campoValor.value
        ) || 0;


    const importe =
        cantidad * valor;


    campoImporte.value =
        importe.toFixed(2);


    calcularTotales();

}


/* =====================================================
   CALCULAR SUBTOTAL Y TOTAL
===================================================== */

function calcularTotales() {

    let subtotal = 0;


    const importes =
        document.querySelectorAll(
            ".importe"
        );


    importes.forEach(function(campo) {

        subtotal +=
            parseFloat(
                campo.value
            ) || 0;

    });


    subtotal =
        Math.round(
            subtotal * 100
        ) / 100;


    const campoIVA =
        document.getElementById("iva");


    const iva =
        parseFloat(
            campoIVA.value
        ) || 0;


    const total =
        subtotal + iva;


    document.getElementById(
        "subtotal"
    ).value =
        subtotal.toFixed(2);


    document.getElementById(
        "total"
    ).value =
        total.toFixed(2);

}


/* =====================================================
   CAPTURA DE CANTIDAD Y VALOR
===================================================== */

document.addEventListener(
    "input",
    function(event) {

        if (
            event.target.classList.contains(
                "cantidad"
            ) ||
            event.target.classList.contains(
                "valor"
            )
        ) {

            calcularImporte(
                event.target
            );

        }


        if (
            event.target.id === "iva"
        ) {

            calcularTotales();

        }

    }
);


/* =====================================================
   CAMBIO DE MONEDA
===================================================== */

document.addEventListener(
    "change",
    function(event) {

        if (
            event.target.classList.contains(
                "moneda"
            )
        ) {

            // La moneda solamente identifica
            // el valor del producto.
            // No modifica el importe.

            calcularImporte(
                event.target
            );

        }

    }
);


/* =====================================================
   CALCULAR AL CARGAR
===================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        document.querySelectorAll(
            ".producto-fila"
        ).forEach(function(fila) {

            const cantidad =
                fila.querySelector(
                    ".cantidad"
                );

            if (cantidad) {

                calcularImporte(
                    cantidad
                );

            }

        });


        calcularTotales();

    }
);


/* =====================================================
   CONFIRMAR FORMULARIO
===================================================== */

document.getElementById(
    "formEntrada"
).addEventListener(
    "submit",
    function(event) {

        const confirmar =
            confirm(
                "¿Deseas registrar esta entrada de almacén?"
            );


        if (!confirmar) {

            event.preventDefault();

        }

    }
);

</script>


<?php require "footer.php"; ?>
