<?php

require_once __DIR__ . '/seguridad.php';

verificar_sesion();

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';
$rol_usuario = $_SESSION['rol'] ?? 'USUARIO';

?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6f8;
    color: #333;
}

.barra-superior {
    background: #212529;
    color: white;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}

.titulo-sistema {
    font-size: 20px;
    font-weight: bold;
}

.menu {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    align-items: center;
}

.menu a {
    color: white;
    text-decoration: none;
    padding: 8px 12px;
    border-radius: 5px;
    font-size: 14px;
    background: #343a40;
}

.menu a:hover {
    background: #495057;
}

.administracion {
    background: #6f42c1 !important;
}

.usuario-conectado {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-left: 10px;
}

.usuario-info {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.usuario-nombre {
    font-size: 13px;
    font-weight: bold;
}

.usuario-rol {
    font-size: 11px;
    color: #ced4da;
}

.boton-salir {
    background: #dc3545 !important;
}

.boton-salir:hover {
    background: #bb2d3b !important;
}

.pagina {
    width: 95%;
    max-width: 1400px;
    margin: 30px auto;
}
</style>

</head>

<body>

<header class="barra-superior">

    <div class="titulo-sistema">
        📦 Sistema de Almacén
    </div>

    <nav class="menu">

        <a href="index.php">
            📋 Inventario
        </a>

        <a href="nuevo_articulo.php">
            ➕ Nuevo artículo
        </a>

        <a href="entrada.php">
            📥 Entrada
        </a>

        <a href="salida_almacen.php">
            📤 Salida
        </a>

        <a href="facturas.php">
            📄 Facturas
        </a>

        <a href="historial_movimientos.php">
            📋 Historial
        </a>

        <a href="panel.php">
            📊 Panel
        </a>

        <a href="empleados_areas.php">
            👥 Empleados
        </a>

        <?php if ($rol_usuario === 'ADMIN'): ?>

            <a href="admin_panel.php" class="administracion">
                ⚙️ Administración
            </a>

        <?php endif; ?>

        <div class="usuario-conectado">

            <div class="usuario-info">

                <span class="usuario-nombre">
                    👤 <?= htmlspecialchars($nombre_empleado) ?>
                </span>

                <span class="usuario-rol">
                    <?= htmlspecialchars($rol_usuario) ?>
                </span>

            </div>

            <a href="logout.php" class="boton-salir">
                🚪 Salir
            </a>

        </div>

    </nav>

</header>

<div class="pagina">

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            color: #333;
        }

        .barra-superior {

            background: #212529;

            color: white;

            padding: 15px 30px;

            display: flex;

            justify-content: space-between;

            align-items: center;

            flex-wrap: wrap;

            gap: 10px;

        }

        .titulo-sistema {

            font-size: 20px;

            font-weight: bold;

        }

        .menu {

            display: flex;

            gap: 8px;

            flex-wrap: wrap;

        }

        .menu a {

            color: white;

            text-decoration: none;

            padding: 8px 12px;

            border-radius: 5px;

            font-size: 14px;

            background: #343a40;

        }

        .menu a:hover {

            background: #495057;

        }

        .pagina {

            width: 95%;

            max-width: 1400px;

            margin: 30px auto;

        }

    </style>

</head>

<body>

<header class="barra-superior">

    <div class="titulo-sistema">

        📦 Sistema de Almacén

    </div>

    <nav class="menu">

        <a href="index.php">
            📋 Inventario
        </a>

        <a href="nuevo_articulo.php">
            ➕ Nuevo artículo
        </a>

        <a href="entrada_almacen.php">
            📥 Entrada
        </a>

        <a href="importar.php">
            📊 Excel
        </a>

        <a href="entrada_almacen.php">
            📥 Entrada
        </a>


    </nav>

</header>

<div class="pagina">