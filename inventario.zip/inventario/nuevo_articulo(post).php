<?php

// ==========================================
// SEGURIDAD
// ==========================================

require_once __DIR__ . '/seguridad.php';

verificar_sesion();


// ==========================================
// CONEXIÓN
// ==========================================

require "conexion.php";


// ==========================================
// VARIABLES
// ==========================================

$mensaje = "";
$error = "";

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';


// ==========================================
// OBTENER ARTÍCULOS DEL INVENTARIO
// ==========================================

$articulos = [];

$sql_articulos = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        ubicacion,
        maximo,
        minimo,
        proveedor_marca
    FROM inventario
    ORDER BY articulo_descripcion ASC
";

$resultado_articulos = $conexion->query($sql_articulos);

if ($resultado_articulos) {

    while ($fila = $resultado_articulos->fetch_assoc()) {

        $articulos[] = $fila;

    }

}


// ==========================================
// PROCESAR FORMULARIO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $id_articulo = intval(
        $_POST["id_articulo"] ?? 0
    );

    $cantidad_reingreso = intval(
        $_POST["cantidad"] ?? 0
    );


    // ======================================
    // VALIDACIONES
    // ======================================

    if ($id_articulo <= 0) {

        $error = "Debes seleccionar un artículo.";

    } elseif ($cantidad_reingreso <= 0) {

        $error =
            "La cantidad a ingresar debe ser mayor a 0.";

    } else {


        // ==================================
        // BUSCAR ARTÍCULO SELECCIONADO
        // ==================================

        $buscar = $conexion->prepare("
            SELECT
                id,
                codigo,
                articulo_descripcion,
                cantidad,
                ubicacion,
                maximo,
                minimo,
                proveedor_marca
            FROM inventario
            WHERE id = ?
            LIMIT 1
        ");


        if (!$buscar) {

            $error =
                "Error al preparar la consulta: "
                . $conexion->error;

        } else {

            $buscar->bind_param(
                "i",
                $id_articulo
            );

            $buscar->execute();

            $resultado = $buscar->get_result();


            // ==================================
            // ARTÍCULO NO ENCONTRADO
            // ==================================

            if ($resultado->num_rows === 0) {

                $error =
                    "El artículo seleccionado no existe "
                    . "en el inventario.";

            } else {


                // ==================================
                // DATOS DEL ARTÍCULO
                // ==================================

                $articulo = $resultado->fetch_assoc();

                $cantidad_actual =
                    intval($articulo["cantidad"]);


                // ==================================
                // CALCULAR NUEVA CANTIDAD
                // ==================================

                $nueva_cantidad =
                    $cantidad_actual
                    + $cantidad_reingreso;


                // ==================================
                // ACTUALIZAR INVENTARIO
                // ==================================

                $actualizar = $conexion->prepare("
                    UPDATE inventario
                    SET cantidad = ?
                    WHERE id = ?
                ");


                if (!$actualizar) {

                    $error =
                        "Error al preparar la actualización: "
                        . $conexion->error;

                } else {

                    $actualizar->bind_param(
                        "ii",
                        $nueva_cantidad,
                        $id_articulo
                    );


                    // ==================================
                    // GUARDAR
                    // ==================================

                    if ($actualizar->execute()) {

                        header(
                            "Location: index.php?"
                            . "mensaje=reingreso_realizado"
                        );

                        exit;

                    } else {

                        $error =
                            "Error al actualizar el inventario: "
                            . $actualizar->error;

                    }


                    $actualizar->close();

                }

            }


            $buscar->close();

        }

    }

}

?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Ingreso de artículo</title>


    <style>

        /* ==========================================
           CONFIGURACIÓN GENERAL
        =========================================== */

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            padding: 0;

            font-family: Arial, sans-serif;

            background: #f4f6f8;

            color: #333;

        }


        /* ==========================================
           CONTENIDO PRINCIPAL
        =========================================== */

        .contenido-principal {

            margin-left: 240px;

            min-height: 100vh;

        }


        /* ==========================================
           BARRA SUPERIOR
        =========================================== */

        .barra-superior {

            height: 70px;

            background: #ffffff;

            border-bottom: 1px solid #ddd;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 30px;

            box-shadow:
                0 1px 5px rgba(0,0,0,.08);

        }


        .titulo-superior {

            font-size: 20px;

            font-weight: bold;

            color: #212529;

        }


        .usuario-superior {

            font-size: 13px;

            color: #555;

        }


        /* ==========================================
           CONTENEDOR
        =========================================== */

        .contenedor {

            max-width: 700px;

            margin: 40px auto;

            background: white;

            padding: 30px;

            border-radius: 12px;

            box-shadow:
                0 3px 15px rgba(0,0,0,.15);

        }


        h1 {

            margin-top: 0;

            color: #333;

        }


        .descripcion-ayuda {

            color: #666;

            font-size: 14px;

            margin-bottom: 25px;

            line-height: 1.5;

        }


        /* ==========================================
           FORMULARIO
        =========================================== */

        .formulario {

            display: grid;

            grid-template-columns: 1fr 1fr;

            gap: 15px;

        }


        .campo {

            display: flex;

            flex-direction: column;

        }


        .campo-completo {

            grid-column: 1 / -1;

        }


        label {

            font-weight: bold;

            margin-bottom: 6px;

        }


        input,
        select {

            padding: 11px;

            border: 1px solid #ccc;

            border-radius: 6px;

            font-size: 15px;

            font-family: Arial, sans-serif;

        }


        input:focus,
        select:focus {

            outline: none;

            border-color: #0d6efd;

            box-shadow:
                0 0 0 2px rgba(13,110,253,.10);

        }


        input[readonly] {

            background: #f1f3f5;

            color: #555;

        }


        /* ==========================================
           INFORMACIÓN DEL ARTÍCULO
        =========================================== */

        .informacion-articulo {

            margin-top: 20px;

            padding: 15px;

            background: #f8f9fa;

            border: 1px solid #ddd;

            border-radius: 8px;

        }


        .informacion-articulo h3 {

            margin-top: 0;

            margin-bottom: 15px;

            font-size: 16px;

            color: #212529;

        }


        /* ==========================================
           BOTONES
        =========================================== */

        .botones {

            margin-top: 25px;

            display: flex;

            gap: 10px;

            flex-wrap: wrap;

        }


        button,
        .cancelar {

            padding: 12px 20px;

            border: none;

            border-radius: 6px;

            text-decoration: none;

            cursor: pointer;

            font-size: 15px;

            font-family: Arial, sans-serif;

        }


        button {

            background: #198754;

            color: white;

        }


        button:hover {

            background: #157347;

        }


        .cancelar {

            background: #6c757d;

            color: white;

        }


        .cancelar:hover {

            background: #5a6268;

        }


        /* ==========================================
           ERROR
        =========================================== */

        .error {

            background: #f8d7da;

            color: #842029;

            padding: 12px;

            margin-bottom: 20px;

            border-radius: 6px;

        }


        /* ==========================================
           RESPONSIVE
        =========================================== */

        @media (max-width: 850px) {

            .contenido-principal {

                margin-left: 210px;

            }

        }


        @media (max-width: 650px) {

            .contenido-principal {

                margin-left: 0;

            }


            .barra-superior {

                height: auto;

                padding: 15px;

                flex-direction: column;

                align-items: flex-start;

                gap: 8px;

            }


            .contenedor {

                width: 92%;

                margin: 20px auto;

                padding: 20px;

            }


            .formulario {

                grid-template-columns: 1fr;

            }


            .campo-completo {

                grid-column: auto;

            }

        }

    </style>

</head>


<body>


<!-- ==========================================
     MENÚ LATERAL
========================================== -->

<?php include 'menu.php'; ?>


<!-- ==========================================
     CONTENIDO PRINCIPAL
========================================== -->

<main class="contenido-principal">


    <!-- ======================================
         BARRA SUPERIOR
    ======================================= -->

    <header class="barra-superior">

        <div class="titulo-superior">

            📥 Ingreso de artículo

        </div>


        <div class="usuario-superior">

            Usuario:

            <strong>

                <?= htmlspecialchars($nombre_empleado) ?>

            </strong>

        </div>

    </header>


    <!-- ======================================
         FORMULARIO
    ======================================= -->

    <div class="contenedor">


        <h1>

            📥 Ingreso de artículo

        </h1>


        <p class="descripcion-ayuda">

            Selecciona un artículo existente del inventario
            y registra la cantidad que está ingresando.

        </p>


        <!-- ==================================
             ERROR
        =================================== -->

        <?php if ($error !== ""): ?>

            <div class="error">

                ❌

                <?= htmlspecialchars($error) ?>

            </div>

        <?php endif; ?>


        <form method="POST">


            <div class="formulario">


                <!-- ==================================
                     SELECCIONAR ARTÍCULO
                =================================== -->

                <div class="campo campo-completo">

                    <label>

                        Artículo

                    </label>


                    <select
                        name="id_articulo"
                        id="id_articulo"
                        required
                    >

                        <option value="">

                            -- Selecciona un artículo --

                        </option>


                        <?php foreach ($articulos as $item): ?>

                            <option
                                value="<?= $item['id'] ?>"
                                data-descripcion="<?= htmlspecialchars(
                                    $item['articulo_descripcion'],
                                    ENT_QUOTES
                                ) ?>"
                                data-ubicacion="<?= htmlspecialchars(
                                    $item['ubicacion'],
                                    ENT_QUOTES
                                ) ?>"
                                data-maximo="<?= $item['maximo'] ?>"
                                data-minimo="<?= $item['minimo'] ?>"
                                data-proveedor="<?= htmlspecialchars(
                                    $item['proveedor_marca'],
                                    ENT_QUOTES
                                ) ?>"
                            >

                                <?= htmlspecialchars(
                                    $item['codigo']
                                ) ?>

                                -

                                <?= htmlspecialchars(
                                    $item['articulo_descripcion']
                                ) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <!-- ==================================
                     CANTIDAD
                =================================== -->

                <div class="campo campo-completo">

                    <label>

                        Cantidad a ingresar

                    </label>


                    <input
                        type="number"
                        name="cantidad"
                        min="1"
                        required
                        value="<?= htmlspecialchars(
                            $_POST["cantidad"] ?? "1"
                        ) ?>"
                    >

                </div>


                <!-- ==================================
                     INFORMACIÓN AUTOMÁTICA
                =================================== -->

                <div
                    class="informacion-articulo campo-completo"
                >

                    <h3>

                        Información del artículo

                    </h3>


                    <div class="formulario">


                        <!-- DESCRIPCIÓN -->

                        <div class="campo campo-completo">

                            <label>

                                Artículo / Descripción

                            </label>


                            <input
                                type="text"
                                id="articulo_descripcion"
                                readonly
                                placeholder="Se llenará automáticamente"
                            >

                        </div>


                        <!-- UBICACIÓN -->

                        <div class="campo">

                            <label>

                                Ubicación

                            </label>


                            <input
                                type="text"
                                id="ubicacion"
                                readonly
                            >

                        </div>


                        <!-- MÁXIMO -->

                        <div class="campo">

                            <label>

                                Máximo

                            </label>


                            <input
                                type="number"
                                id="maximo"
                                readonly
                            >

                        </div>


                        <!-- MÍNIMO -->

                        <div class="campo">

                            <label>

                                Mínimo

                            </label>


                            <input
                                type="number"
                                id="minimo"
                                readonly
                            >

                        </div>


                        <!-- PROVEEDOR -->

                        <div class="campo campo-completo">

                            <label>

                                Proveedor / Marca

                            </label>


                            <input
                                type="text"
                                id="proveedor_marca"
                                readonly
                            >

                        </div>


                    </div>

                </div>


            </div>


            <!-- ==================================
                 BOTONES
            =================================== -->

            <div class="botones">


                <button type="submit">

                    💾 Registrar ingreso

                </button>


                <a
                    href="index.php"
                    class="cancelar"
                >

                    ↩️ Volver al inventario

                </a>


            </div>


        </form>


    </div>


</main>


<!-- ==========================================
     JAVASCRIPT
     LLENAR DATOS AUTOMÁTICAMENTE
========================================== -->

<script>

const selector =
    document.getElementById("id_articulo");

const descripcion =
    document.getElementById("articulo_descripcion");

const ubicacion =
    document.getElementById("ubicacion");

const maximo =
    document.getElementById("maximo");

const minimo =
    document.getElementById("minimo");

const proveedor =
    document.getElementById("proveedor_marca");


selector.addEventListener("change", function () {

    const opcion =
        this.options[this.selectedIndex];


    if (!this.value) {

        descripcion.value = "";
        ubicacion.value = "";
        maximo.value = "";
        minimo.value = "";
        proveedor.value = "";

        return;

    }


    descripcion.value =
        opcion.dataset.descripcion || "";

    ubicacion.value =
        opcion.dataset.ubicacion || "";

    maximo.value =
        opcion.dataset.maximo || "0";

    minimo.value =
        opcion.dataset.minimo || "0";

    proveedor.value =
        opcion.dataset.proveedor || "";

});

</script>


</body>

</html>