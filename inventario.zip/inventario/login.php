<?php

session_start();

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/auditoria.php';

$error = '';

/*
|--------------------------------------------------------------------------
| FUNCIÓN PARA REDIRECCIONAR SEGÚN EL ROL
|--------------------------------------------------------------------------
*/

function redireccionar_por_rol($rol)
{
    $rol = strtoupper(trim($rol));

    switch ($rol) {

        case 'ADMIN':
            header("Location: admin_panel.php");
            exit;

        case 'GERENCIA':
            header("Location: panel.php");
            exit;

        case 'USUARIO':
            header("Location: index.php");
            exit;

        case 'CONSULTA':
            header("Location: inventario.php");
            exit;

        default:

            session_unset();
            session_destroy();

            header("Location: login.php");
            exit;
    }
}


/*
|--------------------------------------------------------------------------
| SI YA EXISTE UNA SESIÓN
|--------------------------------------------------------------------------
*/

if (isset($_SESSION['usuario_id'])) {

    $rol = $_SESSION['rol'] ?? '';

    redireccionar_por_rol($rol);
}


/*
|--------------------------------------------------------------------------
| PROCESAR LOGIN
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $usuario = trim($_POST['usuario'] ?? '');
    $password = $_POST['password'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | VALIDAR CAMPOS
    |--------------------------------------------------------------------------
    */

    if ($usuario === '' || $password === '') {

        $error = "Debes ingresar usuario y contraseña.";

    } else {


        /*
        |--------------------------------------------------------------------------
        | BUSCAR USUARIO
        |--------------------------------------------------------------------------
        */

        $sql = "
            SELECT
                u.id,
                u.empleado_id,
                u.usuario,
                u.password_hash,
                u.rol,
                u.activo,

                e.nombre AS nombre_empleado,
                e.numero_empleado,
                e.puesto,
                e.activo AS empleado_activo,

                a.nombre AS area

            FROM usuarios u

            INNER JOIN empleados e
                ON e.id = u.empleado_id

            INNER JOIN areas a
                ON a.id = e.area_id

            WHERE u.usuario = ?

            LIMIT 1
        ";


        $stmt = $conexion->prepare($sql);


        if (!$stmt) {

            $error =
                "Error al preparar la consulta de acceso.";

        } else {

            $stmt->bind_param(
                "s",
                $usuario
            );

            $stmt->execute();

            $resultado = $stmt->get_result();


            /*
            |--------------------------------------------------------------------------
            | USUARIO ENCONTRADO
            |--------------------------------------------------------------------------
            */

            if ($resultado->num_rows === 1) {

                $datos = $resultado->fetch_assoc();


                /*
                |--------------------------------------------------------------------------
                | 1. VERIFICAR CUENTA
                |--------------------------------------------------------------------------
                */

                if ((int)$datos['activo'] !== 1) {

                    $error =
                        "Este usuario está desactivado.";

                }


                /*
                |--------------------------------------------------------------------------
                | 2. VERIFICAR EMPLEADO
                |--------------------------------------------------------------------------
                */

                elseif (
                    (int)$datos['empleado_activo'] !== 1
                ) {

                    $error =
                        "El empleado está inactivo.";

                }


                /*
                |--------------------------------------------------------------------------
                | 3. VERIFICAR CONTRASEÑA
                |--------------------------------------------------------------------------
                */

                elseif (
                    !password_verify(
                        $password,
                        $datos['password_hash']
                    )
                ) {

                    $error =
                        "Usuario o contraseña incorrectos.";

                }


                /*
                |--------------------------------------------------------------------------
                | 4. VALIDAR ROL
                |--------------------------------------------------------------------------
                */

                elseif (
                    !in_array(
                        strtoupper(
                            trim(
                                $datos['rol'] ?? ''
                            )
                        ),
                        [
                            'ADMIN',
                            'GERENCIA',
                            'USUARIO',
                            'CONSULTA'
                        ],
                        true
                    )
                ) {

                    $error =
                        "El rol de este usuario no es válido.";

                }


                /*
                |--------------------------------------------------------------------------
                | 5. ACCESO CORRECTO
                |--------------------------------------------------------------------------
                */

                else {


                    /*
                    |--------------------------------------------------------------------------
                    | NORMALIZAR ROL
                    |--------------------------------------------------------------------------
                    */

                    $rol = strtoupper(
                        trim(
                            $datos['rol']
                        )
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | REGENERAR SESIÓN
                    |--------------------------------------------------------------------------
                    */

                    session_regenerate_id(true);


                    /*
                    |--------------------------------------------------------------------------
                    | GUARDAR INFORMACIÓN EN SESIÓN
                    |--------------------------------------------------------------------------
                    */

                    $_SESSION['usuario_id'] =
                        (int)$datos['id'];

                    $_SESSION['empleado_id'] =
                        (int)$datos['empleado_id'];

                    $_SESSION['nombre_usuario'] =
                        $datos['usuario'];

                    $_SESSION['nombre_empleado'] =
                        $datos['nombre_empleado'];

                    $_SESSION['numero_empleado'] =
                        $datos['numero_empleado'];

                    $_SESSION['puesto'] =
                        $datos['puesto'];

                    $_SESSION['area'] =
                        $datos['area'];

                    $_SESSION['rol'] =
                        $rol;


                    /*
                    |--------------------------------------------------------------------------
                    | ACTUALIZAR ÚLTIMO ACCESO
                    |--------------------------------------------------------------------------
                    */

                    $sql_acceso = "
                        UPDATE usuarios
                        SET ultimo_acceso = NOW()
                        WHERE id = ?
                    ";


                    $stmt_acceso =
                        $conexion->prepare(
                            $sql_acceso
                        );


                    if ($stmt_acceso) {

                        $stmt_acceso->bind_param(
                            "i",
                            $datos['id']
                        );

                        $stmt_acceso->execute();

                        $stmt_acceso->close();
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | REGISTRAR AUDITORÍA
                    |--------------------------------------------------------------------------
                    */

                    registrar_auditoria(
                        $conexion,
                        'LOGIN',
                        'Sistema',
                        'Inicio de sesión exitoso'
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | REDIRECCIONAR SEGÚN EL ROL
                    |--------------------------------------------------------------------------
                    */

                    redireccionar_por_rol(
                        $rol
                    );
                }


            } else {

                $error =
                    "Usuario o contraseña incorrectos.";
            }


            $stmt->close();
        }
    }
}

?>


<!DOCTYPE html>

<html lang="es">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Acceso al sistema</title>


<style>

* {
    box-sizing: border-box;
}


body {

    margin: 0;

    font-family: Arial, sans-serif;

    background: #f1f3f5;

    min-height: 100vh;

    display: flex;

    justify-content: center;

    align-items: center;
}


.login-container {

    width: 100%;

    max-width: 420px;

    padding: 20px;
}


.login-box {

    background: white;

    padding: 35px;

    border-radius: 12px;

    box-shadow:
        0 5px 25px rgba(0,0,0,.12);
}


.logo {

    text-align: center;

    margin-bottom: 20px;
}


.logo h1 {

    margin: 0;

    font-size: 24px;

    color: #212529;
}


.logo p {

    margin-top: 8px;

    color: #6c757d;

    font-size: 14px;
}


label {

    display: block;

    margin-bottom: 6px;

    font-weight: bold;
}


input {

    width: 100%;

    padding: 12px;

    margin-bottom: 18px;

    border: 1px solid #ced4da;

    border-radius: 6px;

    font-size: 15px;
}


button {

    width: 100%;

    padding: 12px;

    border: none;

    border-radius: 6px;

    background: #212529;

    color: white;

    font-size: 16px;

    cursor: pointer;
}


button:hover {

    background: #343a40;
}


.error {

    background: #f8d7da;

    color: #842029;

    border: 1px solid #f5c2c7;

    padding: 12px;

    border-radius: 6px;

    margin-bottom: 18px;

    font-size: 14px;
}


.empresa {

    text-align: center;

    margin-top: 20px;

    color: #6c757d;

    font-size: 12px;
}

</style>

</head>


<body>


<div class="login-container">


    <div class="login-box">


        <div class="logo">

            <h1>
                📦 Sistema de Almacén
            </h1>

            <p>
                GRUPO PROTEC, S.A. DE C.V.
            </p>

        </div>


        <?php if ($error !== ''): ?>

            <div class="error">

                <?= htmlspecialchars(
                    $error,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>

            </div>

        <?php endif; ?>


        <form method="POST">


            <label for="usuario">

                Usuario

            </label>


            <input
                type="text"
                id="usuario"
                name="usuario"
                autocomplete="username"
                required
                autofocus
            >


            <label for="password">

                Contraseña

            </label>


            <input
                type="password"
                id="password"
                name="password"
                autocomplete="current-password"
                required
            >


            <button type="submit">

                🔐 Iniciar sesión

            </button>


        </form>


    </div>


    <div class="empresa">

        Sistema interno de inventario<br>

        Grupo Protec

    </div>


</div>


</body>

</html>