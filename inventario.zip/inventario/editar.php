<?php

require "conexion.php";

$id = intval($_GET["id"] ?? 0);

if ($id <= 0) {
    die("Artículo no válido.");
}

// ==========================================
// GUARDAR CAMBIOS
// ==========================================

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $codigo = trim($_POST["codigo"] ?? "");
    $descripcion = trim($_POST["articulo_descripcion"] ?? "");
    $cantidad = intval($_POST["cantidad"] ?? 0);
    $ubicacion = trim($_POST["ubicacion"] ?? "");
    $maximo = intval($_POST["maximo"] ?? 0);
    $minimo = intval($_POST["minimo"] ?? 0);
    $proveedor = trim($_POST["proveedor_marca"] ?? "");

    if ($codigo === "" || $descripcion === "") {
        die("El código y la descripción son obligatorios.");
    }

    $sql = "
        UPDATE inventario
        SET
            codigo = ?,
            articulo_descripcion = ?,
            cantidad = ?,
            ubicacion = ?,
            maximo = ?,
            minimo = ?,
            proveedor_marca = ?
        WHERE id = ?
    ";

    $stmt = $conexion->prepare($sql);

    $stmt->bind_param(
        "ssisiisi",
        $codigo,
        $descripcion,
        $cantidad,
        $ubicacion,
        $maximo,
        $minimo,
        $proveedor,
        $id
    );

    if ($stmt->execute()) {

        header("Location: index.php");
        exit;

    } else {

        echo "Error al actualizar: "
            . $stmt->error;
    }

    $stmt->close();
}

// ==========================================
// OBTENER ARTÍCULO
// ==========================================

$stmt = $conexion->prepare(
    "SELECT * FROM inventario WHERE id = ?"
);

$stmt->bind_param("i", $id);

$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    die("Artículo no encontrado.");
}

$producto = $resultado->fetch_assoc();

$stmt->close();

?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Editar artículo</title>

    <style>

        body {
            font-family: Arial;
            background: #f4f6f8;
            padding: 40px;
        }

        .contenedor {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,.15);
        }

        h1 {
            margin-top: 0;
        }

        label {
            display: block;
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 5px;
        }

        input {
            width: 100%;
            padding: 11px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button,
        a {
            display: inline-block;
            margin-top: 25px;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        button {
            background: #198754;
            color: white;
        }

        a {
            background: #6c757d;
            color: white;
        }

    </style>

</head>

<body>

<div class="contenedor">

    <h1>✏️ Editar artículo</h1>

    <form method="POST">

        <label>Código</label>

        <input
            type="text"
            name="codigo"
            value="<?= htmlspecialchars($producto["codigo"]) ?>"
            required
        >

        <label>Artículo / Descripción</label>

        <input
            type="text"
            name="articulo_descripcion"
            value="<?= htmlspecialchars($producto["articulo_descripcion"]) ?>"
            required
        >

        <label>Cantidad</label>

        <input
            type="number"
            name="cantidad"
            value="<?= $producto["cantidad"] ?>"
        >

        <label>Ubicación</label>

        <input
            type="text"
            name="ubicacion"
            value="<?= htmlspecialchars($producto["ubicacion"]) ?>"
        >

        <label>Máximo</label>

        <input
            type="number"
            name="maximo"
            value="<?= $producto["maximo"] ?>"
        >

        <label>Mínimo</label>

        <input
            type="number"
            name="minimo"
            value="<?= $producto["minimo"] ?>"
        >

        <label>Proveedor / Marca</label>

        <input
            type="text"
            name="proveedor_marca"
            value="<?= htmlspecialchars($producto["proveedor_marca"]) ?>"
        >

        <button type="submit">
            💾 Guardar cambios
        </button>

        <a href="index.php">
            Cancelar
        </a>

    </form>

</div>

</body>

</html>
