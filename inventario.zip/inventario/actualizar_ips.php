<?php

require_once __DIR__ . '/config.php';

$tablaLogs = 'logs';

/*
|--------------------------------------------------------------------------
| Función para determinar si una IP es pública
|--------------------------------------------------------------------------
*/

function esIpPublica(string $ip): bool
{
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return false;
    }

    return filter_var(
        $ip,
        FILTER_VALIDATE_IP,
         FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
    ) !== false;
}


/*
|--------------------------------------------------------------------------
| Consultar IP en ipapi.co
|--------------------------------------------------------------------------
*/

function consultarIpApi(string $ip): array
{
    $url = 'https://ipapi.co/' . rawurlencode($ip) . '/json/';

    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json'
        ],
        CURLOPT_USERAGENT => 'SistemaAuditoria/1.0'
    ]);

    $respuesta = curl_exec($ch);

    if ($respuesta === false) {
        $error = curl_error($ch);
        curl_close($ch);

        return [
            'ok' => false,
            'mensaje' => $error
        ];
    }

    $codigoHttp = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($codigoHttp < 200 || $codigoHttp >= 300) {
        return [
            'ok' => false,
            'mensaje' => 'HTTP ' . $codigoHttp
        ];
    }

    $datos = json_decode($respuesta, true);

    if (!is_array($datos)) {
        return [
            'ok' => false,
            'mensaje' => 'Respuesta JSON inválida'
        ];
    }

    if (!empty($datos['error'])) {
        return [
            'ok' => false,
            'mensaje' => $datos['reason'] ?? 'Error de geolocalización'
        ];
    }

    return [
        'ok' => true,
        'datos' => $datos
    ];
}


/*
|--------------------------------------------------------------------------
| Obtener IPs únicas
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT DISTINCT ip
    FROM {$tablaLogs}
    WHERE ip IS NOT NULL
      AND ip <> ''
";

$stmt = $pdo->query($sql);

$ips = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo "IPs encontradas: " . count($ips) . PHP_EOL;


/*
|--------------------------------------------------------------------------
| Preparar INSERT/UPDATE
|--------------------------------------------------------------------------
*/

$sqlGuardar = "
    INSERT INTO ip_geolocalizacion (
        ip,
        ciudad,
        region,
        pais,
        codigo_pais,
        codigo_postal,
        latitud,
        longitud,
        zona_horaria,
        asn,
        organizacion,
        proveedor,
        estado,
        mensaje
    )
    VALUES (
        :ip,
        :ciudad,
        :region,
        :pais,
        :codigo_pais,
        :codigo_postal,
        :latitud,
        :longitud,
        :zona_horaria,
        :asn,
        :organizacion,
        :proveedor,
        :estado,
        :mensaje
    )
    ON DUPLICATE KEY UPDATE
        ciudad = VALUES(ciudad),
        region = VALUES(region),
        pais = VALUES(pais),
        codigo_pais = VALUES(codigo_pais),
        codigo_postal = VALUES(codigo_postal),
        latitud = VALUES(latitud),
        longitud = VALUES(longitud),
        zona_horaria = VALUES(zona_horaria),
        asn = VALUES(asn),
        organizacion = VALUES(organizacion),
        proveedor = VALUES(proveedor),
        estado = VALUES(estado),
        mensaje = VALUES(mensaje),
        actualizado_en = CURRENT_TIMESTAMP
";

$guardar = $pdo->prepare($sqlGuardar);


/*
|--------------------------------------------------------------------------
| Procesar IPs
|--------------------------------------------------------------------------
*/

foreach ($ips as $ip) {

    $ip = trim($ip);

    echo "Procesando: {$ip} ... ";

    /*
     * IP local o privada
     */

    if (!esIpPublica($ip)) {

        $guardar->execute([
            ':ip' => $ip,
            ':ciudad' => null,
            ':region' => null,
            ':pais' => null,
            ':codigo_pais' => null,
            ':codigo_postal' => null,
            ':latitud' => null,
            ':longitud' => null,
            ':zona_horaria' => null,
            ':asn' => null,
            ':organizacion' => null,
            ':proveedor' => null,
            ':estado' => 'privada',
            ':mensaje' => 'IP local, privada o reservada'
        ]);

        echo "IP privada/local" . PHP_EOL;

        continue;
    }


    /*
     * Revisar si ya existe
     *
     * Si ya fue consultada, no volvemos a llamar a la API.
     */

    $check = $pdo->prepare("
        SELECT id
        FROM ip_geolocalizacion
        WHERE ip = ?
        LIMIT 1
    ");

    $check->execute([$ip]);

    if ($check->fetch()) {

        echo "ya existe" . PHP_EOL;

        continue;
    }


    /*
     * Consultar API
     */

    $resultado = consultarIpApi($ip);

    if (!$resultado['ok']) {

        $guardar->execute([
            ':ip' => $ip,
            ':ciudad' => null,
            ':region' => null,
            ':pais' => null,
            ':codigo_pais' => null,
            ':codigo_postal' => null,
            ':latitud' => null,
            ':longitud' => null,
            ':zona_horaria' => null,
            ':asn' => null,
            ':organizacion' => null,
            ':proveedor' => null,
            ':estado' => 'error',
            ':mensaje' => $resultado['mensaje']
        ]);

        echo "ERROR: " . $resultado['mensaje'] . PHP_EOL;

        sleep(1);

        continue;
    }


    /*
     * Datos obtenidos
     */

    $d = $resultado['datos'];

    $guardar->execute([
        ':ip' => $ip,
        ':ciudad' => $d['city'] ?? null,
        ':region' => $d['region'] ?? null,
        ':pais' => $d['country_name'] ?? null,
        ':codigo_pais' => $d['country_code'] ?? null,
        ':codigo_postal' => $d['postal'] ?? null,
        ':latitud' => $d['latitude'] ?? null,
        ':longitud' => $d['longitude'] ?? null,
        ':zona_horaria' => $d['timezone'] ?? null,
        ':asn' => $d['asn'] ?? null,
        ':organizacion' => $d['org'] ?? null,
        ':proveedor' => $d['org'] ?? null,
        ':estado' => 'ok',
        ':mensaje' => null
    ]);

    echo "OK" . PHP_EOL;

    /*
     * Pausa para evitar demasiadas consultas
     */

    sleep(1);
}

echo PHP_EOL;
echo "Proceso terminado." . PHP_EOL;
