<?php

// ==========================================
// SEGURIDAD
// ==========================================

require_once __DIR__ . '/seguridad.php';

verificar_sesion();


// ==========================================
// DATOS DEL USUARIO
// ==========================================

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';

$rol_usuario = strtoupper(
    trim($_SESSION['rol'] ?? 'USUARIO')
);


// ==========================================
// PÁGINA ACTUAL
// ==========================================

$pagina_actual = basename(
    $_SERVER['PHP_SELF']
);


// ==========================================
// FUNCIÓN PARA MARCAR PÁGINA ACTIVA
// ==========================================

function menu_activo($pagina)
{
    global $pagina_actual;

    return $pagina_actual === $pagina
        ? 'activo'
        : '';
}

?>

<style>

/* ==========================================
   CONFIGURACIÓN DEL MENÚ
========================================== */

/*
   IMPORTANTE:
   El box-sizing solamente se aplica
   al menú y sus elementos.

   NO se aplica a toda la página.
*/

.barra-lateral,
.barra-lateral * {

    box-sizing: border-box;

}


/* ==========================================
   BARRA LATERAL
========================================== */

.barra-lateral {

    position: fixed;

    top: 0;
    left: 0;
    bottom: 0;

    width: 240px;

    background: #212529;

    color: white;

    z-index: 1000;

    overflow-y: auto;

    box-shadow: 2px 0 8px rgba(0,0,0,.20);

}


/* ==========================================
   ENCABEZADO DEL MENÚ
========================================== */

.logo-menu {

    padding: 22px 18px;

    border-bottom: 1px solid #343a40;

    font-size: 18px;

    font-weight: bold;

    text-align: center;

}


.subtitulo-menu {

    font-size: 11px;

    font-weight: normal;

    color: #adb5bd;

    margin-top: 5px;

}


/* ==========================================
   NAVEGACIÓN
========================================== */

.menu-navegacion {

    padding: 12px 0;

    padding-bottom: 180px;

}


.menu-navegacion a {

    display: block;

    color: #ffffff;

    text-decoration: none;

    padding: 14px 20px;

    font-size: 14px;

    border-left: 4px solid transparent;

    transition:
        background .2s,
        border-color .2s;

}


.menu-navegacion a:hover {

    background: #343a40;

    border-left-color: #0d6efd;

}


.menu-navegacion a.activo {

    background: #343a40;

    border-left-color: #0d6efd;

    font-weight: bold;

}


/* ==========================================
   SEPARADOR
========================================== */

.menu-separador {

    height: 1px;

    background: #343a40;

    margin: 8px 15px;

}


/* ==========================================
   INFORMACIÓN DEL USUARIO
========================================== */

.usuario-menu {

    position: absolute;

    bottom: 0;

    left: 0;

    right: 0;

    padding: 15px;

    border-top: 1px solid #343a40;

    background: #1c1f22;

}


.usuario-nombre {

    font-size: 13px;

    font-weight: bold;

    color: #ffffff;

    margin-bottom: 4px;

    word-break: break-word;

}


.usuario-rol {

    font-size: 11px;

    color: #adb5bd;

    margin-bottom: 12px;

}


/* ==========================================
   BOTÓN SALIR
========================================== */

.boton-salir {

    display: block;

    width: 100%;

    padding: 9px;

    background: #dc3545;

    color: white;

    text-decoration: none;

    text-align: center;

    border-radius: 5px;

    font-size: 13px;

}


.boton-salir:hover {

    background: #bb2d3b;

}


/* ==========================================
   RESPONSIVE
========================================== */

@media (max-width: 850px) {

    .barra-lateral {

        width: 210px;

    }

}


@media (max-width: 650px) {

    .barra-lateral {

        position: relative;

        width: 100%;

        height: auto;

        min-height: auto;

    }


    .usuario-menu {

        position: relative;

        margin-top: 10px;

    }


    .menu-navegacion {

        padding-bottom: 10px;

    }

}

</style>


<!-- ==========================================
     BARRA LATERAL
========================================== -->

<aside class="barra-lateral">


    <!-- ======================================
         ENCABEZADO
    ======================================= -->

    <div class="logo-menu">

        📦 Sistema de Almacén

        <div class="subtitulo-menu">

            Grupo Protec

        </div>

    </div>


    <!-- ======================================
         MENÚ
    ======================================= -->

    <nav class="menu-navegacion">


        <!-- ==================================
             ADMIN
             ACCESO COMPLETO
        =================================== -->

        <?php if ($rol_usuario === 'ADMIN'): ?>


            <a
                href="admin_panel.php"
                class="<?= menu_activo('admin_panel.php') ?>"
            >

                ⚙️ &nbsp; Panel administrativo

            </a>


            <div class="menu-separador"></div>


            <a
                href="index.php"
                class="<?= menu_activo('index.php') ?>"
            >

                🏠 &nbsp; Inventario

            </a>


            <a
                href="nuevo_articulo.php"
                class="<?= menu_activo('nuevo_articulo.php') ?>"
            >

                ➕ &nbsp; Nuevo artículo

            </a>


            <a
                href="entrada.php"
                class="<?= menu_activo('entrada.php') ?>"
            >

                📥 &nbsp; Entrada de almacén

            </a>


            <a
                href="salida.php"
                class="<?= menu_activo('salida.php') ?>"
            >

                📤 &nbsp; Salida de almacén

            </a>


            <a
                href="historial_movimientos.php"
                class="<?= menu_activo('historial_movimientos.php') ?>"
            >

                📋 &nbsp; Historial de movimientos

            </a>


            <a
                href="facturas.php"
                class="<?= menu_activo('facturas.php') ?>"
            >

                🧾 &nbsp; Facturas

            </a>


            <!-- ==============================
                 INVENTARIO FÍSICO
            =============================== -->

            <a
                href="inventario_fisico.php"
                class="<?= menu_activo('inventario_fisico.php') ?>"
            >

                📋 &nbsp; Inventario físico

            </a>


            <div class="menu-separador"></div>


            <a
                href="empleados_areas.php"
                class="<?= menu_activo('empleados_areas.php') ?>"
            >

                👥 &nbsp; Empleados y áreas

            </a>


            <a
                href="usuarios.php"
                class="<?= menu_activo('usuarios.php') ?>"
            >

                👤 &nbsp; Usuarios

            </a>


            <a
                href="auditoria_sistema.php"
                class="<?= menu_activo('auditoria_sistema.php') ?>"
            >

                🔍 &nbsp; Auditoría del sistema

            </a>


        <!-- ==================================
             GERENCIA
        =================================== -->

        <?php elseif ($rol_usuario === 'GERENCIA'): ?>


            <a
                href="panel.php"
                class="<?= menu_activo('panel.php') ?>"
            >

                📊 &nbsp; Panel de gerencia

            </a>


            <a
                href="inventario.php"
                class="<?= menu_activo('inventario.php') ?>"
            >

                📦 &nbsp; Inventario

            </a>


            <a
                href="historial_movimientos.php"
                class="<?= menu_activo('historial_movimientos.php') ?>"
            >

                📋 &nbsp; Historial de movimientos

            </a>


            <a
                href="facturas.php"
                class="<?= menu_activo('facturas.php') ?>"
            >

                🧾 &nbsp; Facturas

            </a>


            <a
                href="auditoria_sistema.php"
                class="<?= menu_activo('auditoria_sistema.php') ?>"
            >

                🔍 &nbsp; Auditoría del sistema

            </a>


            <a
                href="usuarios.php"
                class="<?= menu_activo('usuarios.php') ?>"
            >

                👤 &nbsp; Usuarios

            </a>


        <!-- ==================================
             USUARIO
        =================================== -->

        <?php elseif ($rol_usuario === 'USUARIO'): ?>


            <a
                href="index.php"
                class="<?= menu_activo('index.php') ?>"
            >

                🏠 &nbsp; Inventario

            </a>


            <a
                href="nuevo_articulo.php"
                class="<?= menu_activo('nuevo_articulo.php') ?>"
            >

                ➕ &nbsp; Nuevo artículo

            </a>


            <a
                href="entrada.php"
                class="<?= menu_activo('entrada.php') ?>"
            >

                📥 &nbsp; Entrada de almacén

            </a>


            <a
                href="salida.php"
                class="<?= menu_activo('salida.php') ?>"
            >

                📤 &nbsp; Salida de almacén

            </a>


            <a
                href="historial_movimientos.php"
                class="<?= menu_activo('historial_movimientos.php') ?>"
            >

                📋 &nbsp; Historial de movimientos

            </a>


            <a
                href="facturas.php"
                class="<?= menu_activo('facturas.php') ?>"
            >

                🧾 &nbsp; Facturas

            </a>


            <!-- ==============================
                 INVENTARIO FÍSICO
                 SOLO ADMIN Y USUARIO
            =============================== -->

            <a
                href="inventario_fisico.php"
                class="<?= menu_activo('inventario_fisico.php') ?>"
            >

                📋 &nbsp; Inventario físico

            </a>


        <!-- ==================================
             CONSULTA
        =================================== -->

        <?php elseif ($rol_usuario === 'CONSULTA'): ?>


            <a
                href="inventario.php"
                class="<?= menu_activo('inventario.php') ?>"
            >

                📦 &nbsp; Inventario

            </a>


            <a
                href="historial_movimientos.php"
                class="<?= menu_activo('historial_movimientos.php') ?>"
            >

                📋 &nbsp; Historial de movimientos

            </a>


            <a
                href="facturas.php"
                class="<?= menu_activo('facturas.php') ?>"
            >

                🧾 &nbsp; Facturas

            </a>


        <?php endif; ?>


    </nav>


    <!-- ======================================
         INFORMACIÓN DEL USUARIO
    ======================================= -->

    <div class="usuario-menu">


        <div class="usuario-nombre">

            👤

            <?= htmlspecialchars(
                $nombre_empleado,
                ENT_QUOTES,
                'UTF-8'
            ) ?>

        </div>


        <div class="usuario-rol">

            <?= htmlspecialchars(
                $rol_usuario,
                ENT_QUOTES,
                'UTF-8'
            ) ?>

        </div>


        <a
            href="logout.php"
            class="boton-salir"
        >

            🚪 Salir

        </a>


    </div>


</aside>