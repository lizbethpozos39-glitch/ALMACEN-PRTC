<?php

// ==========================================
// SEGURIDAD Y CONEXIÓN
// ==========================================

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();


// ==========================================
// DATOS DEL USUARIO
// ==========================================

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';
$rol_usuario     = $_SESSION['rol'] ?? 'USUARIO';


// ==========================================
// FILTROS
// ==========================================

$descripcion = $_GET["descripcion"] ?? "";
$cantidad    = $_GET["cantidad"] ?? "";
$ubicacion   = $_GET["ubicacion"] ?? "";
$maximo      = $_GET["maximo"] ?? "";
$minimo      = $_GET["minimo"] ?? "";
$proveedor   = $_GET["proveedor"] ?? "";


// ==========================================
// CONSULTA
// ==========================================

$sql = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        ubicacion,
        maximo,
        minimo,
        proveedor_marca
    FROM inventario
    WHERE 1=1
";

$parametros = [];
$tipos = "";


// ==========================================
// DESCRIPCIÓN
// ==========================================

if ($descripcion !== "") {

    $sql .= " AND articulo_descripcion LIKE ?";

    $parametros[] = "%$descripcion%";
    $tipos .= "s";
}


// ==========================================
// CANTIDAD
// ==========================================

if ($cantidad !== "") {

    $sql .= " AND cantidad = ?";

    $parametros[] = $cantidad;
    $tipos .= "i";
}


// ==========================================
// UBICACIÓN
// ==========================================

if ($ubicacion !== "") {

    $sql .= " AND ubicacion LIKE ?";

    $parametros[] = "%$ubicacion%";
    $tipos .= "s";
}


// ==========================================
// MÁXIMO
// ==========================================

if ($maximo !== "") {

    $sql .= " AND maximo = ?";

    $parametros[] = $maximo;
    $tipos .= "i";
}


// ==========================================
// MÍNIMO
// ==========================================

if ($minimo !== "") {

    $sql .= " AND minimo = ?";

    $parametros[] = $minimo;
    $tipos .= "i";
}


// ==========================================
// PROVEEDOR / MARCA
// ==========================================

if ($proveedor !== "") {

    $sql .= " AND proveedor_marca LIKE ?";

    $parametros[] = "%$proveedor%";
    $tipos .= "s";
}


// ==========================================
// ORDEN
// ==========================================

$sql .= " ORDER BY id DESC";


// ==========================================
// PREPARAR CONSULTA
// ==========================================

$stmt = $conexion->prepare($sql);

if (!$stmt) {

    die("Error al preparar la consulta: " . $conexion->error);

}


// ==========================================
// PARÁMETROS
// ==========================================

if (!empty($parametros)) {

    $stmt->bind_param(
        $tipos,
        ...$parametros
    );

}


// ==========================================
// EJECUTAR
// ==========================================

$stmt->execute();

$resultado = $stmt->get_result();

?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Sistema de Almacén</title>


    <style>

        /* ==========================================
           CONFIGURACIÓN GENERAL
        =========================================== */

        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            color: #333;
        }


        /* ==========================================
           BARRA LATERAL FIJA
        =========================================== */

        .barra-lateral {

            position: fixed;

            top: 0;
            left: 0;
            bottom: 0;

            width: 240px;

            background: #212529;

            color: white;

            z-index: 1000;

            overflow-y: auto;

            box-shadow: 2px 0 8px rgba(0, 0, 0, .20);
        }


        /* ==========================================
           ENCABEZADO DEL MENÚ
        =========================================== */

        .logo-menu {

            padding: 22px 18px;

            border-bottom: 1px solid #343a40;

            font-size: 18px;

            font-weight: bold;

            text-align: center;
        }


        .subtitulo-menu {

            font-size: 11px;

            font-weight: normal;

            color: #adb5bd;

            margin-top: 5px;
        }


        /* ==========================================
           OPCIONES DEL MENÚ
        =========================================== */

        .menu-navegacion {

            padding: 12px 0;
        }


        .menu-navegacion a {

            display: block;

            color: #ffffff;

            text-decoration: none;

            padding: 14px 20px;

            font-size: 14px;

            border-left: 4px solid transparent;

            transition: background .2s, border-color .2s;
        }


        .menu-navegacion a:hover {

            background: #343a40;

            border-left-color: #0d6efd;
        }


        .menu-navegacion a.activo {

            background: #343a40;

            border-left-color: #0d6efd;

            font-weight: bold;
        }


        /* ==========================================
           INFORMACIÓN USUARIO
        =========================================== */

        .usuario-menu {

            position: absolute;

            bottom: 0;
            left: 0;
            right: 0;

            padding: 15px;

            border-top: 1px solid #343a40;

            background: #1c1f22;
        }


        .usuario-nombre {

            font-size: 13px;

            font-weight: bold;

            color: #ffffff;

            margin-bottom: 4px;

            word-break: break-word;
        }


        .usuario-rol {

            font-size: 11px;

            color: #adb5bd;

            margin-bottom: 12px;
        }


        /* ==========================================
           BOTÓN SALIR
        =========================================== */

        .boton-salir {

            display: block;

            width: 100%;

            padding: 9px;

            background: #dc3545;

            color: white;

            text-decoration: none;

            text-align: center;

            border-radius: 5px;

            font-size: 13px;

        }


        .boton-salir:hover {

            background: #bb2d3b;

        }


        /* ==========================================
           CONTENIDO PRINCIPAL
        =========================================== */

        .contenido-principal {

            margin-left: 240px;

            min-height: 100vh;

            padding: 0;
        }


        /* ==========================================
           BARRA SUPERIOR
        =========================================== */

        .barra-superior {

            height: 70px;

            background: #ffffff;

            border-bottom: 1px solid #ddd;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 30px;

            box-shadow: 0 1px 5px rgba(0,0,0,.08);
        }


        .titulo-superior {

            font-size: 20px;

            font-weight: bold;

            color: #212529;
        }


        .usuario-superior {

            font-size: 13px;

            color: #555;
        }


        /* ==========================================
           CONTENEDOR
        =========================================== */

        .contenedor {

            width: 95%;

            max-width: 1400px;

            margin: 30px auto;
        }


        h1 {

            margin-top: 0;

            margin-bottom: 20px;

            color: #212529;
        }


        /* ==========================================
           FILTROS
        =========================================== */

        .filtros {

            background: white;

            padding: 20px;

            border-radius: 10px;

            box-shadow: 0 2px 8px rgba(0,0,0,.10);

            margin-bottom: 20px;
        }


        .filtros-grid {

            display: grid;

            grid-template-columns:
                repeat(auto-fit, minmax(180px, 1fr));

            gap: 12px;
        }


        .campo label {

            display: block;

            font-size: 13px;

            font-weight: bold;

            margin-bottom: 5px;
        }


        .campo input {

            width: 100%;

            padding: 10px;

            border: 1px solid #ccc;

            border-radius: 5px;

            font-size: 14px;
        }


        .campo input:focus {

            outline: none;

            border-color: #0d6efd;

            box-shadow: 0 0 0 2px rgba(13,110,253,.10);
        }


        /* ==========================================
           BOTONES
        =========================================== */

        .botones {

            margin-top: 15px;

            display: flex;

            gap: 10px;

            flex-wrap: wrap;
        }


        button,
        .boton {

            padding: 10px 18px;

            border: none;

            border-radius: 5px;

            cursor: pointer;

            text-decoration: none;

            display: inline-block;

            font-size: 14px;
        }


        .buscar {

            background: #007bff;

            color: white;
        }


        .buscar:hover {

            background: #0069d9;
        }


        .limpiar {

            background: #6c757d;

            color: white;
        }


        .limpiar:hover {

            background: #5a6268;
        }


        .importar {

            background: #198754;

            color: white;
        }


        .importar:hover {

            background: #157347;
        }


        /* ==========================================
           TABLA
        =========================================== */

        .tabla-contenedor {

            background: white;

            border-radius: 10px;

            overflow-x: auto;

            box-shadow: 0 2px 8px rgba(0,0,0,.10);
        }


        table {

            width: 100%;

            border-collapse: collapse;

            min-width: 1000px;
        }


        th {

            background: #212529;

            color: white;

            padding: 12px;

            text-align: left;

            font-size: 13px;
        }


        td {

            padding: 10px;

            border-bottom: 1px solid #ddd;

            font-size: 13px;
        }


        tr:hover {

            background: #f8f9fa;
        }


        /* ==========================================
           CANTIDADES
        =========================================== */

        .bajo {

            background: #ffe0e0;

            color: #b00000;

            font-weight: bold;
        }


        .normal {

            background: #e0ffe7;

            color: #08752a;
        }


        /* ==========================================
           ACCIONES
        =========================================== */

        .acciones {

            white-space: nowrap;
        }


        .editar {

            background: #ffc107;

            color: #000;
        }


        .editar:hover {

            background: #e0a800;
        }


        .eliminar {

            background: #dc3545;

            color: white;
        }


        .eliminar:hover {

            background: #bb2d3b;
        }


        /* ==========================================
           SIN REGISTROS
        =========================================== */

        .sin-registros {

            text-align: center;

            padding: 30px;

            color: #777;
        }


        /* ==========================================
           FOOTER
        =========================================== */

        .footer {

            width: 100%;

            margin-top: 40px;

            padding: 20px;

            text-align: center;

            color: #6c757d;

            font-size: 13px;

            border-top: 1px solid #ddd;

            background: #ffffff;
        }


        /* ==========================================
           RESPONSIVE
        =========================================== */

        @media (max-width: 850px) {

            .barra-lateral {

                width: 210px;
            }


            .contenido-principal {

                margin-left: 210px;
            }


            .barra-superior {

                padding: 0 20px;
            }

        }


        @media (max-width: 650px) {

            .barra-lateral {

                position: relative;

                width: 100%;

                height: auto;

                min-height: auto;
            }


            .usuario-menu {

                position: relative;

                margin-top: 10px;
            }


            .contenido-principal {

                margin-left: 0;
            }


            .barra-superior {

                height: auto;

                padding: 15px;

                flex-direction: column;

                align-items: flex-start;

                gap: 8px;
            }


            .contenedor {

                width: 92%;

                margin: 20px auto;
            }

        }

    </style>

</head>


<body>


<!-- ==========================================
     BARRA LATERAL FIJA
========================================== -->

<aside class="barra-lateral">


    <!-- ENCABEZADO -->

    <div class="logo-menu">

        📦 Sistema de Almacén

        <div class="subtitulo-menu">

            Grupo Protec

        </div>

    </div>


    <!-- MENÚ -->

    <nav class="menu-navegacion">


        <a
            href="index.php"
            class="activo"
        >

            🏠 &nbsp; Inventario

        </a>


        <a href="nuevo_articulo.php">

            ➕ &nbsp; Nuevo artículo

        </a>


        <a href="entrada.php">

            📥 &nbsp; Entrada de almacén

        </a>


        <a href="salida.php">

            📤 &nbsp; Salida de almacén

        </a>


        <a href="historial_movimientos.php">

            📋 &nbsp; Historial de movimientos

        </a>


        <a href="facturas.php">

            🧾 &nbsp; Facturas

        </a>


    </nav>


    <!-- USUARIO -->

    <div class="usuario-menu">


        <div class="usuario-nombre">

            👤 <?= htmlspecialchars($nombre_empleado) ?>

        </div>


        <div class="usuario-rol">

            <?= htmlspecialchars($rol_usuario) ?>

        </div>


        <a
            href="logout.php"
            class="boton-salir"
        >

            🚪 Salir

        </a>


    </div>


</aside>


<!-- ==========================================
     CONTENIDO PRINCIPAL
========================================== -->

<main class="contenido-principal">


    <!-- ======================================
         BARRA SUPERIOR
    ======================================= -->

    <header class="barra-superior">


        <div class="titulo-superior">

            📦 Inventario

        </div>


        <div class="usuario-superior">

            Usuario:
            <strong>
                <?= htmlspecialchars($nombre_empleado) ?>
            </strong>

        </div>


    </header>


    <!-- ======================================
         CONTENIDO
    ======================================= -->

    <div class="contenedor">


        <!-- ==================================
             FILTROS
        =================================== -->

        <div class="filtros">


            <form method="GET">


                <div class="filtros-grid">


                    <!-- DESCRIPCIÓN -->

                    <div class="campo">

                        <label>

                            Artículo / Descripción

                        </label>


                        <input
                            type="text"
                            name="descripcion"
                            value="<?= htmlspecialchars($descripcion) ?>"
                            placeholder="Ej. abanico"
                        >

                    </div>


                    <!-- CANTIDAD -->

                    <div class="campo">

                        <label>

                            Cantidad

                        </label>


                        <input
                            type="number"
                            name="cantidad"
                            value="<?= htmlspecialchars($cantidad) ?>"
                            placeholder="Cantidad"
                        >

                    </div>


                    <!-- UBICACIÓN -->

                    <div class="campo">

                        <label>

                            Ubicación

                        </label>


                        <input
                            type="text"
                            name="ubicacion"
                            value="<?= htmlspecialchars($ubicacion) ?>"
                            placeholder="Ej. A-01"
                        >

                    </div>


                    <!-- MÁXIMO -->

                    <div class="campo">

                        <label>

                            Máximo

                        </label>


                        <input
                            type="number"
                            name="maximo"
                            value="<?= htmlspecialchars($maximo) ?>"
                        >

                    </div>


                    <!-- MÍNIMO -->

                    <div class="campo">

                        <label>

                            Mínimo

                        </label>


                        <input
                            type="number"
                            name="minimo"
                            value="<?= htmlspecialchars($minimo) ?>"
                        >

                    </div>


                    <!-- PROVEEDOR -->

                    <div class="campo">

                        <label>

                            Proveedor / Marca

                        </label>


                        <input
                            type="text"
                            name="proveedor"
                            value="<?= htmlspecialchars($proveedor) ?>"
                            placeholder="Proveedor o marca"
                        >

                    </div>


                </div>


                <!-- BOTONES -->

                <div class="botones">


                    <button
                        type="submit"
                        class="buscar"
                    >

                        🔎 Buscar

                    </button>


                    <a
                        href="index.php"
                        class="boton limpiar"
                    >

                        🔄 Limpiar

                    </a>


                    <a
                        href="importar.php"
                        class="boton importar"
                    >

                        📥 Importar Excel

                    </a>


                </div>


            </form>


        </div>


        <!-- ==================================
             TABLA
        =================================== -->

        <div class="tabla-contenedor">


            <table>


                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Código</th>

                        <th>Descripción</th>

                        <th>Cantidad</th>

                        <th>Ubicación</th>

                        <th>Máximo</th>

                        <th>Mínimo</th>

                        <th>Proveedor / Marca</th>

                        <th>Acciones</th>

                    </tr>

                </thead>


                <tbody>


                <?php if ($resultado->num_rows > 0): ?>


                    <?php while ($producto = $resultado->fetch_assoc()): ?>


                        <tr>


                            <td>

                                <?= $producto["id"] ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $producto["codigo"]
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $producto["articulo_descripcion"]
                                ) ?>

                            </td>


                            <td class="<?=

                                $producto["cantidad"]
                                <= $producto["minimo"]

                                ? "bajo"
                                : "normal"

                            ?>">

                                <?= $producto["cantidad"] ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $producto["ubicacion"]
                                ) ?>

                            </td>


                            <td>

                                <?= $producto["maximo"] ?>

                            </td>


                            <td>

                                <?= $producto["minimo"] ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $producto["proveedor_marca"]
                                ) ?>

                            </td>


                            <td class="acciones">


                                <a
                                    class="boton editar"
                                    href="editar.php?id=<?= $producto["id"] ?>"
                                >

                                    ✏️ Editar

                                </a>


                                <a
                                    class="boton eliminar"
                                    href="eliminar.php?id=<?= $producto["id"] ?>"
                                    onclick="return confirm(
                                        '¿Seguro que deseas eliminar este artículo?'
                                    );"
                                >

                                    🗑️ Eliminar

                                </a>


                            </td>


                        </tr>


                    <?php endwhile; ?>


                <?php else: ?>


                    <tr>

                        <td
                            colspan="9"
                            class="sin-registros"
                        >

                            No se encontraron productos.

                        </td>

                    </tr>


                <?php endif; ?>


                </tbody>


            </table>


        </div>


        <!-- ==================================
             FOOTER
        =================================== -->

        <footer class="footer">

            © <?= date("Y") ?>

            Sistema de Inventario

            |

            Desarrollado por

            <strong>Ing. Lizbeth Pozos Yañez</strong>

            |

            <strong>Grupo Protec</strong>

        </footer>


    </div>


</main>


<?php

// ==========================================
// CERRAR CONEXIÓN
// ==========================================

$stmt->close();

$conexion->close();

?>


</body>

</html>