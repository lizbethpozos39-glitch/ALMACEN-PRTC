<?php
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

require_once __DIR__ . '/conexion.php';

$mensaje = "";
$tipo_mensaje = "success";

/* =========================================================
   PROCESAR ACCIONES
========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $accion = $_POST["accion"] ?? "";

    /* =====================================================
       CREAR ÁREA
    ===================================================== */
    if ($accion === "crear_area") {

        $nombre = trim($_POST["nombre_area"] ?? "");

        if ($nombre === "") {

            $mensaje = "El nombre del área es obligatorio.";
            $tipo_mensaje = "danger";

        } else {

            $stmt = $conexion->prepare("
                INSERT INTO areas (nombre)
                VALUES (?)
            ");

            $stmt->bind_param("s", $nombre);

            if ($stmt->execute()) {

                $mensaje = "Área creada correctamente.";

            } else {

                if ($conexion->errno == 1062) {
                    $mensaje = "El área ya existe.";
                } else {
                    $mensaje = "Error al crear el área: " . $conexion->error;
                }

                $tipo_mensaje = "danger";
            }

            $stmt->close();
        }
    }


    /* =====================================================
       ACTIVAR / DESACTIVAR ÁREA
    ===================================================== */
    elseif ($accion === "toggle_area") {

        $area_id = intval($_POST["area_id"] ?? 0);

        if ($area_id > 0) {

            $stmt = $conexion->prepare("
                UPDATE areas
                SET activo = IF(activo = 1, 0, 1)
                WHERE id = ?
            ");

            $stmt->bind_param("i", $area_id);

            if ($stmt->execute()) {
                $mensaje = "Estado del área actualizado.";
            } else {
                $mensaje = "No fue posible actualizar el área.";
                $tipo_mensaje = "danger";
            }

            $stmt->close();
        }
    }


    /* =====================================================
       CREAR EMPLEADO
    ===================================================== */
    elseif ($accion === "crear_empleado") {

        $nombre = trim($_POST["nombre"] ?? "");
        $numero_empleado = trim($_POST["numero_empleado"] ?? "");
        $area_id = intval($_POST["area_id"] ?? 0);
        $puesto = trim($_POST["puesto"] ?? "");

        if ($nombre === "") {

            $mensaje = "El nombre del empleado es obligatorio.";
            $tipo_mensaje = "danger";

        } elseif ($area_id <= 0) {

            $mensaje = "Debes seleccionar un área.";
            $tipo_mensaje = "danger";

        } else {

            /* Verificar que el área exista y esté activa */
            $stmt_area = $conexion->prepare("
                SELECT id
                FROM areas
                WHERE id = ?
                AND activo = 1
            ");

            $stmt_area->bind_param("i", $area_id);
            $stmt_area->execute();

            $resultado_area = $stmt_area->get_result();

            if ($resultado_area->num_rows === 0) {

                $mensaje = "El área seleccionada no está disponible.";
                $tipo_mensaje = "danger";

            } else {

                $stmt = $conexion->prepare("
                    INSERT INTO empleados
                    (
                        nombre,
                        numero_empleado,
                        area_id,
                        puesto
                    )
                    VALUES (?, ?, ?, ?)
                ");

                $stmt->bind_param(
                    "ssis",
                    $nombre,
                    $numero_empleado,
                    $area_id,
                    $puesto
                );

                if ($stmt->execute()) {

                    $mensaje = "Empleado registrado correctamente.";

                } else {

                    $mensaje = "Error al registrar el empleado: " . $conexion->error;
                    $tipo_mensaje = "danger";
                }

                $stmt->close();
            }

            $stmt_area->close();
        }
    }


    /* =====================================================
       EDITAR EMPLEADO
    ===================================================== */
    elseif ($accion === "editar_empleado") {

        $empleado_id = intval($_POST["empleado_id"] ?? 0);
        $nombre = trim($_POST["nombre"] ?? "");
        $numero_empleado = trim($_POST["numero_empleado"] ?? "");
        $area_id = intval($_POST["area_id"] ?? 0);
        $puesto = trim($_POST["puesto"] ?? "");

        if ($empleado_id <= 0) {

            $mensaje = "Empleado no válido.";
            $tipo_mensaje = "danger";

        } elseif ($nombre === "") {

            $mensaje = "El nombre del empleado es obligatorio.";
            $tipo_mensaje = "danger";

        } elseif ($area_id <= 0) {

            $mensaje = "Debes seleccionar un área.";
            $tipo_mensaje = "danger";

        } else {

            $stmt = $conexion->prepare("
                UPDATE empleados
                SET
                    nombre = ?,
                    numero_empleado = ?,
                    area_id = ?,
                    puesto = ?
                WHERE id = ?
            ");

            $stmt->bind_param(
                "ssisi",
                $nombre,
                $numero_empleado,
                $area_id,
                $puesto,
                $empleado_id
            );

            if ($stmt->execute()) {

                $mensaje = "Empleado actualizado correctamente.";

            } else {

                $mensaje = "Error al actualizar el empleado: " . $conexion->error;
                $tipo_mensaje = "danger";
            }

            $stmt->close();
        }
    }


    /* =====================================================
       ACTIVAR / DESACTIVAR EMPLEADO
    ===================================================== */
    elseif ($accion === "toggle_empleado") {

        $empleado_id = intval($_POST["empleado_id"] ?? 0);

        if ($empleado_id > 0) {

            $stmt = $conexion->prepare("
                UPDATE empleados
                SET activo = IF(activo = 1, 0, 1)
                WHERE id = ?
            ");

            $stmt->bind_param("i", $empleado_id);

            if ($stmt->execute()) {

                $mensaje = "Estado del empleado actualizado.";

            } else {

                $mensaje = "No fue posible actualizar el empleado.";
                $tipo_mensaje = "danger";
            }

            $stmt->close();
        }
    }
}


/* =========================================================
   OBTENER ÁREAS
========================================================= */

$areas = [];

$resultado_areas = $conexion->query("
    SELECT
        a.id,
        a.nombre,
        a.activo,
        a.fecha_registro,
        COUNT(e.id) AS total_empleados
    FROM areas a
    LEFT JOIN empleados e
        ON e.area_id = a.id
    GROUP BY
        a.id,
        a.nombre,
        a.activo,
        a.fecha_registro
    ORDER BY
        a.activo DESC,
        a.nombre ASC
");

if ($resultado_areas) {

    while ($fila = $resultado_areas->fetch_assoc()) {
        $areas[] = $fila;
    }
}


/* =========================================================
   OBTENER EMPLEADOS
========================================================= */

$empleados = [];

$resultado_empleados = $conexion->query("
    SELECT
        e.id,
        e.nombre,
        e.numero_empleado,
        e.area_id,
        e.puesto,
        e.activo,
        e.fecha_registro,
        a.nombre AS area_nombre,
        a.activo AS area_activa
    FROM empleados e
    INNER JOIN areas a
        ON a.id = e.area_id
    ORDER BY
        e.activo DESC,
        a.nombre ASC,
        e.nombre ASC
");

if ($resultado_empleados) {

    while ($fila = $resultado_empleados->fetch_assoc()) {
        $empleados[] = $fila;
    }
}

?>

<?php require_once __DIR__ . '/header.php'; ?>


<style>

.contenedor-administracion {
    width: 100%;
}

.titulo-pagina {
    margin-bottom: 25px;
}

.titulo-pagina h1 {
    margin: 0 0 8px 0;
    color: #212529;
}

.titulo-pagina p {
    margin: 0;
    color: #6c757d;
}


/* =========================================================
   MENSAJES
========================================================= */

.mensaje {
    padding: 14px 18px;
    border-radius: 6px;
    margin-bottom: 20px;
    font-weight: bold;
}

.mensaje.success {
    background: #d1e7dd;
    color: #0f5132;
    border: 1px solid #badbcc;
}

.mensaje.danger {
    background: #f8d7da;
    color: #842029;
    border: 1px solid #f5c2c7;
}


/* =========================================================
   GRID PRINCIPAL
========================================================= */

.grid-superior {
    display: grid;
    grid-template-columns: 360px 1fr;
    gap: 25px;
    margin-bottom: 30px;
}

.tarjeta {
    background: white;
    border-radius: 10px;
    padding: 22px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.tarjeta h2 {
    margin-top: 0;
    margin-bottom: 18px;
    color: #212529;
    font-size: 20px;
}

.tarjeta h3 {
    margin-top: 0;
    color: #212529;
}


/* =========================================================
   FORMULARIOS
========================================================= */

.form-grupo {
    margin-bottom: 15px;
}

.form-grupo label {
    display: block;
    font-weight: bold;
    margin-bottom: 6px;
}

.form-grupo input,
.form-grupo select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ced4da;
    border-radius: 5px;
    font-size: 14px;
}

.form-grupo input:focus,
.form-grupo select:focus {
    outline: none;
    border-color: #495057;
    box-shadow: 0 0 0 2px rgba(73,80,87,.1);
}


/* =========================================================
   BOTONES
========================================================= */

.btn {
    border: none;
    border-radius: 5px;
    padding: 9px 14px;
    cursor: pointer;
    font-size: 14px;
    text-decoration: none;
    display: inline-block;
}

.btn-principal {
    background: #212529;
    color: white;
}

.btn-principal:hover {
    background: #343a40;
}

.btn-editar {
    background: #0d6efd;
    color: white;
}

.btn-editar:hover {
    background: #0b5ed7;
}

.btn-activo {
    background: #198754;
    color: white;
}

.btn-activo:hover {
    background: #157347;
}

.btn-inactivo {
    background: #dc3545;
    color: white;
}

.btn-inactivo:hover {
    background: #bb2d3b;
}

.btn-secundario {
    background: #6c757d;
    color: white;
}

.btn-secundario:hover {
    background: #5c636a;
}


/* =========================================================
   TABLAS
========================================================= */

.tabla-contenedor {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #212529;
    color: white;
    padding: 11px;
    text-align: left;
    font-size: 14px;
}

td {
    padding: 10px;
    border-bottom: 1px solid #dee2e6;
    font-size: 14px;
}

tr:hover {
    background: #f8f9fa;
}


/* =========================================================
   ESTADOS
========================================================= */

.estado {
    display: inline-block;
    padding: 4px 9px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.estado-activo {
    background: #d1e7dd;
    color: #0f5132;
}

.estado-inactivo {
    background: #f8d7da;
    color: #842029;
}


/* =========================================================
   CONTADORES
========================================================= */

.resumen-areas {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    margin-bottom: 20px;
}

.resumen-item {
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 7px;
    padding: 12px;
    text-align: center;
}

.resumen-item strong {
    display: block;
    font-size: 22px;
}

.resumen-item span {
    font-size: 12px;
    color: #6c757d;
}


/* =========================================================
   MODAL
========================================================= */

.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,.55);
    padding: 30px;
    overflow-y: auto;
}

.modal-contenido {
    background: white;
    max-width: 600px;
    margin: 40px auto;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 20px rgba(0,0,0,.25);
}

.modal-contenido h2 {
    margin-top: 0;
}

.modal-botones {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 20px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .grid-superior {
        grid-template-columns: 1fr;
    }

}

@media (max-width: 600px) {

    .resumen-areas {
        grid-template-columns: 1fr;
    }

    .modal {
        padding: 10px;
    }

}

</style>


<div class="contenedor-administracion">

    <div class="titulo-pagina">

        <h1>👥 Empleados y Áreas</h1>

        <p>
            Administración de las áreas y empleados que utilizará el sistema de salidas de almacén.
        </p>

    </div>


    <?php if ($mensaje !== ""): ?>

        <div class="mensaje <?= htmlspecialchars($tipo_mensaje) ?>">

            <?= htmlspecialchars($mensaje) ?>

        </div>

    <?php endif; ?>


    <div class="grid-superior">


        <!-- =================================================
             ÁREAS
        ================================================== -->

        <div class="tarjeta">

            <h2>🏢 Nueva Área</h2>

            <form method="POST">

                <input
                    type="hidden"
                    name="accion"
                    value="crear_area"
                >

                <div class="form-grupo">

                    <label for="nombre_area">
                        Nombre del área
                    </label>

                    <input
                        type="text"
                        name="nombre_area"
                        id="nombre_area"
                        maxlength="150"
                        placeholder="Ej. Alarmas"
                        required
                    >

                </div>

                <button
                    type="submit"
                    class="btn btn-principal"
                >
                    ➕ Crear área
                </button>

            </form>

            <hr style="margin:25px 0;">


            <h3>Áreas registradas</h3>

            <div class="tabla-contenedor">

                <table>

                    <thead>

                        <tr>

                            <th>Área</th>
                            <th>Empleados</th>
                            <th>Estado</th>
                            <th>Acción</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php if (count($areas) > 0): ?>

                        <?php foreach ($areas as $area): ?>

                            <tr>

                                <td>
                                    <strong>
                                        <?= htmlspecialchars($area["nombre"]) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= intval($area["total_empleados"]) ?>
                                </td>

                                <td>

                                    <?php if ($area["activo"]): ?>

                                        <span class="estado estado-activo">
                                            Activa
                                        </span>

                                    <?php else: ?>

                                        <span class="estado estado-inactivo">
                                            Inactiva
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <form method="POST">

                                        <input
                                            type="hidden"
                                            name="accion"
                                            value="toggle_area"
                                        >

                                        <input
                                            type="hidden"
                                            name="area_id"
                                            value="<?= intval($area["id"]) ?>"
                                        >

                                        <?php if ($area["activo"]): ?>

                                            <button
                                                type="submit"
                                                class="btn btn-inactivo"
                                                onclick="return confirm('¿Desactivar esta área?');"
                                            >
                                                Desactivar
                                            </button>

                                        <?php else: ?>

                                            <button
                                                type="submit"
                                                class="btn btn-activo"
                                            >
                                                Activar
                                            </button>

                                        <?php endif; ?>

                                    </form>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="4">
                                No hay áreas registradas.
                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>



        <!-- =================================================
             NUEVO EMPLEADO
        ================================================== -->

        <div class="tarjeta">

            <h2>👤 Nuevo Empleado</h2>

            <form method="POST">

                <input
                    type="hidden"
                    name="accion"
                    value="crear_empleado"
                >

                <div class="form-grupo">

                    <label for="nombre">
                        Nombre completo
                    </label>

                    <input
                        type="text"
                        name="nombre"
                        id="nombre"
                        maxlength="200"
                        placeholder="Nombre del empleado"
                        required
                    >

                </div>


                <div class="form-grupo">

                    <label for="numero_empleado">
                        Número de empleado
                    </label>

                    <input
                        type="text"
                        name="numero_empleado"
                        id="numero_empleado"
                        maxlength="50"
                        placeholder="Opcional"
                    >

                </div>


                <div class="form-grupo">

                    <label for="area_id">
                        Área
                    </label>

                    <select
                        name="area_id"
                        id="area_id"
                        required
                    >

                        <option value="">
                            -- Seleccionar área --
                        </option>

                        <?php foreach ($areas as $area): ?>

                            <?php if ($area["activo"]): ?>

                                <option value="<?= intval($area["id"]) ?>">

                                    <?= htmlspecialchars($area["nombre"]) ?>

                                </option>

                            <?php endif; ?>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="form-grupo">

                    <label for="puesto">
                        Puesto
                    </label>

                    <input
                        type="text"
                        name="puesto"
                        id="puesto"
                        maxlength="150"
                        placeholder="Ej. Técnico"
                    >

                </div>


                <button
                    type="submit"
                    class="btn btn-principal"
                >
                    ➕ Registrar empleado
                </button>

            </form>

        </div>

    </div>



    <!-- =====================================================
         EMPLEADOS REGISTRADOS
    ====================================================== -->

    <div class="tarjeta">

        <h2>👥 Empleados registrados</h2>


        <?php

        $total_empleados = count($empleados);

        $empleados_activos = 0;
        $empleados_inactivos = 0;

        foreach ($empleados as $empleado) {

            if ($empleado["activo"]) {
                $empleados_activos++;
            } else {
                $empleados_inactivos++;
            }

        }

        ?>


        <div class="resumen-areas">

            <div class="resumen-item">

                <strong>
                    <?= $total_empleados ?>
                </strong>

                <span>
                    Total empleados
                </span>

            </div>


            <div class="resumen-item">

                <strong>
                    <?= $empleados_activos ?>
                </strong>

                <span>
                    Empleados activos
                </span>

            </div>


            <div class="resumen-item">

                <strong>
                    <?= $empleados_inactivos ?>
                </strong>

                <span>
                    Empleados inactivos
                </span>

            </div>

        </div>


        <div class="tabla-contenedor">

            <table>

                <thead>

                    <tr>

                        <th>Nombre</th>
                        <th>No. empleado</th>
                        <th>Área</th>
                        <th>Puesto</th>
                        <th>Estado</th>
                        <th>Acciones</th>

                    </tr>

                </thead>

                <tbody>

                <?php if (count($empleados) > 0): ?>

                    <?php foreach ($empleados as $empleado): ?>

                        <tr>

                            <td>

                                <strong>

                                    <?= htmlspecialchars($empleado["nombre"]) ?>

                                </strong>

                            </td>


                            <td>

                                <?= $empleado["numero_empleado"] !== ""
                                    ? htmlspecialchars($empleado["numero_empleado"])
                                    : "—"
                                ?>

                            </td>


                            <td>

                                <?= htmlspecialchars($empleado["area_nombre"]) ?>

                            </td>


                            <td>

                                <?= $empleado["puesto"] !== ""
                                    ? htmlspecialchars($empleado["puesto"])
                                    : "—"
                                ?>

                            </td>


                            <td>

                                <?php if ($empleado["activo"]): ?>

                                    <span class="estado estado-activo">
                                        Activo
                                    </span>

                                <?php else: ?>

                                    <span class="estado estado-inactivo">
                                        Inactivo
                                    </span>

                                <?php endif; ?>

                            </td>


                            <td>

                                <div style="display:flex; gap:6px; flex-wrap:wrap;">


                                    <!-- EDITAR -->

                                    <button
                                        type="button"
                                        class="btn btn-editar"
                                        onclick='editarEmpleado(
                                            <?= json_encode($empleado["id"]) ?>,
                                            <?= json_encode($empleado["nombre"]) ?>,
                                            <?= json_encode($empleado["numero_empleado"]) ?>,
                                            <?= json_encode($empleado["area_id"]) ?>,
                                            <?= json_encode($empleado["puesto"]) ?>
                                        )'
                                    >
                                        ✏️ Editar
                                    </button>


                                    <!-- ACTIVAR / DESACTIVAR -->

                                    <form method="POST">

                                        <input
                                            type="hidden"
                                            name="accion"
                                            value="toggle_empleado"
                                        >

                                        <input
                                            type="hidden"
                                            name="empleado_id"
                                            value="<?= intval($empleado["id"]) ?>"
                                        >

                                        <?php if ($empleado["activo"]): ?>

                                            <button
                                                type="submit"
                                                class="btn btn-inactivo"
                                                onclick="return confirm('¿Desactivar este empleado?');"
                                            >
                                                Desactivar
                                            </button>

                                        <?php else: ?>

                                            <button
                                                type="submit"
                                                class="btn btn-activo"
                                            >
                                                Activar
                                            </button>

                                        <?php endif; ?>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="6" style="text-align:center;">

                            No hay empleados registrados.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>



<!-- =========================================================
     MODAL EDITAR EMPLEADO
========================================================= -->

<div
    id="modalEditar"
    class="modal"
>

    <div class="modal-contenido">

        <h2>✏️ Editar empleado</h2>


        <form method="POST">

            <input
                type="hidden"
                name="accion"
                value="editar_empleado"
            >

            <input
                type="hidden"
                name="empleado_id"
                id="editar_empleado_id"
            >


            <div class="form-grupo">

                <label for="editar_nombre">
                    Nombre completo
                </label>

                <input
                    type="text"
                    name="nombre"
                    id="editar_nombre"
                    maxlength="200"
                    required
                >

            </div>


            <div class="form-grupo">

                <label for="editar_numero_empleado">
                    Número de empleado
                </label>

                <input
                    type="text"
                    name="numero_empleado"
                    id="editar_numero_empleado"
                    maxlength="50"
                >

            </div>


            <div class="form-grupo">

                <label for="editar_area_id">
                    Área
                </label>

                <select
                    name="area_id"
                    id="editar_area_id"
                    required
                >

                    <option value="">
                        -- Seleccionar área --
                    </option>

                    <?php foreach ($areas as $area): ?>

                        <?php if ($area["activo"]): ?>

                            <option
                                value="<?= intval($area["id"]) ?>"
                            >

                                <?= htmlspecialchars($area["nombre"]) ?>

                            </option>

                        <?php endif; ?>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="form-grupo">

                <label for="editar_puesto">
                    Puesto
                </label>

                <input
                    type="text"
                    name="puesto"
                    id="editar_puesto"
                    maxlength="150"
                >

            </div>


            <div class="modal-botones">

                <button
                    type="button"
                    class="btn btn-secundario"
                    onclick="cerrarModal()"
                >
                    Cancelar
                </button>

                <button
                    type="submit"
                    class="btn btn-principal"
                >
                    💾 Guardar cambios
                </button>

            </div>

        </form>

    </div>

</div>


<script>

function editarEmpleado(
    id,
    nombre,
    numeroEmpleado,
    areaId,
    puesto
) {

    document.getElementById("editar_empleado_id").value = id;

    document.getElementById("editar_nombre").value = nombre;

    document.getElementById("editar_numero_empleado").value =
        numeroEmpleado;

    document.getElementById("editar_area_id").value =
        areaId;

    document.getElementById("editar_puesto").value =
        puesto;

    document.getElementById("modalEditar").style.display = "block";
}


function cerrarModal() {

    document.getElementById("modalEditar").style.display = "none";

}


window.onclick = function(event) {

    const modal = document.getElementById("modalEditar");

    if (event.target === modal) {

        cerrarModal();

    }

};

</script>


<?php require_once __DIR__ . '/footer.php'; ?>