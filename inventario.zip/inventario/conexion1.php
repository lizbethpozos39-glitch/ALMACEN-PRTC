<?php

$conexion = new mysqli(
    "localhost",
    "root",
    "",
    "inventario_db"
);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$conexion->set_charset("utf8mb4");

?>
