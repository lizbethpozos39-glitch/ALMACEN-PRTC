<footer class="footer">

    © <?= date("Y") ?> Sistema de Inventario
    |
    Desarrollado por <strong>Ing.Lizbeth Pozos Yañez</strong>
    |
    <strong>Grupo Protec</strong>

</footer>

<style>

.footer {

    width: 100%;

    margin-top: 40px;

    padding: 20px;

    text-align: center;

    color: #6c757d;

    font-size: 13px;

    border-top: 1px solid #ddd;

    background: #ffffff;

}

</style>
