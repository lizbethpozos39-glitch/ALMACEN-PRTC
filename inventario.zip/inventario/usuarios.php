<?php

// ==========================================
// CONEXIÓN Y SEGURIDAD
// ==========================================

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';
require_once __DIR__ . '/auditoria.php';

verificar_admin();


// ==========================================
// MENSAJES
// ==========================================

$mensaje = "";
$error = "";


// ==========================================
// FUNCIÓN AUXILIAR PARA AUDITORÍA
// ==========================================

function registrar_auditoria_segura($conexion, $accion, $modulo, $descripcion)
{
    /*
     * IMPORTANTE:
     * registrar_auditoria() recibe la conexión como
     * primer parámetro.
     */
    registrar_auditoria(
        $conexion,
        $accion,
        $modulo,
        $descripcion
    );
}


// ==========================================
// CREAR USUARIO
// ==========================================

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["crear_usuario"])
) {

    $empleado_id = intval($_POST["empleado_id"] ?? 0);
    $usuario = trim($_POST["usuario"] ?? "");
    $password = $_POST["password"] ?? "";
    $rol = strtoupper(trim($_POST["rol"] ?? "USUARIO"));

    // ------------------------------------------
    // VALIDACIONES
    // ------------------------------------------

    if ($empleado_id <= 0) {

        $error = "Debes seleccionar un empleado.";

    } elseif ($usuario === "") {

        $error = "Debes indicar un nombre de usuario.";

    } elseif (strlen($usuario) < 3) {

        $error = "El usuario debe tener al menos 3 caracteres.";

    } elseif (strlen($usuario) > 100) {

        $error = "El nombre de usuario es demasiado largo.";

    } elseif ($password === "") {

        $error = "Debes indicar una contraseña.";

    } elseif (strlen($password) < 6) {

        $error = "La contraseña debe tener al menos 6 caracteres.";

    } elseif (
        !in_array(
            $rol,
            ["ADMIN", "GERENCIA", "USUARIO", "CONSULTA"],
            true
        )
    ) {

        $error = "El rol seleccionado no es válido.";

    } else {

        // ------------------------------------------
        // VERIFICAR EMPLEADO
        // ------------------------------------------

        $stmt = $conexion->prepare("
            SELECT id
            FROM empleados
            WHERE id = ?
              AND activo = 1
            LIMIT 1
        ");

        if (!$stmt) {

            $error = "Error al verificar el empleado.";

        } else {

            $stmt->bind_param("i", $empleado_id);
            $stmt->execute();

            $resultado_empleado = $stmt->get_result();

            if ($resultado_empleado->num_rows === 0) {

                $error = "El empleado seleccionado no existe o está inactivo.";
            }

            $stmt->close();
        }


        // ------------------------------------------
        // VERIFICAR SI YA TIENE USUARIO
        // ------------------------------------------

        if ($error === "") {

            $stmt = $conexion->prepare("
                SELECT id
                FROM usuarios
                WHERE empleado_id = ?
                LIMIT 1
            ");

            if (!$stmt) {

                $error = "Error al verificar el usuario existente.";

            } else {

                $stmt->bind_param("i", $empleado_id);
                $stmt->execute();

                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {

                    $error = "Este empleado ya tiene un usuario.";
                }

                $stmt->close();
            }
        }


        // ------------------------------------------
        // VERIFICAR NOMBRE DE USUARIO
        // ------------------------------------------

        if ($error === "") {

            $stmt = $conexion->prepare("
                SELECT id
                FROM usuarios
                WHERE usuario = ?
                LIMIT 1
            ");

            if (!$stmt) {

                $error = "Error al verificar el nombre de usuario.";

            } else {

                $stmt->bind_param("s", $usuario);
                $stmt->execute();

                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {

                    $error = "El nombre de usuario ya está registrado.";
                }

                $stmt->close();
            }
        }


        // ------------------------------------------
        // CREAR USUARIO
        // ------------------------------------------

        if ($error === "") {

            $password_hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $stmt = $conexion->prepare("
                INSERT INTO usuarios
                (
                    empleado_id,
                    usuario,
                    password_hash,
                    rol,
                    activo
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    1
                )
            ");

            if (!$stmt) {

                $error = "Error al preparar la creación del usuario.";

            } else {

                $stmt->bind_param(
                    "isss",
                    $empleado_id,
                    $usuario,
                    $password_hash,
                    $rol
                );

                if ($stmt->execute()) {

                    $mensaje = "Usuario creado correctamente.";

                    // Auditoría
                    registrar_auditoria_segura(
                        $conexion,
                        "CREAR_USUARIO",
                        "USUARIOS",
                        "Se creó el usuario '{$usuario}' con rol '{$rol}'."
                    );

                } else {

                    $error = "Error al crear el usuario: " . $stmt->error;
                }

                $stmt->close();
            }
        }
    }
}


// ==========================================
// CAMBIAR ROL
// ==========================================

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["cambiar_rol"])
) {

    $usuario_id = intval($_POST["usuario_id"] ?? 0);
    $nuevo_rol = strtoupper(trim($_POST["nuevo_rol"] ?? ""));

    $roles_validos = [
        "ADMIN",
        "GERENCIA",
        "USUARIO",
        "CONSULTA"
    ];


    if ($usuario_id <= 0) {

        $error = "Usuario no válido.";

    } elseif (
        !in_array(
            $nuevo_rol,
            $roles_validos,
            true
        )
    ) {

        $error = "El rol seleccionado no es válido.";

    } elseif (
        isset($_SESSION["usuario_id"])
        && $usuario_id == $_SESSION["usuario_id"]
    ) {

        /*
         * Evitamos que el administrador conectado
         * cambie accidentalmente su propio rol.
         */
        $error = "No puedes cambiar el rol del usuario con el que estás conectado.";

    } else {

        // ------------------------------------------
        // OBTENER USUARIO Y ROL ACTUAL
        // ------------------------------------------

        $stmt = $conexion->prepare("
            SELECT
                u.usuario,
                u.rol,
                e.nombre AS empleado
            FROM usuarios u
            INNER JOIN empleados e
                ON e.id = u.empleado_id
            WHERE u.id = ?
            LIMIT 1
        ");

        if (!$stmt) {

            $error = "No fue posible consultar el usuario.";

        } else {

            $stmt->bind_param("i", $usuario_id);
            $stmt->execute();

            $resultado = $stmt->get_result();

            if ($resultado->num_rows === 0) {

                $error = "El usuario no existe.";

                $stmt->close();

            } else {

                $datos_usuario = $resultado->fetch_assoc();

                $rol_anterior = strtoupper(
                    trim($datos_usuario["rol"])
                );

                $nombre_usuario = $datos_usuario["usuario"];
                $nombre_empleado = $datos_usuario["empleado"];

                $stmt->close();


                // ------------------------------------------
                // SI NO CAMBIÓ EL ROL
                // ------------------------------------------

                if ($rol_anterior === $nuevo_rol) {

                    $mensaje = "El usuario ya tiene el rol {$nuevo_rol}.";

                } else {

                    // ------------------------------------------
                    // ACTUALIZAR ROL
                    // ------------------------------------------

                    $stmt = $conexion->prepare("
                        UPDATE usuarios
                        SET rol = ?
                        WHERE id = ?
                    ");

                    if (!$stmt) {

                        $error = "No fue posible preparar el cambio de rol.";

                    } else {

                        $stmt->bind_param(
                            "si",
                            $nuevo_rol,
                            $usuario_id
                        );

                        if ($stmt->execute()) {

                            $mensaje =
                                "Rol actualizado correctamente. "
                                . "Ahora {$nombre_empleado} tiene el rol {$nuevo_rol}.";

                            // ------------------------------------------
                            // AUDITORÍA
                            // ------------------------------------------

                            registrar_auditoria_segura(
                                $conexion,
                                "CAMBIO_ROL",
                                "USUARIOS",
                                "Se cambió el rol del usuario '{$nombre_usuario}' "
                                . "({$nombre_empleado}) de '{$rol_anterior}' "
                                . "a '{$nuevo_rol}'."
                            );

                        } else {

                            $error =
                                "No fue posible actualizar el rol: "
                                . $stmt->error;
                        }

                        $stmt->close();
                    }
                }
            }
        }
    }
}


// ==========================================
// ACTIVAR / DESACTIVAR USUARIO
// ==========================================

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["cambiar_estado"])
) {

    $usuario_id = intval($_POST["usuario_id"] ?? 0);


    if ($usuario_id <= 0) {

        $error = "Usuario no válido.";

    } elseif (
        isset($_SESSION["usuario_id"])
        && $usuario_id == $_SESSION["usuario_id"]
    ) {

        /*
         * No permitimos desactivar al usuario
         * que está actualmente conectado.
         */
        $error = "No puedes desactivar el usuario con el que estás conectado.";

    } else {

        // ------------------------------------------
        // OBTENER DATOS ANTES DEL CAMBIO
        // ------------------------------------------

        $stmt = $conexion->prepare("
            SELECT
                u.usuario,
                u.activo,
                e.nombre AS empleado
            FROM usuarios u
            INNER JOIN empleados e
                ON e.id = u.empleado_id
            WHERE u.id = ?
            LIMIT 1
        ");

        if (!$stmt) {

            $error = "No fue posible consultar el usuario.";

        } else {

            $stmt->bind_param("i", $usuario_id);
            $stmt->execute();

            $resultado = $stmt->get_result();

            if ($resultado->num_rows === 0) {

                $error = "El usuario no existe.";

                $stmt->close();

            } else {

                $datos_usuario = $resultado->fetch_assoc();

                $estado_anterior = intval(
                    $datos_usuario["activo"]
                );

                $nombre_usuario = $datos_usuario["usuario"];
                $nombre_empleado = $datos_usuario["empleado"];

                $stmt->close();


                // ------------------------------------------
                // CAMBIAR ESTADO
                // ------------------------------------------

                $nuevo_estado = $estado_anterior == 1 ? 0 : 1;

                $stmt = $conexion->prepare("
                    UPDATE usuarios
                    SET activo = ?
                    WHERE id = ?
                ");

                if (!$stmt) {

                    $error = "No fue posible preparar el cambio de estado.";

                } else {

                    $stmt->bind_param(
                        "ii",
                        $nuevo_estado,
                        $usuario_id
                    );

                    if ($stmt->execute()) {

                        $mensaje =
                            $nuevo_estado == 1
                            ? "Usuario activado correctamente."
                            : "Usuario desactivado correctamente.";

                        // ------------------------------------------
                        // AUDITORÍA
                        // ------------------------------------------

                        registrar_auditoria_segura(
                            $conexion,
                            "CAMBIO_ESTADO",
                            "USUARIOS",
                            "Se "
                            . (
                                $nuevo_estado == 1
                                ? "activó"
                                : "desactivó"
                            )
                            . " el usuario '{$nombre_usuario}' "
                            . "({$nombre_empleado})."
                        );

                    } else {

                        $error =
                            "No fue posible cambiar el estado: "
                            . $stmt->error;
                    }

                    $stmt->close();
                }
            }
        }
    }
}


// ==========================================
// CAMBIAR CONTRASEÑA
// ==========================================

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["cambiar_password"])
) {

    $usuario_id = intval($_POST["usuario_id"] ?? 0);
    $nueva_password = $_POST["nueva_password"] ?? "";


    if ($usuario_id <= 0) {

        $error = "Usuario no válido.";

    } elseif ($nueva_password === "") {

        $error = "Debes indicar una nueva contraseña.";

    } elseif (strlen($nueva_password) < 6) {

        $error = "La nueva contraseña debe tener al menos 6 caracteres.";

    } elseif (strlen($nueva_password) > 100) {

        $error = "La nueva contraseña es demasiado larga.";

    } else {

        // ------------------------------------------
        // OBTENER DATOS DEL USUARIO
        // ------------------------------------------

        $stmt = $conexion->prepare("
            SELECT
                u.usuario,
                e.nombre AS empleado
            FROM usuarios u
            INNER JOIN empleados e
                ON e.id = u.empleado_id
            WHERE u.id = ?
            LIMIT 1
        ");

        if (!$stmt) {

            $error = "No fue posible consultar el usuario.";

        } else {

            $stmt->bind_param("i", $usuario_id);
            $stmt->execute();

            $resultado = $stmt->get_result();

            if ($resultado->num_rows === 0) {

                $error = "El usuario no existe.";

                $stmt->close();

            } else {

                $datos_usuario = $resultado->fetch_assoc();

                $nombre_usuario = $datos_usuario["usuario"];
                $nombre_empleado = $datos_usuario["empleado"];

                $stmt->close();


                // ------------------------------------------
                // GENERAR HASH
                // ------------------------------------------

                $password_hash = password_hash(
                    $nueva_password,
                    PASSWORD_DEFAULT
                );


                // ------------------------------------------
                // ACTUALIZAR CONTRASEÑA
                // ------------------------------------------

                $stmt = $conexion->prepare("
                    UPDATE usuarios
                    SET password_hash = ?
                    WHERE id = ?
                ");

                if (!$stmt) {

                    $error =
                        "No fue posible preparar el cambio de contraseña.";

                } else {

                    $stmt->bind_param(
                        "si",
                        $password_hash,
                        $usuario_id
                    );

                    if ($stmt->execute()) {

                        $mensaje =
                            "Contraseña actualizada correctamente para "
                            . $nombre_empleado . ".";

                        // ------------------------------------------
                        // AUDITORÍA
                        // ------------------------------------------

                        registrar_auditoria_segura(
                            $conexion,
                            "CAMBIO_PASSWORD",
                            "USUARIOS",
                            "Se cambió la contraseña del usuario "
                            . "'{$nombre_usuario}' ({$nombre_empleado})."
                        );

                    } else {

                        $error =
                            "No fue posible actualizar la contraseña: "
                            . $stmt->error;
                    }

                    $stmt->close();
                }
            }
        }
    }
}


// ==========================================
// ELIMINAR USUARIO
// ==========================================

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["eliminar_usuario"])
) {

    $usuario_id = intval($_POST["usuario_id"] ?? 0);


    if ($usuario_id <= 0) {

        $error = "Usuario no válido.";

    } elseif (
        isset($_SESSION["usuario_id"])
        && $usuario_id == $_SESSION["usuario_id"]
    ) {

        $error =
            "No puedes eliminar el usuario con el que estás conectado.";

    } else {

        // ------------------------------------------
        // OBTENER DATOS ANTES DE ELIMINAR
        // ------------------------------------------

        $stmt = $conexion->prepare("
            SELECT
                u.usuario,
                e.nombre AS empleado
            FROM usuarios u
            INNER JOIN empleados e
                ON e.id = u.empleado_id
            WHERE u.id = ?
            LIMIT 1
        ");

        if (!$stmt) {

            $error = "No fue posible consultar el usuario.";

        } else {

            $stmt->bind_param("i", $usuario_id);
            $stmt->execute();

            $resultado = $stmt->get_result();

            if ($resultado->num_rows === 0) {

                $error = "El usuario no existe.";

                $stmt->close();

            } else {

                $datos_usuario = $resultado->fetch_assoc();

                $nombre_usuario = $datos_usuario["usuario"];
                $nombre_empleado = $datos_usuario["empleado"];

                $stmt->close();


                // ------------------------------------------
                // ELIMINAR
                // ------------------------------------------

                $stmt = $conexion->prepare("
                    DELETE FROM usuarios
                    WHERE id = ?
                ");

                if (!$stmt) {

                    $error =
                        "No fue posible preparar la eliminación.";

                } else {

                    $stmt->bind_param(
                        "i",
                        $usuario_id
                    );

                    if ($stmt->execute()) {

                        $mensaje =
                            "Usuario eliminado correctamente.";

                        // ------------------------------------------
                        // AUDITORÍA
                        // ------------------------------------------

                        registrar_auditoria_segura(
                            $conexion,
                            "ELIMINAR_USUARIO",
                            "USUARIOS",
                            "Se eliminó el usuario '{$nombre_usuario}' "
                            . "({$nombre_empleado})."
                        );

                    } else {

                        $error =
                            "No fue posible eliminar el usuario: "
                            . $stmt->error;
                    }

                    $stmt->close();
                }
            }
        }
    }
}


// ==========================================
// EMPLEADOS DISPONIBLES
// ==========================================

$empleados = [];

$sql_empleados = "
    SELECT
        e.id,
        e.nombre,
        e.numero_empleado,
        e.puesto,
        a.nombre AS area
    FROM empleados e
    LEFT JOIN areas a
        ON a.id = e.area_id
    LEFT JOIN usuarios u
        ON u.empleado_id = e.id
    WHERE e.activo = 1
      AND u.id IS NULL
    ORDER BY e.nombre ASC
";

$resultado_empleados = $conexion->query(
    $sql_empleados
);

if ($resultado_empleados) {

    while (
        $fila = $resultado_empleados->fetch_assoc()
    ) {

        $empleados[] = $fila;
    }
}


// ==========================================
// USUARIOS REGISTRADOS
// ==========================================

$sql_usuarios = "
    SELECT
        u.id,
        u.usuario,
        u.rol,
        u.activo,
        u.ultimo_acceso,
        u.fecha_registro,

        e.id AS empleado_id,
        e.nombre AS empleado,
        e.numero_empleado,
        e.puesto,

        a.nombre AS area

    FROM usuarios u

    INNER JOIN empleados e
        ON e.id = u.empleado_id

    LEFT JOIN areas a
        ON a.id = e.area_id

    ORDER BY e.nombre ASC
";

$resultado_usuarios = $conexion->query(
    $sql_usuarios
);

?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Administración de Usuarios</title>


<style>

* {
    box-sizing: border-box;
}


body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6f8;
    color: #333;
}


/* ==========================================
   BARRA SUPERIOR
========================================== */

.barra {

    background: #212529;

    color: white;

    padding: 15px 30px;

    display: flex;

    justify-content: space-between;

    align-items: center;

    flex-wrap: wrap;

    gap: 10px;
}


.barra h1 {

    margin: 0;

    font-size: 20px;
}


.barra-derecha {

    display: flex;

    align-items: center;

    gap: 15px;
}


.usuario {

    font-size: 13px;

    text-align: right;
}


.usuario strong {

    display: block;
}


.usuario small {

    color: #ced4da;
}


.salir {

    background: #dc3545;

    color: white;

    text-decoration: none;

    padding: 8px 12px;

    border-radius: 5px;

    font-size: 13px;
}


.salir:hover {

    background: #bb2d3b;
}


/* ==========================================
   CONTENEDOR
========================================== */

.contenedor {

    width: 95%;

    max-width: 1400px;

    margin: 30px auto;
}


/* ==========================================
   TARJETAS
========================================== */

.tarjeta {

    background: white;

    padding: 25px;

    border-radius: 10px;

    box-shadow:
        0 2px 8px rgba(0,0,0,.10);

    margin-bottom: 25px;
}


.tarjeta h2 {

    margin-top: 0;

    margin-bottom: 20px;
}


/* ==========================================
   MENSAJES
========================================== */

.mensaje {

    padding: 12px 15px;

    border-radius: 6px;

    margin-bottom: 20px;

    background: #d1e7dd;

    color: #0f5132;

    border: 1px solid #badbcc;
}


.error {

    padding: 12px 15px;

    border-radius: 6px;

    margin-bottom: 20px;

    background: #f8d7da;

    color: #842029;

    border: 1px solid #f5c2c7;
}


/* ==========================================
   FORMULARIO
========================================== */

.form-grid {

    display: grid;

    grid-template-columns:
        repeat(auto-fit, minmax(220px, 1fr));

    gap: 15px;
}


.campo label {

    display: block;

    font-size: 13px;

    font-weight: bold;

    margin-bottom: 6px;
}


.campo input,
.campo select {

    width: 100%;

    padding: 10px;

    border: 1px solid #ccc;

    border-radius: 5px;

    font-size: 14px;
}


.boton-crear {

    margin-top: 20px;

    padding: 11px 20px;

    border: none;

    border-radius: 5px;

    background: #198754;

    color: white;

    cursor: pointer;

    font-size: 14px;

    font-weight: bold;
}


.boton-crear:hover {

    background: #157347;
}


/* ==========================================
   TABLA
========================================== */

.tabla-contenedor {

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 1200px;
}


th {

    background: #212529;

    color: white;

    padding: 12px;

    text-align: left;

    font-size: 13px;
}


td {

    padding: 11px;

    border-bottom: 1px solid #ddd;

    font-size: 13px;

    vertical-align: top;
}


tr:hover {

    background: #f8f9fa;
}


/* ==========================================
   ESTADOS
========================================== */

.estado-activo {

    display: inline-block;

    padding: 5px 9px;

    border-radius: 20px;

    background: #d1e7dd;

    color: #0f5132;

    font-weight: bold;

    font-size: 11px;
}


.estado-inactivo {

    display: inline-block;

    padding: 5px 9px;

    border-radius: 20px;

    background: #f8d7da;

    color: #842029;

    font-weight: bold;

    font-size: 11px;
}


/* ==========================================
   ROLES
========================================== */

.rol-admin {

    font-weight: bold;

    color: #6f42c1;
}


.rol-gerencia {

    font-weight: bold;

    color: #fd7e14;
}


.rol-usuario {

    color: #0d6efd;

    font-weight: bold;
}


.rol-consulta {

    color: #198754;

    font-weight: bold;
}


/* ==========================================
   BOTONES DE TABLA
========================================== */

.btn {

    border: none;

    padding: 7px 10px;

    border-radius: 5px;

    cursor: pointer;

    font-size: 12px;

    color: white;

    margin: 2px;
}


.btn-estado {

    background: #6c757d;
}


.btn-password {

    background: #0d6efd;
}


.btn-rol {

    background: #fd7e14;
}


.btn-eliminar {

    background: #dc3545;
}


.btn-guardar {

    background: #198754;
}


.btn-cancelar {

    background: #6c757d;
}


.btn:hover {

    opacity: .85;
}


/* ==========================================
   CONTRASEÑA
========================================== */

.password-box {

    display: none;

    margin-top: 10px;

    padding: 10px;

    background: #f8f9fa;

    border-radius: 5px;
}


.password-box input {

    padding: 7px;

    border: 1px solid #ccc;

    border-radius: 4px;

    margin-bottom: 5px;
}


.password-box button {

    padding: 7px 10px;

    border: none;

    background: #198754;

    color: white;

    border-radius: 4px;

    cursor: pointer;
}


/* ==========================================
   ROL BOX
========================================== */

.rol-box {

    display: none;

    margin-top: 10px;

    padding: 10px;

    background: #fff3cd;

    border: 1px solid #ffe69c;

    border-radius: 5px;
}


.rol-box select {

    padding: 7px;

    border: 1px solid #ccc;

    border-radius: 4px;

    margin-bottom: 5px;

    min-width: 150px;
}


.rol-box button {

    padding: 7px 10px;

    border: none;

    background: #198754;

    color: white;

    border-radius: 4px;

    cursor: pointer;
}


/* ==========================================
   INFORMACIÓN
========================================== */

.info-password {

    display: block;

    margin-top: 5px;

    color: #6c757d;

    font-size: 11px;
}


/* ==========================================
   FOOTER
========================================== */

.footer {

    width: 100%;

    margin-top: 40px;

    padding: 20px;

    text-align: center;

    color: #6c757d;

    font-size: 13px;

    border-top: 1px solid #ddd;

    background: white;
}


/* ==========================================
   RESPONSIVE
========================================== */

@media (max-width: 700px) {

    .barra {

        padding: 15px;
    }

    .barra-derecha {

        width: 100%;

        justify-content: space-between;
    }

    .contenedor {

        width: 95%;

        margin: 20px auto;
    }

    .tarjeta {

        padding: 15px;
    }
}

</style>


<script>

// ==========================================
// MOSTRAR / OCULTAR CONTRASEÑA
// ==========================================

function mostrarPassword(id) {

    const elemento =
        document.getElementById(
            "password-" + id
        );

    if (!elemento) {
        return;
    }

    if (
        elemento.style.display === "block"
    ) {

        elemento.style.display = "none";

    } else {

        elemento.style.display = "block";
    }
}


// ==========================================
// MOSTRAR / OCULTAR ROL
// ==========================================

function mostrarRol(id) {

    const elemento =
        document.getElementById(
            "rol-" + id
        );

    if (!elemento) {
        return;
    }

    if (
        elemento.style.display === "block"
    ) {

        elemento.style.display = "none";

    } else {

        elemento.style.display = "block";
    }
}


// ==========================================
// CONFIRMAR ELIMINACIÓN
// ==========================================

function confirmarEliminar(nombre) {

    return confirm(
        "¿Seguro que deseas eliminar el usuario de "
        + nombre
        + "?"
    );
}


// ==========================================
// CONFIRMAR CAMBIO DE ROL
// ==========================================

function confirmarRol(nombre) {

    return confirm(
        "¿Deseas cambiar el rol del usuario de "
        + nombre
        + "?"
    );
}


// ==========================================
// CONFIRMAR CONTRASEÑA
// ==========================================

function confirmarPassword(nombre) {

    return confirm(
        "¿Deseas establecer una nueva contraseña para "
        + nombre
        + "?"
    );
}


// ==========================================
// OCULTAR MENSAJES AUTOMÁTICAMENTE
// ==========================================

setTimeout(function() {

    const mensajes =
        document.querySelectorAll(
            ".mensaje"
        );

    mensajes.forEach(function(elemento) {

        elemento.style.transition =
            "opacity .5s";

        elemento.style.opacity = "0";

        setTimeout(function() {

            elemento.style.display = "none";

        }, 500);

    });

}, 5000);

</script>

</head>


<body>


<!-- ==========================================
     BARRA
========================================== -->

<header class="barra">

    <h1>
        👥 Administración de Usuarios
    </h1>


    <div class="barra-derecha">

        <div class="usuario">

            <strong>

                👤

                <?= htmlspecialchars(
                    $_SESSION['nombre_empleado']
                    ?? 'Administrador'
                ) ?>

            </strong>

            <small>

                <?= htmlspecialchars(
                    $_SESSION['rol']
                    ?? 'ADMIN'
                ) ?>

            </small>

        </div>


        <a
            href="logout.php"
            class="salir"
        >

            🚪 Salir

        </a>

    </div>

</header>


<!-- ==========================================
     CONTENEDOR
========================================== -->

<div class="contenedor">


    <!-- ======================================
         MENSAJE ÉXITO
    ======================================= -->

    <?php if ($mensaje !== ""): ?>

        <div class="mensaje">

            ✅

            <?= htmlspecialchars(
                $mensaje
            ) ?>

        </div>

    <?php endif; ?>


    <!-- ======================================
         MENSAJE ERROR
    ======================================= -->

    <?php if ($error !== ""): ?>

        <div class="error">

            ⚠️

            <?= htmlspecialchars(
                $error
            ) ?>

        </div>

    <?php endif; ?>


    <!-- ======================================
         CREAR USUARIO
    ======================================= -->

    <div class="tarjeta">

        <h2>
            ➕ Crear usuario
        </h2>


        <?php if (count($empleados) > 0): ?>


            <form method="POST">

                <div class="form-grid">


                    <!-- EMPLEADO -->

                    <div class="campo">

                        <label>
                            Empleado
                        </label>

                        <select
                            name="empleado_id"
                            required
                        >

                            <option value="">
                                Seleccionar empleado
                            </option>


                            <?php foreach (
                                $empleados
                                as $empleado
                            ): ?>

                                <option
                                    value="<?= $empleado['id'] ?>"
                                >

                                    <?= htmlspecialchars(
                                        $empleado['nombre']
                                    ) ?>

                                    <?php if (
                                        !empty(
                                            $empleado['numero_empleado']
                                        )
                                    ): ?>

                                        -
                                        <?= htmlspecialchars(
                                            $empleado['numero_empleado']
                                        ) ?>

                                    <?php endif; ?>

                                    <?php if (
                                        !empty(
                                            $empleado['puesto']
                                        )
                                    ): ?>

                                        -
                                        <?= htmlspecialchars(
                                            $empleado['puesto']
                                        ) ?>

                                    <?php endif; ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- USUARIO -->

                    <div class="campo">

                        <label>
                            Nombre de usuario
                        </label>

                        <input
                            type="text"
                            name="usuario"
                            required
                            minlength="3"
                            maxlength="100"
                            placeholder="Ej. iram"
                        >

                    </div>


                    <!-- CONTRASEÑA -->

                    <div class="campo">

                        <label>
                            Contraseña
                        </label>

                        <input
                            type="password"
                            name="password"
                            required
                            minlength="6"
                            maxlength="100"
                            placeholder="Mínimo 6 caracteres"
                            autocomplete="new-password"
                        >

                    </div>


                    <!-- ROL -->

                    <div class="campo">

                        <label>
                            Rol
                        </label>

                        <select
                            name="rol"
                            required
                        >

                            <option value="USUARIO">
                                USUARIO
                            </option>

                            <option value="CONSULTA">
                                CONSULTA
                            </option>

                            <option value="GERENCIA">
                                GERENCIA
                            </option>

                            <option value="ADMIN">
                                ADMIN
                            </option>

                        </select>

                    </div>


                </div>


                <button
                    type="submit"
                    name="crear_usuario"
                    class="boton-crear"
                >

                    ➕ Crear usuario

                </button>


            </form>


        <?php else: ?>


            <div class="mensaje">

                ℹ️ Todos los empleados activos ya tienen
                un usuario registrado.

            </div>


        <?php endif; ?>


    </div>


    <!-- ======================================
         USUARIOS REGISTRADOS
    ======================================= -->

    <div class="tarjeta">

        <h2>
            👥 Usuarios registrados
        </h2>


        <div class="tabla-contenedor">

            <table>

                <thead>

                    <tr>

                        <th>
                            ID
                        </th>

                        <th>
                            Empleado
                        </th>

                        <th>
                            No. empleado
                        </th>

                        <th>
                            Área
                        </th>

                        <th>
                            Puesto
                        </th>

                        <th>
                            Usuario
                        </th>

                        <th>
                            Rol
                        </th>

                        <th>
                            Estado
                        </th>

                        <th>
                            Último acceso
                        </th>

                        <th>
                            Acciones
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php if (
                    $resultado_usuarios
                    && $resultado_usuarios->num_rows > 0
                ): ?>


                    <?php while (
                        $usuario =
                        $resultado_usuarios->fetch_assoc()
                    ): ?>


                        <tr>


                            <!-- ID -->

                            <td>

                                <?= $usuario["id"] ?>

                            </td>


                            <!-- EMPLEADO -->

                            <td>

                                <strong>

                                    <?= htmlspecialchars(
                                        $usuario["empleado"]
                                    ) ?>

                                </strong>

                            </td>


                            <!-- NÚMERO -->

                            <td>

                                <?= htmlspecialchars(
                                    $usuario["numero_empleado"]
                                    ?? ""
                                ) ?>

                            </td>


                            <!-- ÁREA -->

                            <td>

                                <?= htmlspecialchars(
                                    $usuario["area"]
                                    ?? ""
                                ) ?>

                            </td>


                            <!-- PUESTO -->

                            <td>

                                <?= htmlspecialchars(
                                    $usuario["puesto"]
                                    ?? ""
                                ) ?>

                            </td>


                            <!-- USUARIO -->

                            <td>

                                <strong>

                                    <?= htmlspecialchars(
                                        $usuario["usuario"]
                                    ) ?>

                                </strong>

                            </td>


                            <!-- ROL -->

                            <td>


                                <?php

                                $rol_actual =
                                    strtoupper(
                                        trim(
                                            $usuario["rol"]
                                        )
                                    );

                                ?>


                                <?php if (
                                    $rol_actual === "ADMIN"
                                ): ?>

                                    <span class="rol-admin">

                                        🛡️ ADMIN

                                    </span>


                                <?php elseif (
                                    $rol_actual === "GERENCIA"
                                ): ?>

                                    <span class="rol-gerencia">

                                        👔 GERENCIA

                                    </span>


                                <?php elseif (
                                    $rol_actual === "CONSULTA"
                                ): ?>

                                    <span class="rol-consulta">

                                        👁️ CONSULTA

                                    </span>


                                <?php else: ?>

                                    <span class="rol-usuario">

                                        👤 USUARIO

                                    </span>

                                <?php endif; ?>


                            </td>


                            <!-- ESTADO -->

                            <td>


                                <?php if (
                                    $usuario["activo"] == 1
                                ): ?>

                                    <span class="estado-activo">

                                        ACTIVO

                                    </span>

                                <?php else: ?>

                                    <span class="estado-inactivo">

                                        INACTIVO

                                    </span>

                                <?php endif; ?>


                            </td>


                            <!-- ÚLTIMO ACCESO -->

                            <td>


                                <?php if (
                                    !empty(
                                        $usuario["ultimo_acceso"]
                                    )
                                ): ?>

                                    <?= htmlspecialchars(
                                        $usuario["ultimo_acceso"]
                                    ) ?>

                                <?php else: ?>

                                    Nunca

                                <?php endif; ?>


                            </td>


                            <!-- ACCIONES -->

                            <td>


                                <!-- ==================================
                                     ACTIVAR / DESACTIVAR
                                =================================== -->

                                <?php if (
                                    $usuario["id"]
                                    != ($_SESSION["usuario_id"] ?? 0)
                                ): ?>

                                    <form
                                        method="POST"
                                        style="display:inline;"
                                    >

                                        <input
                                            type="hidden"
                                            name="usuario_id"
                                            value="<?= $usuario["id"] ?>"
                                        >

                                        <button
                                            type="submit"
                                            name="cambiar_estado"
                                            class="btn btn-estado"
                                        >

                                            <?= $usuario["activo"] == 1
                                                ? "⛔ Desactivar"
                                                : "✅ Activar"
                                            ?>

                                        </button>

                                    </form>

                                <?php else: ?>

                                    <button
                                        type="button"
                                        class="btn btn-estado"
                                        disabled
                                        title="No puedes cambiar tu propio estado"
                                        style="cursor:not-allowed;opacity:.55;"
                                    >

                                        🔒 Tu cuenta

                                    </button>

                                <?php endif; ?>


                                <!-- ==================================
                                     CAMBIAR ROL
                                =================================== -->

                                <?php if (
                                    $usuario["id"]
                                    != ($_SESSION["usuario_id"] ?? 0)
                                ): ?>

                                    <button
                                        type="button"
                                        class="btn btn-rol"
                                        onclick="mostrarRol(
                                            <?= $usuario["id"] ?>
                                        )"
                                    >

                                        ✏️ Rol

                                    </button>


                                    <div
                                        id="rol-<?= $usuario["id"] ?>"
                                        class="rol-box"
                                    >

                                        <form
                                            method="POST"
                                            onsubmit="return confirmarRol(
                                                '<?= htmlspecialchars(
                                                    $usuario["empleado"],
                                                    ENT_QUOTES
                                                ) ?>'
                                            );"
                                        >

                                            <input
                                                type="hidden"
                                                name="usuario_id"
                                                value="<?= $usuario["id"] ?>"
                                            >


                                            <select
                                                name="nuevo_rol"
                                                required
                                            >

                                                <option
                                                    value="USUARIO"
                                                    <?= $rol_actual === "USUARIO"
                                                        ? "selected"
                                                        : ""
                                                    ?>
                                                >
                                                    USUARIO
                                                </option>


                                                <option
                                                    value="CONSULTA"
                                                    <?= $rol_actual === "CONSULTA"
                                                        ? "selected"
                                                        : ""
                                                    ?>
                                                >
                                                    CONSULTA
                                                </option>


                                                <option
                                                    value="GERENCIA"
                                                    <?= $rol_actual === "GERENCIA"
                                                        ? "selected"
                                                        : ""
                                                    ?>
                                                >
                                                    GERENCIA
                                                </option>


                                                <option
                                                    value="ADMIN"
                                                    <?= $rol_actual === "ADMIN"
                                                        ? "selected"
                                                        : ""
                                                    ?>
                                                >
                                                    ADMIN
                                                </option>

                                            </select>


                                            <br>


                                            <button
                                                type="submit"
                                                name="cambiar_rol"
                                                class="btn-guardar"
                                            >

                                                💾 Guardar rol

                                            </button>

                                        </form>

                                    </div>


                                <?php else: ?>

                                    <button
                                        type="button"
                                        class="btn btn-rol"
                                        disabled
                                        title="No puedes cambiar tu propio rol"
                                        style="cursor:not-allowed;opacity:.55;"
                                    >

                                        🔒 Rol protegido

                                    </button>

                                <?php endif; ?>


                                <!-- ==================================
                                     CAMBIAR CONTRASEÑA
                                =================================== -->

                                <button
                                    type="button"
                                    class="btn btn-password"
                                    onclick="mostrarPassword(
                                        <?= $usuario["id"] ?>
                                    )"
                                >

                                    🔑 Contraseña

                                </button>


                                <div
                                    id="password-<?= $usuario["id"] ?>"
                                    class="password-box"
                                >

                                    <form
                                        method="POST"
                                        onsubmit="return confirmarPassword(
                                            '<?= htmlspecialchars(
                                                $usuario["empleado"],
                                                ENT_QUOTES
                                            ) ?>'
                                        );"
                                    >

                                        <input
                                            type="hidden"
                                            name="usuario_id"
                                            value="<?= $usuario["id"] ?>"
                                        >


                                        <input
                                            type="password"
                                            name="nueva_password"
                                            minlength="6"
                                            maxlength="100"
                                            placeholder="Nueva contraseña"
                                            autocomplete="new-password"
                                            required
                                        >


                                        <br>


                                        <button
                                            type="submit"
                                            name="cambiar_password"
                                        >

                                            💾 Guardar

                                        </button>


                                        <span class="info-password">

                                            La contraseña actual no puede
                                            mostrarse. Aquí puedes establecer
                                            una nueva.

                                        </span>


                                    </form>

                                </div>


                                <!-- ==================================
                                     ELIMINAR
                                =================================== -->

                                <?php if (
                                    $usuario["id"]
                                    != ($_SESSION["usuario_id"] ?? 0)
                                ): ?>


                                    <form
                                        method="POST"
                                        style="display:inline;"
                                        onsubmit="return confirmarEliminar(
                                            '<?= htmlspecialchars(
                                                $usuario["empleado"],
                                                ENT_QUOTES
                                            ) ?>'
                                        );"
                                    >

                                        <input
                                            type="hidden"
                                            name="usuario_id"
                                            value="<?= $usuario["id"] ?>"
                                        >


                                        <button
                                            type="submit"
                                            name="eliminar_usuario"
                                            class="btn btn-eliminar"
                                        >

                                            🗑️ Eliminar

                                        </button>

                                    </form>


                                <?php endif; ?>


                            </td>


                        </tr>


                    <?php endwhile; ?>


                <?php else: ?>


                    <tr>

                        <td
                            colspan="10"
                            style="
                                text-align:center;
                                padding:30px;
                            "
                        >

                            No hay usuarios registrados.

                        </td>

                    </tr>


                <?php endif; ?>


                </tbody>

            </table>

        </div>

    </div>


</div>


<!-- ==========================================
     FOOTER
========================================== -->

<footer class="footer">

    © <?= date("Y") ?>
    Sistema de Inventario

    |

    Administración de Usuarios

    |

    <strong>
        Grupo Protec
    </strong>

</footer>


</body>

</html>


<?php

// ==========================================
// CERRAR CONEXIÓN
// ==========================================

$conexion->close();

?>