<?php

require "conexion.php";

$id = intval($_GET["id"] ?? 0);

if ($id <= 0) {
    die("Artículo no válido.");
}

$stmt = $conexion->prepare(
    "DELETE FROM inventario WHERE id = ?"
);

$stmt->bind_param("i", $id);

$stmt->execute();

$stmt->close();

$conexion->close();

header("Location: index.php");
exit;

?>
