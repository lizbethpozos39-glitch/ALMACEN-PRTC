<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';
require_once __DIR__ . '/auditoria.php';

verificar_sesion();

$mensaje = "";
$error = "";


/*
|--------------------------------------------------------------------------
| OBTENER ÁREAS
|--------------------------------------------------------------------------
*/

$areas = [];

$sqlAreas = "
    SELECT
        id,
        nombre
    FROM areas
    WHERE activo = 1
    ORDER BY nombre ASC
";

$resultadoAreas = $conexion->query($sqlAreas);

if ($resultadoAreas) {

    while ($fila = $resultadoAreas->fetch_assoc()) {
        $areas[] = $fila;
    }
}


/*
|--------------------------------------------------------------------------
| OBTENER EMPLEADOS
|--------------------------------------------------------------------------
*/

$empleados = [];

$sqlEmpleados = "
    SELECT
        e.id,
        e.nombre,
        e.numero_empleado,
        e.area_id,
        e.puesto,
        a.nombre AS area_nombre
    FROM empleados e
    INNER JOIN areas a
        ON a.id = e.area_id
    WHERE e.activo = 1
      AND a.activo = 1
    ORDER BY a.nombre ASC, e.nombre ASC
";

$resultadoEmpleados = $conexion->query($sqlEmpleados);

if ($resultadoEmpleados) {

    while ($fila = $resultadoEmpleados->fetch_assoc()) {
        $empleados[] = $fila;
    }
}


/*
|--------------------------------------------------------------------------
| OBTENER INVENTARIO
|--------------------------------------------------------------------------
*/

$articulos = [];

$sqlArticulos = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        proveedor_marca
    FROM inventario
    WHERE cantidad > 0
    ORDER BY articulo_descripcion ASC
";

$resultadoArticulos = $conexion->query($sqlArticulos);

if ($resultadoArticulos) {

    while ($fila = $resultadoArticulos->fetch_assoc()) {
        $articulos[] = $fila;
    }
}


/*
|--------------------------------------------------------------------------
| PROCESAR SALIDA
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $folio = trim($_POST["folio"] ?? "");

    $fecha_salida = $_POST["fecha_salida"] ?? date("Y-m-d");

    $area_id = (int)($_POST["area_id"] ?? 0);

    $empleado_id = (int)($_POST["empleado_id"] ?? 0);

    $observaciones = trim($_POST["observaciones"] ?? "");

    $inventario_ids = $_POST["inventario_id"] ?? [];

    $cantidades = $_POST["cantidad"] ?? [];


    /*
    |--------------------------------------------------------------------------
    | VALIDACIONES
    |--------------------------------------------------------------------------
    */

    if ($folio === "") {

        $error = "Debes ingresar el folio de la nota de salida.";

    } elseif ($fecha_salida === "") {

        $error = "Debes ingresar la fecha.";

    } elseif ($area_id <= 0) {

        $error = "Debes seleccionar un área.";

    } elseif ($empleado_id <= 0) {

        $error = "Debes seleccionar a quién se entrega.";

    } elseif (empty($inventario_ids)) {

        $error = "Debes agregar por lo menos un artículo.";
    }


    /*
    |--------------------------------------------------------------------------
    | VALIDAR EMPLEADO Y ÁREA
    |--------------------------------------------------------------------------
    */

    if ($error === "") {

        $sqlValidarEmpleado = "
            SELECT
                e.id,
                e.nombre,
                e.area_id,
                a.nombre AS area_nombre
            FROM empleados e
            INNER JOIN areas a
                ON a.id = e.area_id
            WHERE e.id = ?
              AND e.area_id = ?
              AND e.activo = 1
              AND a.activo = 1
        ";

        $stmtValidarEmpleado = $conexion->prepare(
            $sqlValidarEmpleado
        );

        if (!$stmtValidarEmpleado) {

            $error = "Error preparando validación del empleado.";

        } else {

            $stmtValidarEmpleado->bind_param(
                "ii",
                $empleado_id,
                $area_id
            );

            $stmtValidarEmpleado->execute();

            $resultadoEmpleado =
                $stmtValidarEmpleado->get_result();

            $empleado =
                $resultadoEmpleado->fetch_assoc();

            $stmtValidarEmpleado->close();

            if (!$empleado) {

                $error =
                    "El empleado no pertenece al área seleccionada.";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | PROCESAR ARTÍCULOS
    |--------------------------------------------------------------------------
    */

    if ($error === "") {

        $lineas = [];

        $total_salida = 0;


        for (
            $i = 0;
            $i < count($inventario_ids);
            $i++
        ) {

            $inventario_id =
                (int)$inventario_ids[$i];

            $cantidad =
                isset($cantidades[$i])
                ? (float)$cantidades[$i]
                : 0;


            /*
            | Ignorar líneas vacías
            */

            if ($inventario_id <= 0) {
                continue;
            }


            if ($cantidad <= 0) {

                $error =
                    "La cantidad debe ser mayor a cero.";

                break;
            }


            /*
            |--------------------------------------------------------------------------
            | CONSULTAR ARTÍCULO
            |--------------------------------------------------------------------------
            */

            $sqlArticulo = "
                SELECT
                    id,
                    codigo,
                    articulo_descripcion,
                    cantidad
                FROM inventario
                WHERE id = ?
            ";

            $stmtArticulo =
                $conexion->prepare($sqlArticulo);

            if (!$stmtArticulo) {

                $error =
                    "Error consultando el artículo.";

                break;
            }

            $stmtArticulo->bind_param(
                "i",
                $inventario_id
            );

            if (!$stmtArticulo->execute()) {

                $error =
                    "Error consultando el artículo.";

                $stmtArticulo->close();

                break;
            }

            $resultadoArticulo =
                $stmtArticulo->get_result();

            $articulo =
                $resultadoArticulo->fetch_assoc();

            $stmtArticulo->close();


            if (!$articulo) {

                $error =
                    "El artículo seleccionado no existe.";

                break;
            }


            /*
            |--------------------------------------------------------------------------
            | VALIDAR EXISTENCIA
            |--------------------------------------------------------------------------
            */

            $existencia =
                (float)$articulo["cantidad"];


            if ($cantidad > $existencia) {

                $error =
                    "No puedes sacar " .
                    $cantidad .
                    " unidades de " .
                    $articulo["articulo_descripcion"] .
                    ". La existencia disponible es " .
                    $existencia .
                    ".";

                break;
            }


            /*
            |--------------------------------------------------------------------------
            | COSTO UNITARIO
            |--------------------------------------------------------------------------
            */

            $costo_unitario = 0;

            $importe =
                $cantidad * $costo_unitario;

            $total_salida += $importe;


            $lineas[] = [
                "inventario_id" =>
                    $inventario_id,

                "cantidad" =>
                    $cantidad,

                "codigo" =>
                    $articulo["codigo"],

                "descripcion" =>
                    $articulo["articulo_descripcion"],

                "costo_unitario" =>
                    $costo_unitario,

                "importe" =>
                    $importe
            ];
        }


        if (
            $error === "" &&
            empty($lineas)
        ) {

            $error =
                "Debes agregar por lo menos un artículo.";
        }
    }


    /*
    |--------------------------------------------------------------------------
    | REGISTRAR SALIDA
    |--------------------------------------------------------------------------
    */

    if ($error === "") {

        $conexion->begin_transaction();

        try {


            /*
            |--------------------------------------------------------------------------
            | ACTUALIZAR INVENTARIO Y MOVIMIENTOS
            |--------------------------------------------------------------------------
            */

            foreach ($lineas as $linea) {

                $inventario_id =
                    $linea["inventario_id"];

                $cantidad =
                    $linea["cantidad"];


                /*
                |--------------------------------------------------------------------------
                | BLOQUEAR ARTÍCULO
                |--------------------------------------------------------------------------
                */

                $sqlBloqueo = "
                    SELECT
                        id,
                        cantidad
                    FROM inventario
                    WHERE id = ?
                    FOR UPDATE
                ";

                $stmtBloqueo =
                    $conexion->prepare(
                        $sqlBloqueo
                    );

                if (!$stmtBloqueo) {

                    throw new Exception(
                        "Error preparando inventario."
                    );
                }

                $stmtBloqueo->bind_param(
                    "i",
                    $inventario_id
                );

                if (!$stmtBloqueo->execute()) {

                    $stmtBloqueo->close();

                    throw new Exception(
                        "Error consultando existencia."
                    );
                }

                $resultadoBloqueo =
                    $stmtBloqueo->get_result();

                $inventario =
                    $resultadoBloqueo->fetch_assoc();

                $stmtBloqueo->close();


                if (!$inventario) {

                    throw new Exception(
                        "El artículo ya no existe."
                    );
                }


                $cantidad_anterior =
                    (float)$inventario["cantidad"];


                /*
                |--------------------------------------------------------------------------
                | VALIDAR NUEVAMENTE EXISTENCIA
                |--------------------------------------------------------------------------
                */

                if (
                    $cantidad >
                    $cantidad_anterior
                ) {

                    throw new Exception(
                        "La existencia del artículo cambió. " .
                        "La salida no puede continuar."
                    );
                }


                $cantidad_nueva =
                    $cantidad_anterior - $cantidad;


                /*
                |--------------------------------------------------------------------------
                | ACTUALIZAR INVENTARIO
                |--------------------------------------------------------------------------
                */

                $sqlActualizar = "
                    UPDATE inventario
                    SET cantidad = ?
                    WHERE id = ?
                ";

                $stmtActualizar =
                    $conexion->prepare(
                        $sqlActualizar
                    );

                if (!$stmtActualizar) {

                    throw new Exception(
                        "Error preparando actualización."
                    );
                }

                $stmtActualizar->bind_param(
                    "di",
                    $cantidad_nueva,
                    $inventario_id
                );

                if (!$stmtActualizar->execute()) {

                    $stmtActualizar->close();

                    throw new Exception(
                        "Error actualizando inventario."
                    );
                }

                $stmtActualizar->close();


                /*
                |--------------------------------------------------------------------------
                | REGISTRAR MOVIMIENTO
                |--------------------------------------------------------------------------
                */

                $observacionMovimiento =
                    "Salida - Nota " .
                    $folio .
                    " - Entregado a: " .
                    $empleado["nombre"] .
                    " - Área: " .
                    $empleado["area_nombre"];


                if ($observaciones !== "") {

                    $observacionMovimiento .=
                        " - " .
                        $observaciones;
                }


                $sqlMovimiento = "
                    INSERT INTO movimientos_inventario
                    (
                        inventario_id,
                        tipo,
                        cantidad,
                        cantidad_anterior,
                        cantidad_nueva,
                        factura_id,
                        observaciones
                    )
                    VALUES
                    (
                        ?,
                        'SALIDA',
                        ?,
                        ?,
                        ?,
                        NULL,
                        ?
                    )
                ";

                $stmtMovimiento =
                    $conexion->prepare(
                        $sqlMovimiento
                    );

                if (!$stmtMovimiento) {

                    throw new Exception(
                        "Error preparando movimiento."
                    );
                }

                $stmtMovimiento->bind_param(
                    "iddds",
                    $inventario_id,
                    $cantidad,
                    $cantidad_anterior,
                    $cantidad_nueva,
                    $observacionMovimiento
                );

                if (!$stmtMovimiento->execute()) {

                    $stmtMovimiento->close();

                    throw new Exception(
                        "Error registrando movimiento."
                    );
                }

                $stmtMovimiento->close();
            }


            /*
            |--------------------------------------------------------------------------
            | CONFIRMAR TRANSACCIÓN
            |--------------------------------------------------------------------------
            */

            $conexion->commit();


            /*
            |--------------------------------------------------------------------------
            | REGISTRAR AUDITORÍA
            |--------------------------------------------------------------------------
            |
            | IMPORTANTE:
            | Se registra después del commit para que la auditoría
            | no interfiera con la salida de almacén.
            |
            */

            $cantidad_lineas =
                count($lineas);


            $detalleArticulos = [];


            foreach ($lineas as $linea) {

                $detalleArticulos[] =
                    $linea["codigo"] .
                    " - " .
                    $linea["descripcion"] .
                    " (" .
                    number_format(
                        $linea["cantidad"],
                        3
                    ) .
                    " pzas)";
            }


            $descripcionAuditoria =
                "Salida de almacén registrada. " .
                "Folio: " .
                $folio .
                " | Fecha: " .
                $fecha_salida .
                " | Entregado a: " .
                $empleado["nombre"] .
                " | Área: " .
                $empleado["area_nombre"] .
                " | Artículos: " .
                $cantidad_lineas .
                " | Detalle: " .
                implode(
                    " | ",
                    $detalleArticulos
                );


            if ($observaciones !== "") {

                $descripcionAuditoria .=
                    " | Observaciones: " .
                    $observaciones;
            }


            registrar_auditoria(
                $conexion,
                'SALIDA',
                'Almacén',
                $descripcionAuditoria
            );


            /*
            |--------------------------------------------------------------------------
            | MENSAJE
            |--------------------------------------------------------------------------
            */

            $mensaje =
                "Salida registrada correctamente. " .
                "Folio: " .
                htmlspecialchars($folio) .
                " | Total: $" .
                number_format(
                    $total_salida,
                    2
                );


            $_POST = [];

        }

        catch (Exception $e) {

            $conexion->rollback();

            $error =
                $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| DATOS DEL USUARIO
|--------------------------------------------------------------------------
*/

$nombre_empleado =
    $_SESSION['nombre_empleado'] ?? 'Usuario';

$rol_usuario =
    $_SESSION['rol'] ?? 'USUARIO';

?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Nota de salida - Grupo Protec
    </title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {

            margin: 0;

            font-family:
                Arial,
                sans-serif;

            background: #f4f6f9;

            color: #212529;
        }


        /*
        |--------------------------------------------------------------------------
        | CONTENIDO PRINCIPAL
        |--------------------------------------------------------------------------
        */

        .contenido-principal {

            margin-left: 240px;

            min-height: 100vh;

            padding: 25px;
        }


        /*
        |--------------------------------------------------------------------------
        | BARRA SUPERIOR
        |--------------------------------------------------------------------------
        */

        .barra-superior {

            display: flex;

            justify-content: space-between;

            align-items: center;

            background: #ffffff;

            padding: 15px 20px;

            border-radius: 8px;

            margin-bottom: 20px;

            box-shadow:
                0 2px 8px rgba(0,0,0,0.08);
        }


        .titulo-superior {

            font-size: 22px;

            font-weight: bold;
        }


        .usuario-superior {

            font-size: 14px;

            color: #555;
        }


        /*
        |--------------------------------------------------------------------------
        | FORMATO DE SALIDA
        |--------------------------------------------------------------------------
        */

        .formato-salida {

            background: #ffffff;

            padding: 25px;

            border-radius: 10px;

            box-shadow:
                0 2px 8px rgba(0,0,0,0.08);
        }


        /*
        |--------------------------------------------------------------------------
        | ENCABEZADO DE LA NOTA
        |--------------------------------------------------------------------------
        */

        .encabezado-nota {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 25px;

            border-bottom:
                2px solid #222;

            padding-bottom: 15px;

            margin-bottom: 25px;
        }


        .logo-empresa {

            width: 150px;

            max-height: 90px;

            object-fit: contain;
        }


        .datos-empresa {

            flex: 1;

            text-align: center;
        }


        .nombre-empresa {

            font-size: 24px;

            font-weight: bold;

            margin-bottom: 6px;
        }


        .direccion-empresa {

            font-size: 12px;

            color: #555;
        }


        .titulo-nota {

            text-align: right;

            font-size: 22px;

            font-weight: bold;
        }


        /*
        |--------------------------------------------------------------------------
        | CAMPOS
        |--------------------------------------------------------------------------
        */

        .grid {

            display: grid;

            grid-template-columns:
                repeat(
                    auto-fit,
                    minmax(220px, 1fr)
                );

            gap: 18px;
        }


        .campo {

            display: flex;

            flex-direction: column;
        }


        .campo label {

            font-weight: bold;

            margin-bottom: 6px;
        }


        .campo input,
        .campo select,
        .campo textarea {

            padding: 10px;

            border:
                1px solid #ced4da;

            border-radius: 5px;

            font-size: 14px;
        }


        .campo small {

            color: #6c757d;

            margin-top: 4px;
        }


        /*
        |--------------------------------------------------------------------------
        | TABLA
        |--------------------------------------------------------------------------
        */

        .seccion-articulos {

            margin-top: 30px;
        }


        .tabla-contenedor {

            overflow-x: auto;
        }


        .tabla {

            width: 100%;

            border-collapse: collapse;

            margin-top: 15px;

            min-width: 900px;
        }


        .tabla th {

            background: #212529;

            color: #ffffff;

            padding: 10px;

            text-align: left;
        }


        .tabla td {

            padding: 8px;

            border-bottom:
                1px solid #ddd;
        }


        .tabla input,
        .tabla select {

            width: 100%;

            padding: 8px;

            border:
                1px solid #ced4da;

            border-radius: 4px;
        }


        /*
        |--------------------------------------------------------------------------
        | EXISTENCIA
        |--------------------------------------------------------------------------
        */

        .existencia {

            display: block;

            margin-top: 4px;

            font-size: 12px;

            color: #198754;

            font-weight: bold;
        }


        /*
        |--------------------------------------------------------------------------
        | BOTONES
        |--------------------------------------------------------------------------
        */

        .boton {

            border: none;

            border-radius: 5px;

            padding: 10px 16px;

            cursor: pointer;

            font-size: 14px;
        }


        .boton-agregar {

            background: #198754;

            color: white;

            margin-top: 15px;
        }


        .boton-eliminar {

            background: #dc3545;

            color: white;
        }


        .boton-cancelar {

            background: #6c757d;

            color: white;

            text-decoration: none;
        }


        .boton-registrar {

            background: #0d6efd;

            color: white;
        }


        /*
        |--------------------------------------------------------------------------
        | RESUMEN
        |--------------------------------------------------------------------------
        */

        .resumen {

            max-width: 450px;

            margin-left: auto;

            margin-top: 25px;

            background: #f8f9fa;

            padding: 20px;

            border-radius: 8px;
        }


        .resumen-fila {

            display: flex;

            justify-content:
                space-between;

            padding: 8px 0;

            border-bottom:
                1px solid #ddd;
        }


        .resumen-total {

            font-size: 20px;

            border-bottom: none;
        }


        /*
        |--------------------------------------------------------------------------
        | ALERTAS
        |--------------------------------------------------------------------------
        */

        .alerta {

            padding: 15px;

            border-radius: 6px;

            margin-bottom: 20px;
        }


        .alerta-exito {

            background: #d1e7dd;

            color: #0f5132;
        }


        .alerta-error {

            background: #f8d7da;

            color: #842029;
        }


        /*
        |--------------------------------------------------------------------------
        | BOTONES FINALES
        |--------------------------------------------------------------------------
        */

        .botones {

            display: flex;

            justify-content: flex-end;

            gap: 10px;

            margin-top: 25px;
        }


        /*
        |--------------------------------------------------------------------------
        | RESPONSIVE
        |--------------------------------------------------------------------------
        */

        @media (max-width: 850px) {

            .contenido-principal {

                margin-left: 0;

                padding: 15px;
            }

            .encabezado-nota {

                flex-direction: column;

                text-align: center;
            }

            .titulo-nota {

                text-align: center;
            }

            .barra-superior {

                flex-direction: column;

                align-items: flex-start;

                gap: 8px;
            }
        }


        @media (max-width: 600px) {

            .contenido-principal {

                padding: 10px;
            }

            .formato-salida {

                padding: 15px;
            }

            .nombre-empresa {

                font-size: 20px;
            }

            .titulo-nota {

                font-size: 20px;
            }

            .botones {

                flex-direction: column;
            }

            .botones .boton {

                width: 100%;

                text-align: center;
            }
        }

    </style>

</head>


<body>


<?php include 'menu.php'; ?>


<main class="contenido-principal">


    <!-- ==========================================================
         BARRA SUPERIOR
    =========================================================== -->

    <header class="barra-superior">

        <div class="titulo-superior">

            📤 Salida de almacén

        </div>


        <div class="usuario-superior">

            Usuario:

            <strong>
                <?= htmlspecialchars($nombre_empleado) ?>
            </strong>

        </div>

    </header>


    <div class="formato-salida">


        <!-- ==========================================================
             ENCABEZADO
        =========================================================== -->

        <div class="encabezado-nota">


            <div>

                <?php

                $logo = "";

                $posiblesLogos = [

                    __DIR__ . "/img/logo.png",

                    __DIR__ . "/img/logo.jpg",

                    __DIR__ . "/img/logo.jpeg",

                    __DIR__ . "/img/logo.webp",

                    __DIR__ . "/img/logo.gif"

                ];


                foreach ($posiblesLogos as $rutaLogo) {

                    if (file_exists($rutaLogo)) {

                        $logo =
                            str_replace(
                                __DIR__,
                                "",
                                $rutaLogo
                            );

                        break;
                    }
                }

                ?>


                <?php if ($logo !== ""): ?>

                    <img
                        src="<?= htmlspecialchars($logo) ?>"
                        class="logo-empresa"
                        alt="Logo Grupo Protec"
                    >

                <?php else: ?>

                    <div
                        style="
                            width:150px;
                            height:80px;
                            border:1px dashed #999;
                            display:flex;
                            align-items:center;
                            justify-content:center;
                            color:#777;
                            font-size:12px;
                            text-align:center;
                        "
                    >

                        Coloca el logo en<br>
                        la carpeta img

                    </div>

                <?php endif; ?>


            </div>


            <div class="datos-empresa">

                <div class="nombre-empresa">

                    GRUPO PROTEC, S.A DE C.V

                </div>


                <div class="direccion-empresa">

                    16 Sta. Ma. de Aguayo No.210, Los Pinos
                    Tel 834 312 01 29,
                    Cd.Victoria, Tamaulipas, Mexico

                </div>

            </div>


            <div class="titulo-nota">

                NOTA DE<br>
                SALIDA

            </div>


        </div>


        <?php if ($mensaje !== ""): ?>

            <div class="alerta alerta-exito">

                <?= $mensaje ?>

            </div>

        <?php endif; ?>


        <?php if ($error !== ""): ?>

            <div class="alerta alerta-error">

                <?= htmlspecialchars($error) ?>

            </div>

        <?php endif; ?>


        <form
            method="POST"
            id="formSalida"
        >


            <!-- ======================================================
                 DATOS GENERALES
            ======================================================= -->

            <h2>

                Datos de la salida

            </h2>


            <div class="grid">


                <div class="campo">

                    <label for="folio">

                        Folio de nota de salida

                    </label>

                    <input
                        type="text"
                        name="folio"
                        id="folio"
                        value="<?= htmlspecialchars(
                            $_POST["folio"] ?? ""
                        ) ?>"
                        placeholder="Ej. NS-000125"
                        required
                    >

                    <small>

                        Captura el número consecutivo
                        que aparece en tu formato de papel.

                    </small>

                </div>


                <div class="campo">

                    <label for="fecha_salida">

                        Fecha

                    </label>

                    <input
                        type="date"
                        name="fecha_salida"
                        id="fecha_salida"
                        value="<?= htmlspecialchars(
                            $_POST["fecha_salida"]
                            ?? date("Y-m-d")
                        ) ?>"
                        required
                    >

                </div>


                <!-- ==================================================
                     ÁREA
                =================================================== -->

                <div class="campo">

                    <label for="area_id">

                        Área

                    </label>

                    <select
                        name="area_id"
                        id="area_id"
                        required
                    >

                        <option value="">

                            -- Seleccionar área --

                        </option>


                        <?php foreach ($areas as $area): ?>

                            <option
                                value="<?= $area["id"] ?>"
                                <?= (
                                    isset(
                                        $_POST["area_id"]
                                    ) &&
                                    $_POST["area_id"]
                                    == $area["id"]
                                )
                                ? "selected"
                                : ""
                                ?>
                            >

                                <?= htmlspecialchars(
                                    $area["nombre"]
                                ) ?>

                            </option>

                        <?php endforeach; ?>


                    </select>

                </div>


                <!-- ==================================================
                     EMPLEADO
                =================================================== -->

                <div class="campo">

                    <label for="empleado_id">

                        Se entrega a

                    </label>

                    <select
                        name="empleado_id"
                        id="empleado_id"
                        required
                    >

                        <option value="">

                            -- Primero selecciona área --

                        </option>


                        <?php foreach ($empleados as $empleado): ?>

                            <option
                                value="<?= $empleado["id"] ?>"
                                data-area="<?= $empleado["area_id"] ?>"
                                <?= (
                                    isset(
                                        $_POST["empleado_id"]
                                    ) &&
                                    $_POST["empleado_id"]
                                    == $empleado["id"]
                                )
                                ? "selected"
                                : ""
                                ?>
                            >

                                <?= htmlspecialchars(
                                    $empleado["nombre"]
                                ) ?>

                                -
                                <?= htmlspecialchars(
                                    $empleado["area_nombre"]
                                ) ?>

                            </option>

                        <?php endforeach; ?>


                    </select>

                </div>


            </div>


            <!-- ======================================================
                 ARTÍCULOS
            ======================================================= -->

            <div class="seccion-articulos">


                <h2>

                    Artículos de la salida

                </h2>


                <div class="tabla-contenedor">


                    <table class="tabla">


                        <thead>

                            <tr>

                                <th>
                                    Artículo
                                </th>

                                <th style="width:110px;">
                                    Existencia
                                </th>

                                <th style="width:110px;">
                                    Cantidad
                                </th>

                                <th style="width:110px;">
                                    Unidad
                                </th>

                                <th style="width:140px;">
                                    Costo unitario
                                </th>

                                <th style="width:140px;">
                                    Importe
                                </th>

                                <th style="width:80px;">
                                    Acción
                                </th>

                            </tr>

                        </thead>


                        <tbody id="contenedorArticulos">


                            <tr class="fila-articulo">


                                <!-- ==================================
                                     ARTÍCULO
                                =================================== -->

                                <td>

                                    <select
                                        name="inventario_id[]"
                                        class="articulo"
                                        required
                                    >

                                        <option value="">

                                            -- Seleccionar artículo --

                                        </option>


                                        <?php foreach (
                                            $articulos
                                            as $articulo
                                        ): ?>

                                            <option
                                                value="<?= $articulo["id"] ?>"
                                                data-existencia="<?= $articulo["cantidad"] ?>"
                                                data-costo="0"
                                            >

                                                <?= htmlspecialchars(
                                                    $articulo["codigo"]
                                                ) ?>

                                                -
                                                <?= htmlspecialchars(
                                                    $articulo[
                                                        "articulo_descripcion"
                                                    ]
                                                ) ?>

                                            </option>

                                        <?php endforeach; ?>


                                    </select>


                                    <span class="existencia"></span>

                                </td>


                                <!-- ==================================
                                     EXISTENCIA
                                =================================== -->

                                <td>

                                    <input
                                        type="text"
                                        class="existencia-input"
                                        value="0"
                                        readonly
                                    >

                                </td>


                                <!-- ==================================
                                     CANTIDAD
                                =================================== -->

                                <td>

                                    <input
                                        type="number"
                                        name="cantidad[]"
                                        class="cantidad"
                                        min="0.001"
                                        step="0.001"
                                        value="1"
                                        required
                                    >

                                </td>


                                <!-- ==================================
                                     UNIDAD
                                =================================== -->

                                <td>

                                    <input
                                        type="text"
                                        class="unidad"
                                        value="PZA"
                                        readonly
                                    >

                                </td>


                                <!-- ==================================
                                     COSTO
                                =================================== -->

                                <td>

                                    <input
                                        type="number"
                                        class="costo-unitario"
                                        value="0"
                                        readonly
                                    >

                                </td>


                                <!-- ==================================
                                     IMPORTE
                                =================================== -->

                                <td>

                                    <input
                                        type="number"
                                        class="importe-linea"
                                        value="0.00"
                                        readonly
                                    >

                                </td>


                                <!-- ==================================
                                     ELIMINAR
                                =================================== -->

                                <td>

                                    <button
                                        type="button"
                                        class="boton boton-eliminar"
                                        onclick="eliminarFila(this)"
                                    >

                                        ✕

                                    </button>

                                </td>


                            </tr>


                        </tbody>

                    </table>

                </div>


                <button
                    type="button"
                    class="boton boton-agregar"
                    onclick="agregarArticulo()"
                >

                    + Agregar otro artículo

                </button>


            </div>


            <!-- ======================================================
                 TOTAL
            ======================================================= -->

            <div class="resumen">


                <div class="resumen-fila">

                    <span>

                        Total de artículos:

                    </span>

                    <strong id="totalArticulos">

                        0

                    </strong>

                </div>


                <div class="resumen-fila">

                    <span>

                        Monto total de la salida:

                    </span>

                    <strong
                        id="total"
                        class="resumen-total"
                    >

                        $0.00

                    </strong>

                </div>


            </div>


            <!-- ======================================================
                 OBSERVACIONES
            ======================================================= -->

            <div
                class="campo"
                style="margin-top:25px;"
            >

                <label for="observaciones">

                    Observaciones

                </label>

                <textarea
                    name="observaciones"
                    id="observaciones"
                    rows="4"
                    placeholder="Observaciones de la salida..."
                ><?= htmlspecialchars(
                    $_POST["observaciones"] ?? ""
                ) ?></textarea>

            </div>


            <!-- ======================================================
                 BOTONES
            ======================================================= -->

            <div class="botones">


                <a
                    href="index.php"
                    class="boton boton-cancelar"
                >

                    Cancelar

                </a>


                <button
                    type="submit"
                    class="boton boton-registrar"
                >

                    📤 Registrar salida

                </button>


            </div>


        </form>

    </div>

</main>


<script>

/*
|--------------------------------------------------------------------------
| DATOS DE EMPLEADOS
|--------------------------------------------------------------------------
*/

const empleados =
    <?= json_encode(
        $empleados,
        JSON_UNESCAPED_UNICODE
    ) ?>;


/*
|--------------------------------------------------------------------------
| FILTRAR EMPLEADOS POR ÁREA
|--------------------------------------------------------------------------
*/

document
    .getElementById("area_id")
    .addEventListener(
        "change",
        function() {

            const areaId =
                this.value;

            const empleadoSelect =
                document.getElementById(
                    "empleado_id"
                );


            empleadoSelect.innerHTML =
                '<option value="">-- Seleccionar empleado --</option>';


            if (!areaId) {

                empleadoSelect.innerHTML =
                    '<option value="">-- Primero selecciona área --</option>';

                return;
            }


            empleados.forEach(
                function(empleado) {

                    if (
                        String(
                            empleado.area_id
                        ) === String(areaId)
                    ) {

                        const opcion =
                            document.createElement(
                                "option"
                            );

                        opcion.value =
                            empleado.id;

                        opcion.textContent =
                            empleado.nombre +
                            (
                                empleado.puesto
                                ? " - " +
                                  empleado.puesto
                                : ""
                            );

                        empleadoSelect.appendChild(
                            opcion
                        );
                    }

                }
            );

        }
    );


/*
|--------------------------------------------------------------------------
| ACTUALIZAR ARTÍCULO
|--------------------------------------------------------------------------
*/

function actualizarArticulo(fila) {

    const select =
        fila.querySelector(
            ".articulo"
        );


    const opcion =
        select.options[
            select.selectedIndex
        ];


    if (!opcion || !opcion.value) {

        fila.querySelector(
            ".existencia-input"
        ).value = "0";


        fila.querySelector(
            ".cantidad"
        ).value = "1";


        fila.querySelector(
            ".cantidad"
        ).max = "";


        fila.querySelector(
            ".costo-unitario"
        ).value = "0";


        fila.querySelector(
            ".importe-linea"
        ).value = "0.00";


        return;
    }


    /*
    |--------------------------------------------------------------------------
    | EXISTENCIA
    |--------------------------------------------------------------------------
    */

    const existencia =
        parseFloat(
            opcion.dataset.existencia
        ) || 0;


    /*
    |--------------------------------------------------------------------------
    | COSTO
    |--------------------------------------------------------------------------
    */

    const costo =
        parseFloat(
            opcion.dataset.costo
        ) || 0;


    /*
    |--------------------------------------------------------------------------
    | MOSTRAR EXISTENCIA
    |--------------------------------------------------------------------------
    */

    fila.querySelector(
        ".existencia-input"
    ).value =
        existencia.toFixed(3);


    /*
    |--------------------------------------------------------------------------
    | PONER MÁXIMO A CANTIDAD
    |--------------------------------------------------------------------------
    */

    fila.querySelector(
        ".cantidad"
    ).max = existencia;


    /*
    |--------------------------------------------------------------------------
    | COSTO AUTOMÁTICO
    |--------------------------------------------------------------------------
    */

    fila.querySelector(
        ".costo-unitario"
    ).value =
        costo.toFixed(2);


    /*
    |--------------------------------------------------------------------------
    | CALCULAR
    |--------------------------------------------------------------------------
    */

    calcularTotales();
}


/*
|--------------------------------------------------------------------------
| CALCULAR IMPORTE DE LÍNEA
|--------------------------------------------------------------------------
*/

function calcularImporteLinea(fila) {

    const cantidad =
        parseFloat(
            fila.querySelector(
                ".cantidad"
            ).value
        ) || 0;


    const costo =
        parseFloat(
            fila.querySelector(
                ".costo-unitario"
            ).value
        ) || 0;


    const importe =
        cantidad * costo;


    fila.querySelector(
        ".importe-linea"
    ).value =
        importe.toFixed(2);


    return importe;
}


/*
|--------------------------------------------------------------------------
| CALCULAR TOTALES
|--------------------------------------------------------------------------
*/

function calcularTotales() {

    let total = 0;

    let cantidadArticulos = 0;


    const filas =
        document.querySelectorAll(
            ".fila-articulo"
        );


    filas.forEach(
        function(fila) {

            const select =
                fila.querySelector(
                    ".articulo"
                );


            if (
                select &&
                select.value
            ) {

                total +=
                    calcularImporteLinea(
                        fila
                    );


                cantidadArticulos++;
            }

        }
    );


    document.getElementById(
        "total"
    ).textContent =
        "$" + total.toFixed(2);


    document.getElementById(
        "totalArticulos"
    ).textContent =
        cantidadArticulos;

}


/*
|--------------------------------------------------------------------------
| AGREGAR ARTÍCULO
|--------------------------------------------------------------------------
*/

function agregarArticulo() {

    const contenedor =
        document.getElementById(
            "contenedorArticulos"
        );


    const primeraFila =
        document.querySelector(
            ".fila-articulo"
        );


    const nuevaFila =
        primeraFila.cloneNode(true);


    /*
    |--------------------------------------------------------------------------
    | LIMPIAR
    |--------------------------------------------------------------------------
    */

    nuevaFila.querySelector(
        ".articulo"
    ).value = "";


    nuevaFila.querySelector(
        ".existencia-input"
    ).value = "0";


    nuevaFila.querySelector(
        ".cantidad"
    ).value = "1";


    nuevaFila.querySelector(
        ".cantidad"
    ).max = "";


    nuevaFila.querySelector(
        ".costo-unitario"
    ).value = "0";


    nuevaFila.querySelector(
        ".importe-linea"
    ).value = "0.00";


    nuevaFila.querySelector(
        ".existencia"
    ).textContent = "";


    contenedor.appendChild(
        nuevaFila
    );


    calcularTotales();
}


/*
|--------------------------------------------------------------------------
| ELIMINAR FILA
|--------------------------------------------------------------------------
*/

function eliminarFila(boton) {

    const filas =
        document.querySelectorAll(
            ".fila-articulo"
        );


    if (filas.length <= 1) {

        alert(
            "Debe existir por lo menos un artículo."
        );

        return;
    }


    boton
        .closest(".fila-articulo")
        .remove();


    calcularTotales();
}


/*
|--------------------------------------------------------------------------
| CAMBIO DE ARTÍCULO
|--------------------------------------------------------------------------
*/

document.addEventListener(
    "change",
    function(evento) {

        if (
            evento.target.classList
                .contains("articulo")
        ) {

            actualizarArticulo(
                evento.target.closest(
                    ".fila-articulo"
                )
            );

        }

    }
);


/*
|--------------------------------------------------------------------------
| CAMBIO DE CANTIDAD
|--------------------------------------------------------------------------
*/

document.addEventListener(
    "input",
    function(evento) {

        if (
            evento.target.classList
                .contains("cantidad")
        ) {

            const fila =
                evento.target.closest(
                    ".fila-articulo"
                );


            const select =
                fila.querySelector(
                    ".articulo"
                );


            const opcion =
                select.options[
                    select.selectedIndex
                ];


            if (
                opcion &&
                opcion.value
            ) {

                const existencia =
                    parseFloat(
                        opcion.dataset
                            .existencia
                    ) || 0;


                const cantidad =
                    parseFloat(
                        evento.target.value
                    ) || 0;


                if (
                    cantidad >
                    existencia
                ) {

                    alert(
                        "No puedes sacar más de " +
                        existencia +
                        " unidades."
                    );


                    evento.target.value =
                        existencia;
                }

            }


            calcularTotales();
        }

    }
);


/*
|--------------------------------------------------------------------------
| VALIDACIÓN ANTES DE GUARDAR
|--------------------------------------------------------------------------
*/

document
    .getElementById("formSalida")
    .addEventListener(
        "submit",
        function(evento) {

            const filas =
                document.querySelectorAll(
                    ".fila-articulo"
                );


            let correcto = true;


            filas.forEach(
                function(fila) {

                    const select =
                        fila.querySelector(
                            ".articulo"
                        );


                    if (!select.value) {

                        correcto = false;

                        return;
                    }


                    const opcion =
                        select.options[
                            select.selectedIndex
                        ];


                    const existencia =
                        parseFloat(
                            opcion.dataset
                                .existencia
                        ) || 0;


                    const cantidad =
                        parseFloat(
                            fila.querySelector(
                                ".cantidad"
                            ).value
                        ) || 0;


                    if (
                        cantidad <= 0 ||
                        cantidad > existencia
                    ) {

                        correcto = false;
                    }

                }
            );


            if (!correcto) {

                evento.preventDefault();

                alert(
                    "Revisa los artículos y las cantidades. " +
                    "No puedes sacar más piezas de las existentes."
                );

                return;
            }


            /*
            |--------------------------------------------------------------------------
            | CONFIRMACIÓN
            |--------------------------------------------------------------------------
            */

            const folio =
                document.getElementById(
                    "folio"
                ).value;


            const empleado =
                document.getElementById(
                    "empleado_id"
                );


            const nombreEmpleado =
                empleado.options[
                    empleado.selectedIndex
                ].text;


            const total =
                document.getElementById(
                    "total"
                ).textContent;


            const confirmar =
                confirm(
                    "¿Deseas registrar esta salida?\n\n" +
                    "Folio: " + folio + "\n" +
                    "Entregado a: " +
                    nombreEmpleado + "\n" +
                    "Total: " + total
                );


            if (!confirmar) {

                evento.preventDefault();

            }

        }
    );


/*
|--------------------------------------------------------------------------
| CÁLCULO INICIAL
|--------------------------------------------------------------------------
*/

calcularTotales();

</script>


</body>

</html>