<?php
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

require_once __DIR__ . '/conexion.php';

/* =========================================================
   VALIDAR ID DE FACTURA
========================================================= */

$id = intval($_GET["id"] ?? 0);

if ($id <= 0) {
    die("Factura no válida.");
}


/* =========================================================
   OBTENER FACTURA
========================================================= */

$stmt = $conexion->prepare("
    SELECT
        id,
        rfc_emisor,
        nombre_emisor,
        rfc_receptor,
        nombre_receptor,
        numero_factura,
        fecha_factura,
        subtotal,
        tasa_iva,
        iva,
        total,
        moneda,
        fecha_registro
    FROM facturas
    WHERE id = ?
");

$stmt->bind_param("i", $id);
$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    die("La factura no existe.");
}

$factura = $resultado->fetch_assoc();

$stmt->close();


/* =========================================================
   OBTENER DETALLES
========================================================= */

$detalles = [];

$sql_detalles = "
    SELECT
        fd.*,
        i.codigo,
        i.articulo_descripcion
    FROM factura_detalles fd
    LEFT JOIN inventario i
        ON i.id = fd.inventario_id
    WHERE fd.factura_id = ?
    ORDER BY fd.id ASC
";

$stmt_detalles = $conexion->prepare($sql_detalles);

if ($stmt_detalles) {

    $stmt_detalles->bind_param("i", $id);
    $stmt_detalles->execute();

    $resultado_detalles = $stmt_detalles->get_result();

    while ($fila = $resultado_detalles->fetch_assoc()) {
        $detalles[] = $fila;
    }

    $stmt_detalles->close();
}


/* =========================================================
   FUNCIONES PARA ENCONTRAR LOS CAMPOS DEL DETALLE
   =========================================================
   Esto permite trabajar aunque los nombres usados en
   factura_detalles sean ligeramente diferentes.
========================================================= */

function obtenerCampo($fila, $posibles, $default = 0)
{
    foreach ($posibles as $campo) {

        if (array_key_exists($campo, $fila)) {

            if ($fila[$campo] !== null && $fila[$campo] !== "") {
                return $fila[$campo];
            }
        }
    }

    return $default;
}


/* =========================================================
   IVA
========================================================= */

$tasa_iva = isset($factura["tasa_iva"])
    ? floatval($factura["tasa_iva"])
    : 0;


/* =========================================================
   MONEDA
========================================================= */

$moneda = $factura["moneda"] ?? "MXN";

$simbolo_moneda = "$";

if ($moneda === "USD") {
    $simbolo_moneda = "US$";
}


/* =========================================================
   LOGO
========================================================= */

$logo = "";

$posibles_logos = [
    "img/logo.png",
    "img/logo.jpg",
    "img/logo.jpeg",
    "img/logo.webp",
    "img/logo.gif"
];

foreach ($posibles_logos as $archivo_logo) {

    if (file_exists(__DIR__ . "/" . $archivo_logo)) {

        $logo = $archivo_logo;
        break;
    }
}

?>

<?php require_once __DIR__ . '/header.php'; ?>


<style>

.factura-contenedor {

    background: white;

    max-width: 1100px;

    margin: 0 auto;

    padding: 35px;

    border-radius: 10px;

    box-shadow:
        0 2px 10px rgba(0,0,0,.10);

}


/* =========================================================
   ENCABEZADO EMPRESA
========================================================= */

.encabezado-empresa {

    display: flex;

    align-items: center;

    gap: 20px;

    border-bottom: 2px solid #212529;

    padding-bottom: 20px;

    margin-bottom: 25px;

}

.logo-empresa {

    max-width: 130px;

    max-height: 80px;

    object-fit: contain;

}

.datos-empresa h1 {

    margin: 0;

    font-size: 23px;

    color: #212529;

}

.datos-empresa p {

    margin: 5px 0 0 0;

    font-size: 12px;

    color: #555;

}


/* =========================================================
   TITULO
========================================================= */

.titulo-factura {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;

    gap: 20px;

    margin-bottom: 25px;

}

.titulo-factura h2 {

    margin: 0;

    font-size: 26px;

}

.folio {

    font-size: 18px;

    font-weight: bold;

}


/* =========================================================
   INFORMACIÓN
========================================================= */

.info-grid {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 20px;

    margin-bottom: 30px;

}

.info-bloque {

    border: 1px solid #ddd;

    border-radius: 7px;

    padding: 15px;

}

.info-bloque h3 {

    margin-top: 0;

    margin-bottom: 12px;

    font-size: 16px;

    color: #212529;

}

.info-linea {

    margin-bottom: 6px;

    font-size: 14px;

}

.info-linea strong {

    display: inline-block;

    min-width: 120px;

}


/* =========================================================
   TABLA
========================================================= */

.tabla-contenedor {

    overflow-x: auto;

    margin-top: 20px;

}

table {

    width: 100%;

    border-collapse: collapse;

    min-width: 750px;

}

th {

    background: #212529;

    color: white;

    padding: 11px;

    text-align: left;

    font-size: 13px;

}

td {

    padding: 10px;

    border-bottom: 1px solid #ddd;

    font-size: 13px;

}

td.numero {

    text-align: right;

}

.descripcion {

    font-weight: bold;

}


/* =========================================================
   TOTALES
========================================================= */

.totales {

    width: 350px;

    max-width: 100%;

    margin-left: auto;

    margin-top: 25px;

}

.total-linea {

    display: flex;

    justify-content: space-between;

    padding: 7px 0;

    border-bottom: 1px solid #ddd;

}

.total-final {

    font-size: 20px;

    font-weight: bold;

    color: #198754;

    border-bottom: 3px double #212529;

    padding-top: 12px;

}


/* =========================================================
   BOTONES
========================================================= */

.botones {

    display: flex;

    gap: 10px;

    margin-top: 30px;

    flex-wrap: wrap;

}

.boton {

    display: inline-block;

    padding: 10px 16px;

    border-radius: 5px;

    text-decoration: none;

    border: none;

    cursor: pointer;

    font-size: 14px;

}

.regresar {

    background: #6c757d;

    color: white;

}

.imprimir {

    background: #0d6efd;

    color: white;

}


/* =========================================================
   SIN DETALLES
========================================================= */

.sin-detalles {

    text-align: center;

    padding: 30px;

    color: #777;

    background: #f8f9fa;

    border-radius: 6px;

}


/* =========================================================
   IMPRESIÓN
========================================================= */

@media print {

    body {

        background: white !important;

    }

    .barra-superior,
    .footer,
    .botones {

        display: none !important;

    }

    .pagina {

        width: 100% !important;

        max-width: none !important;

        margin: 0 !important;

    }

    .factura-contenedor {

        box-shadow: none !important;

        border-radius: 0 !important;

        max-width: none !important;

        padding: 10px !important;

    }

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 700px) {

    .factura-contenedor {

        padding: 20px;

    }

    .info-grid {

        grid-template-columns: 1fr;

    }

    .titulo-factura {

        flex-direction: column;

    }

}

</style>


<div class="factura-contenedor">


    <!-- =====================================================
         ENCABEZADO DE LA EMPRESA
    ====================================================== -->

    <div class="encabezado-empresa">


        <?php if ($logo !== ""): ?>

            <img
                src="<?= htmlspecialchars($logo) ?>"
                class="logo-empresa"
                alt="Logo Grupo Protec"
            >

        <?php endif; ?>


        <div class="datos-empresa">

            <h1>
                GRUPO PROTEC, S.A DE C.V
            </h1>

            <p>
                16 Sta. Ma. de Aguayo No.210, Los Pinos
                Tel 834 312 01 29, Cd.Victoria,
                Tamaulipas, Mexico
            </p>

        </div>

    </div>



    <!-- =====================================================
         TITULO
    ====================================================== -->

    <div class="titulo-factura">

        <div>

            <h2>
                FACTURA
            </h2>

            <div style="color:#666; margin-top:5px;">
                Detalle de factura de compra
            </div>

        </div>


        <div class="folio">

            Folio:
            <?= htmlspecialchars($factura["numero_factura"]) ?>

        </div>

    </div>



    <!-- =====================================================
         INFORMACIÓN DE LA FACTURA
    ====================================================== -->

    <div class="info-grid">


        <div class="info-bloque">

            <h3>
                📅 Datos de la factura
            </h3>

            <div class="info-linea">

                <strong>Fecha:</strong>

                <?= htmlspecialchars(
                    $factura["fecha_factura"] ?? ""
                ) ?>

            </div>


            <div class="info-linea">

                <strong>ID interno:</strong>

                <?= intval($factura["id"]) ?>

            </div>


            <div class="info-linea">

                <strong>Moneda:</strong>

                <?= htmlspecialchars($moneda) ?>

            </div>


            <div class="info-linea">

                <strong>Registrada:</strong>

                <?= htmlspecialchars(
                    $factura["fecha_registro"] ?? ""
                ) ?>

            </div>

        </div>



        <div class="info-bloque">

            <h3>
                🏢 Proveedor / Emisor
            </h3>

            <div class="info-linea">

                <strong>Nombre:</strong>

                <?= htmlspecialchars(
                    $factura["nombre_emisor"]
                ) ?>

            </div>


            <div class="info-linea">

                <strong>RFC:</strong>

                <?= htmlspecialchars(
                    $factura["rfc_emisor"]
                ) ?>

            </div>

        </div>


    </div>



    <!-- =====================================================
         RECEPTOR
    ====================================================== -->

    <?php if (
        !empty($factura["nombre_receptor"]) ||
        !empty($factura["rfc_receptor"])
    ): ?>

        <div class="info-bloque" style="margin-bottom:25px;">

            <h3>
                📋 Receptor
            </h3>

            <div class="info-linea">

                <strong>Nombre:</strong>

                <?= htmlspecialchars(
                    $factura["nombre_receptor"] ?? ""
                ) ?>

            </div>


            <div class="info-linea">

                <strong>RFC:</strong>

                <?= htmlspecialchars(
                    $factura["rfc_receptor"] ?? ""
                ) ?>

            </div>

        </div>

    <?php endif; ?>



    <!-- =====================================================
         ARTÍCULOS
    ====================================================== -->

    <h3>
        📦 Artículos de la factura
    </h3>


    <?php if (count($detalles) > 0): ?>


        <div class="tabla-contenedor">

            <table>

                <thead>

                    <tr>

                        <th>#</th>

                        <th>Código</th>

                        <th>Descripción</th>

                        <th style="text-align:right;">
                            Cantidad
                        </th>

                        <th style="text-align:right;">
                            Costo unitario
                        </th>

                        <th style="text-align:right;">
                            Importe
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php

                $contador = 1;

                foreach ($detalles as $detalle):

                    /*
                     * Cantidad
                     */
                    $cantidad = floatval(
                        obtenerCampo(
                            $detalle,
                            [
                                "cantidad",
                                "cantidad_producto",
                                "cantidad_ingresada"
                            ],
                            0
                        )
                    );


                    /*
                     * Costo unitario
                     */
                    $costo = floatval(
                        obtenerCampo(
                            $detalle,
                            [
                                "costo_unitario",
                                "precio_unitario",
                                "costo"
                            ],
                            0
                        )
                    );


                    /*
                     * Importe
                     */
                    $importe = obtenerCampo(
                        $detalle,
                        [
                            "importe",
                            "subtotal",
                            "total"
                        ],
                        null
                    );


                    if ($importe === null || $importe === "") {

                        $importe = $cantidad * $costo;

                    } else {

                        $importe = floatval($importe);

                    }

                ?>

                    <tr>

                        <td>

                            <?= $contador ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $detalle["codigo"] ?? ""
                            ) ?>

                        </td>


                        <td class="descripcion">

                            <?= htmlspecialchars(
                                $detalle["articulo_descripcion"] ?? "Artículo"
                            ) ?>

                        </td>


                        <td class="numero">

                            <?= number_format(
                                $cantidad,
                                3
                            ) ?>

                        </td>


                        <td class="numero">

                            <?= $simbolo_moneda ?>

                            <?= number_format(
                                $costo,
                                2
                            ) ?>

                        </td>


                        <td class="numero">

                            <?= $simbolo_moneda ?>

                            <?= number_format(
                                $importe,
                                2
                            ) ?>

                        </td>

                    </tr>


                <?php

                    $contador++;

                endforeach;

                ?>


                </tbody>

            </table>

        </div>


    <?php else: ?>


        <div class="sin-detalles">

            📭 Esta factura no tiene artículos registrados.

        </div>


    <?php endif; ?>



    <!-- =====================================================
         TOTALES
    ====================================================== -->

    <div class="totales">


        <div class="total-linea">

            <span>
                Subtotal
            </span>

            <strong>

                <?= $simbolo_moneda ?>

                <?= number_format(
                    $factura["subtotal"],
                    2
                ) ?>

            </strong>

        </div>


        <div class="total-linea">

            <span>

                IVA

                <?php if ($tasa_iva > 0): ?>

                    (<?= number_format(
                        $tasa_iva,
                        2
                    ) ?>%)

                <?php endif; ?>

            </span>

            <strong>

                <?= $simbolo_moneda ?>

                <?= number_format(
                    $factura["iva"],
                    2
                ) ?>

            </strong>

        </div>


        <div class="total-linea total-final">

            <span>
                TOTAL
            </span>

            <strong>

                <?= $simbolo_moneda ?>

                <?= number_format(
                    $factura["total"],
                    2
                ) ?>

            </strong>

        </div>


    </div>



    <!-- =====================================================
         BOTONES
    ====================================================== -->

    <div class="botones">

        <a
            href="facturas.php"
            class="boton regresar"
        >
            ⬅️ Regresar a facturas
        </a>


        <button
            type="button"
            class="boton imprimir"
            onclick="window.print()"
        >
            🖨️ Imprimir factura
        </button>

    </div>


</div>


<?php require_once __DIR__ . '/footer.php'; ?>