<?php

/**
 * Registra una acción en la auditoría del sistema.
 *
 * @param mysqli $conexion
 * @param string $accion
 * @param string $modulo
 * @param string $descripcion
 */
function registrar_auditoria(
    $conexion,
    $accion,
    $modulo = '',
    $descripcion = ''
) {

    // Verificar que exista sesión
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Datos de sesión
    $usuario_id = isset($_SESSION['usuario_id'])
        ? (int)$_SESSION['usuario_id']
        : null;

    $empleado_id = isset($_SESSION['empleado_id'])
        ? (int)$_SESSION['empleado_id']
        : null;

    $usuario = $_SESSION['nombre_usuario'] ?? '';
    $empleado = $_SESSION['nombre_empleado'] ?? '';
    $rol = $_SESSION['rol'] ?? '';

    // Obtener IP
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';

    // Insertar auditoría
    $sql = "
        INSERT INTO auditoria_sistema
        (
            usuario_id,
            empleado_id,
            usuario,
            empleado,
            rol,
            accion,
            modulo,
            descripcion,
            ip,
            fecha_hora
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    /*
     * Los dos primeros valores pueden ser NULL.
     * Usamos variables auxiliares para que bind_param
     * funcione correctamente.
     */

    $usuario_id_db = $usuario_id;
    $empleado_id_db = $empleado_id;

    $stmt->bind_param(
        "iisssssss",
        $usuario_id_db,
        $empleado_id_db,
        $usuario,
        $empleado,
        $rol,
        $accion,
        $modulo,
        $descripcion,
        $ip
    );

    $resultado = $stmt->execute();

    $stmt->close();

    return $resultado;
}