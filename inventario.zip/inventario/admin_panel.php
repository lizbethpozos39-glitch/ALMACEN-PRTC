<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_admin();

$mensaje = "";
$tipo_mensaje = "success";


/* =========================================================
   PROCESAR ACCIONES
========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $accion = $_POST["accion"] ?? "";


    /* =====================================================
       AGREGAR MÓDULO
    ===================================================== */

    if ($accion === "agregar") {

        $nombre = trim($_POST["nombre"] ?? "");
        $archivo = trim($_POST["archivo"] ?? "");
        $icono = trim($_POST["icono"] ?? "📄");
        $descripcion = trim($_POST["descripcion"] ?? "");

        if ($nombre === "") {

            $mensaje = "El nombre del módulo es obligatorio.";
            $tipo_mensaje = "danger";

        } elseif ($archivo === "") {

            $mensaje = "El nombre del archivo es obligatorio.";
            $tipo_mensaje = "danger";

        } else {

            if (!preg_match('/^[a-zA-Z0-9_\-]+\.php$/', $archivo)) {

                $mensaje =
                    "El archivo debe tener un nombre válido y terminar en .php.";

                $tipo_mensaje = "danger";

            } elseif (!file_exists(__DIR__ . "/" . $archivo)) {

                $mensaje =
                    "El archivo indicado no existe en esta carpeta.";

                $tipo_mensaje = "danger";

            } else {

                $stmt = $conexion->prepare("
                    INSERT INTO menu_admin
                    (
                        nombre,
                        archivo,
                        icono,
                        descripcion,
                        orden
                    )
                    VALUES (?, ?, ?, ?, 0)
                ");

                if (!$stmt) {

                    $mensaje =
                        "Error al preparar el registro: "
                        . $conexion->error;

                    $tipo_mensaje = "danger";

                } else {

                    $stmt->bind_param(
                        "ssss",
                        $nombre,
                        $archivo,
                        $icono,
                        $descripcion
                    );

                    if ($stmt->execute()) {

                        $mensaje =
                            "Módulo agregado correctamente.";

                    } else {

                        if ($conexion->errno == 1062) {

                            $mensaje =
                                "Ese archivo ya está registrado en el menú.";

                        } else {

                            $mensaje =
                                "Error al agregar el módulo: "
                                . $conexion->error;
                        }

                        $tipo_mensaje = "danger";
                    }

                    $stmt->close();
                }
            }
        }
    }


    /* =====================================================
       EDITAR MÓDULO
    ===================================================== */

    elseif ($accion === "editar") {

        $id = intval($_POST["id"] ?? 0);
        $nombre = trim($_POST["nombre"] ?? "");
        $archivo = trim($_POST["archivo"] ?? "");
        $icono = trim($_POST["icono"] ?? "📄");
        $descripcion = trim($_POST["descripcion"] ?? "");

        if (
            $id <= 0 ||
            $nombre === "" ||
            $archivo === ""
        ) {

            $mensaje =
                "Los datos del módulo son obligatorios.";

            $tipo_mensaje = "danger";

        } elseif (
            !preg_match(
                '/^[a-zA-Z0-9_\-]+\.php$/',
                $archivo
            )
        ) {

            $mensaje =
                "El archivo no tiene un formato válido.";

            $tipo_mensaje = "danger";

        } elseif (
            !file_exists(__DIR__ . "/" . $archivo)
        ) {

            $mensaje =
                "El archivo indicado no existe.";

            $tipo_mensaje = "danger";

        } else {

            $stmt = $conexion->prepare("
                UPDATE menu_admin
                SET
                    nombre = ?,
                    archivo = ?,
                    icono = ?,
                    descripcion = ?
                WHERE id = ?
            ");

            if (!$stmt) {

                $mensaje =
                    "Error al preparar la actualización: "
                    . $conexion->error;

                $tipo_mensaje = "danger";

            } else {

                $stmt->bind_param(
                    "ssssi",
                    $nombre,
                    $archivo,
                    $icono,
                    $descripcion,
                    $id
                );

                if ($stmt->execute()) {

                    $mensaje =
                        "Módulo actualizado correctamente.";

                } else {

                    $mensaje =
                        "No fue posible actualizar el módulo: "
                        . $conexion->error;

                    $tipo_mensaje = "danger";
                }

                $stmt->close();
            }
        }
    }


    /* =====================================================
       ACTIVAR / DESACTIVAR
    ===================================================== */

    elseif ($accion === "toggle") {

        $id = intval($_POST["id"] ?? 0);

        if ($id > 0) {

            $stmt = $conexion->prepare("
                UPDATE menu_admin
                SET activo = IF(activo = 1, 0, 1)
                WHERE id = ?
            ");

            if (!$stmt) {

                $mensaje =
                    "No fue posible preparar la actualización.";

                $tipo_mensaje = "danger";

            } else {

                $stmt->bind_param("i", $id);

                if ($stmt->execute()) {

                    $mensaje =
                        "Estado del módulo actualizado.";

                } else {

                    $mensaje =
                        "No fue posible actualizar el módulo.";

                    $tipo_mensaje = "danger";
                }

                $stmt->close();
            }
        }
    }


    /* =====================================================
       CAMBIAR ORDEN
    ===================================================== */

    elseif ($accion === "orden") {

        $id = intval($_POST["id"] ?? 0);
        $orden = intval($_POST["orden"] ?? 0);

        if ($id > 0) {

            $stmt = $conexion->prepare("
                UPDATE menu_admin
                SET orden = ?
                WHERE id = ?
            ");

            if (!$stmt) {

                $mensaje =
                    "No fue posible preparar el cambio de orden.";

                $tipo_mensaje = "danger";

            } else {

                $stmt->bind_param(
                    "ii",
                    $orden,
                    $id
                );

                if ($stmt->execute()) {

                    $mensaje =
                        "Orden actualizado.";

                } else {

                    $mensaje =
                        "No fue posible actualizar el orden.";

                    $tipo_mensaje = "danger";
                }

                $stmt->close();
            }
        }
    }
}


/* =========================================================
   OBTENER MÓDULOS
========================================================= */

$modulos = [];

$resultado = $conexion->query("
    SELECT
        id,
        nombre,
        archivo,
        icono,
        descripcion,
        activo,
        orden,
        fecha_registro
    FROM menu_admin
    ORDER BY
        activo DESC,
        orden ASC,
        nombre ASC
");

if ($resultado) {

    while ($fila = $resultado->fetch_assoc()) {

        $modulos[] = $fila;
    }
}


/* =========================================================
   CONTADORES
========================================================= */

$total_modulos = count($modulos);

$modulos_activos = 0;
$modulos_inactivos = 0;

foreach ($modulos as $modulo) {

    if ($modulo["activo"]) {

        $modulos_activos++;

    } else {

        $modulos_inactivos++;
    }
}

?>


<?php include 'menu.php'; ?>


<!-- =========================================================
     CONTENIDO PRINCIPAL
========================================================= -->

<main class="contenido-principal">


<style>

/* =========================================================
   CONFIGURACIÓN GENERAL
========================================================= */

* {

    box-sizing: border-box;

}


html,
body {

    margin: 0;

    padding: 0;

    width: 100%;

    min-height: 100%;

}


body {

    font-family: Arial, sans-serif;

    background: #f4f6f8;

    color: #333;

}


/* =========================================================
   CONTENIDO PRINCIPAL
   RESERVA EL ESPACIO DEL MENÚ LATERAL
========================================================= */

.contenido-principal {

    margin-left: 240px;

    width: calc(100% - 240px);

    min-height: 100vh;

    padding: 30px;

    box-sizing: border-box;

}


/* =========================================================
   CONTENEDOR ADMINISTRATIVO
========================================================= */

.admin-contenedor {

    width: 100%;

    max-width: 1600px;

    margin: 0 auto;

    box-sizing: border-box;

}


/* =========================================================
   ENCABEZADO
========================================================= */

.admin-titulo {

    margin-bottom: 25px;

}


.admin-titulo h1 {

    margin: 0 0 8px 0;

    color: #212529;

}


.admin-titulo p {

    margin: 0;

    color: #6c757d;

}


/* =========================================================
   MENSAJES
========================================================= */

.mensaje {

    padding: 14px 18px;

    border-radius: 6px;

    margin-bottom: 20px;

    font-weight: bold;

}


.mensaje.success {

    background: #d1e7dd;

    color: #0f5132;

    border: 1px solid #badbcc;

}


.mensaje.danger {

    background: #f8d7da;

    color: #842029;

    border: 1px solid #f5c2c7;

}


/* =========================================================
   RESUMEN
========================================================= */

.resumen {

    display: grid;

    grid-template-columns:
        repeat(3, minmax(0, 1fr));

    gap: 15px;

    margin-bottom: 25px;

}


.resumen-card {

    background: white;

    border-radius: 10px;

    padding: 20px;

    box-shadow:
        0 2px 8px rgba(0,0,0,.08);

}


.resumen-card strong {

    display: block;

    font-size: 28px;

    color: #212529;

}


.resumen-card span {

    color: #6c757d;

    font-size: 14px;

}


/* =========================================================
   GRID PRINCIPAL
========================================================= */

.admin-grid {

    display: grid;

    grid-template-columns:
        330px minmax(0, 1fr);

    gap: 25px;

    width: 100%;

}


/* =========================================================
   TARJETAS
========================================================= */

.tarjeta {

    background: white;

    border-radius: 10px;

    padding: 22px;

    box-shadow:
        0 2px 8px rgba(0,0,0,.08);

    min-width: 0;

}


.tarjeta h2 {

    margin-top: 0;

    margin-bottom: 20px;

    color: #212529;

}


/* =========================================================
   FORMULARIO
========================================================= */

.form-grupo {

    margin-bottom: 15px;

}


.form-grupo label {

    display: block;

    font-weight: bold;

    margin-bottom: 6px;

}


.form-grupo input,
.form-grupo textarea {

    width: 100%;

    padding: 10px;

    border: 1px solid #ced4da;

    border-radius: 5px;

    font-size: 14px;

    box-sizing: border-box;

    font-family: Arial, sans-serif;

}


.form-grupo input:focus,
.form-grupo textarea:focus {

    outline: none;

    border-color: #0d6efd;

    box-shadow:
        0 0 0 2px rgba(13,110,253,.10);

}


.form-grupo textarea {

    resize: vertical;

    min-height: 70px;

}


.form-grupo small {

    display: block;

    margin-top: 5px;

    color: #6c757d;

}


/* =========================================================
   BOTONES
========================================================= */

.boton {

    display: inline-block;

    border: none;

    border-radius: 5px;

    padding: 9px 13px;

    cursor: pointer;

    text-decoration: none;

    font-size: 13px;

    font-family: Arial, sans-serif;

}


.boton-principal {

    background: #212529;

    color: white;

}


.boton-principal:hover {

    background: #343a40;

}


.boton-ver {

    background: #198754;

    color: white;

}


.boton-ver:hover {

    background: #157347;

}


.boton-editar {

    background: #0d6efd;

    color: white;

}


.boton-editar:hover {

    background: #0b5ed7;

}


.boton-desactivar {

    background: #dc3545;

    color: white;

}


.boton-desactivar:hover {

    background: #bb2d3b;

}


.boton-activar {

    background: #198754;

    color: white;

}


.boton-activar:hover {

    background: #157347;

}


/* =========================================================
   BOTONES DE MÓDULOS
========================================================= */

.botones-modulos {

    display: grid;

    grid-template-columns:
        repeat(3, minmax(0, 1fr));

    gap: 15px;

    width: 100%;

}


.modulo-boton {

    display: flex;

    flex-direction: column;

    justify-content: center;

    min-height: 125px;

    padding: 20px;

    background: #212529;

    color: white;

    text-decoration: none;

    border-radius: 10px;

    transition: .2s;

    box-sizing: border-box;

    min-width: 0;

}


.modulo-boton:hover {

    background: #343a40;

    transform: translateY(-2px);

}


.modulo-icono {

    font-size: 30px;

    margin-bottom: 10px;

}


.modulo-nombre {

    font-weight: bold;

    font-size: 16px;

    word-break: break-word;

}


.modulo-descripcion {

    font-size: 12px;

    margin-top: 5px;

    color: #d5d5d5;

    line-height: 1.4;

    word-break: break-word;

}


/* =========================================================
   TABLA
========================================================= */

.tabla-contenedor {

    width: 100%;

    overflow-x: auto;

}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 850px;

}


th {

    background: #212529;

    color: white;

    padding: 11px;

    text-align: left;

    font-size: 13px;

}


td {

    padding: 10px;

    border-bottom: 1px solid #ddd;

    font-size: 13px;

}


tr:hover {

    background: #f8f9fa;

}


code {

    background: #f1f3f5;

    padding: 3px 5px;

    border-radius: 4px;

}


/* =========================================================
   ESTADO
========================================================= */

.estado {

    display: inline-block;

    padding: 4px 9px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: bold;

}


.estado-activo {

    background: #d1e7dd;

    color: #0f5132;

}


.estado-inactivo {

    background: #f8d7da;

    color: #842029;

}


/* =========================================================
   MODAL
========================================================= */

.modal {

    display: none;

    position: fixed;

    z-index: 9999;

    left: 0;

    top: 0;

    width: 100%;

    height: 100%;

    background: rgba(0,0,0,.55);

    padding: 20px;

    overflow-y: auto;

    box-sizing: border-box;

}


.modal-contenido {

    background: white;

    width: 100%;

    max-width: 600px;

    margin: 40px auto;

    padding: 25px;

    border-radius: 10px;

    box-sizing: border-box;

}


.modal-contenido h2 {

    margin-top: 0;

}


.modal-botones {

    display: flex;

    justify-content: flex-end;

    gap: 10px;

    margin-top: 20px;

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 1200px) {

    .admin-grid {

        grid-template-columns:
            300px minmax(0, 1fr);

    }


    .botones-modulos {

        grid-template-columns:
            repeat(2, minmax(0, 1fr));

    }

}


/* =========================================================
   TABLET
========================================================= */

@media (max-width: 900px) {

    .contenido-principal {

        margin-left: 240px;

        width: calc(100% - 240px);

        padding: 20px;

    }


    .admin-grid {

        grid-template-columns: 1fr;

    }


    .botones-modulos {

        grid-template-columns:
            repeat(2, minmax(0, 1fr));

    }

}


/* =========================================================
   MÓVIL
========================================================= */

@media (max-width: 650px) {

    .contenido-principal {

        margin-left: 0;

        width: 100%;

        padding: 15px;

    }


    .resumen {

        grid-template-columns: 1fr;

    }


    .admin-grid {

        grid-template-columns: 1fr;

    }


    .botones-modulos {

        grid-template-columns: 1fr;

    }


    .tarjeta {

        padding: 18px;

    }


    .admin-titulo h1 {

        font-size: 24px;

    }

}

</style>


<!-- =========================================================
     CONTENEDOR
========================================================= -->

<div class="admin-contenedor">


    <!-- =====================================================
         TITULO
    ====================================================== -->

    <div class="admin-titulo">

        <h1>
            ⚙️ Panel de Administración
        </h1>

        <p>
            Acceso centralizado a los módulos del sistema.
        </p>

    </div>


    <!-- =====================================================
         MENSAJE
    ====================================================== -->

    <?php if ($mensaje !== ""): ?>

        <div class="mensaje <?= htmlspecialchars($tipo_mensaje) ?>">

            <?= htmlspecialchars($mensaje) ?>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         RESUMEN
    ====================================================== -->

    <div class="resumen">


        <div class="resumen-card">

            <strong>

                <?= $total_modulos ?>

            </strong>

            <span>

                Módulos registrados

            </span>

        </div>


        <div class="resumen-card">

            <strong>

                <?= $modulos_activos ?>

            </strong>

            <span>

                Módulos activos

            </span>

        </div>


        <div class="resumen-card">

            <strong>

                <?= $modulos_inactivos ?>

            </strong>

            <span>

                Módulos inactivos

            </span>

        </div>


    </div>


    <!-- =====================================================
         GRID PRINCIPAL
    ====================================================== -->

    <div class="admin-grid">


        <!-- =================================================
             AGREGAR MÓDULO
        ================================================== -->

        <div class="tarjeta">

            <h2>
                ➕ Agregar módulo
            </h2>


            <form method="POST">

                <input
                    type="hidden"
                    name="accion"
                    value="agregar"
                >


                <div class="form-grupo">

                    <label>
                        Nombre del botón
                    </label>

                    <input
                        type="text"
                        name="nombre"
                        placeholder="Ej. Reportes"
                        required
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        Archivo PHP
                    </label>

                    <input
                        type="text"
                        name="archivo"
                        placeholder="Ej. reportes.php"
                        required
                    >

                    <small>
                        El archivo debe existir en esta misma carpeta.
                    </small>

                </div>


                <div class="form-grupo">

                    <label>
                        Icono
                    </label>

                    <input
                        type="text"
                        name="icono"
                        value="📄"
                        maxlength="10"
                    >

                </div>


                <div class="form-grupo">

                    <label>
                        Descripción
                    </label>

                    <textarea
                        name="descripcion"
                        placeholder="Descripción del módulo"
                    ></textarea>

                </div>


                <button
                    type="submit"
                    class="boton boton-principal"
                >

                    ➕ Agregar al panel

                </button>

            </form>

        </div>


        <!-- =================================================
             ACCESOS
        ================================================== -->

        <div class="tarjeta">

            <h2>
                🧭 Módulos del sistema
            </h2>


            <div class="botones-modulos">


                <?php foreach ($modulos as $modulo): ?>


                    <?php if ($modulo["activo"]): ?>

                        <a
                            href="<?= htmlspecialchars(
                                $modulo["archivo"]
                            ) ?>"
                            class="modulo-boton"
                        >


                            <div class="modulo-icono">

                                <?= htmlspecialchars(
                                    $modulo["icono"]
                                ) ?>

                            </div>


                            <div class="modulo-nombre">

                                <?= htmlspecialchars(
                                    $modulo["nombre"]
                                ) ?>

                            </div>


                            <?php if (
                                !empty(
                                    $modulo["descripcion"]
                                )
                            ): ?>

                                <div class="modulo-descripcion">

                                    <?= htmlspecialchars(
                                        $modulo["descripcion"]
                                    ) ?>

                                </div>

                            <?php endif; ?>


                        </a>

                    <?php endif; ?>


                <?php endforeach; ?>


            </div>

        </div>


    </div>


    <!-- =====================================================
         ADMINISTRAR MÓDULOS
    ====================================================== -->

    <div
        class="tarjeta"
        style="margin-top:25px;"
    >

        <h2>
            🛠️ Administrar botones
        </h2>


        <div class="tabla-contenedor">


            <table>


                <thead>

                    <tr>

                        <th>
                            Orden
                        </th>

                        <th>
                            Icono
                        </th>

                        <th>
                            Nombre
                        </th>

                        <th>
                            Archivo
                        </th>

                        <th>
                            Descripción
                        </th>

                        <th>
                            Estado
                        </th>

                        <th>
                            Acciones
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php foreach ($modulos as $modulo): ?>


                    <tr>


                        <!-- ORDEN -->

                        <td>

                            <form
                                method="POST"
                                style="
                                    display:flex;
                                    gap:5px;
                                "
                            >

                                <input
                                    type="hidden"
                                    name="accion"
                                    value="orden"
                                >

                                <input
                                    type="hidden"
                                    name="id"
                                    value="<?= intval(
                                        $modulo["id"]
                                    ) ?>"
                                >

                                <input
                                    type="number"
                                    name="orden"
                                    value="<?= intval(
                                        $modulo["orden"]
                                    ) ?>"
                                    style="
                                        width:70px;
                                        padding:5px;
                                    "
                                >

                                <button
                                    type="submit"
                                    class="boton boton-principal"
                                >
                                    💾
                                </button>

                            </form>

                        </td>


                        <!-- ICONO -->

                        <td style="font-size:24px;">

                            <?= htmlspecialchars(
                                $modulo["icono"]
                            ) ?>

                        </td>


                        <!-- NOMBRE -->

                        <td>

                            <strong>

                                <?= htmlspecialchars(
                                    $modulo["nombre"]
                                ) ?>

                            </strong>

                        </td>


                        <!-- ARCHIVO -->

                        <td>

                            <code>

                                <?= htmlspecialchars(
                                    $modulo["archivo"]
                                ) ?>

                            </code>

                        </td>


                        <!-- DESCRIPCIÓN -->

                        <td>

                            <?= htmlspecialchars(
                                $modulo["descripcion"] ?? ""
                            ) ?>

                        </td>


                        <!-- ESTADO -->

                        <td>

                            <?php if ($modulo["activo"]): ?>

                                <span
                                    class="estado estado-activo"
                                >

                                    Activo

                                </span>

                            <?php else: ?>

                                <span
                                    class="estado estado-inactivo"
                                >

                                    Inactivo

                                </span>

                            <?php endif; ?>

                        </td>


                        <!-- ACCIONES -->

                        <td>


                            <div
                                style="
                                    display:flex;
                                    gap:5px;
                                    flex-wrap:wrap;
                                "
                            >


                                <!-- EDITAR -->

                                <button
                                    type="button"
                                    class="boton boton-editar"
                                    onclick='editarModulo(
                                        <?= json_encode(
                                            $modulo["id"]
                                        ) ?>,
                                        <?= json_encode(
                                            $modulo["nombre"]
                                        ) ?>,
                                        <?= json_encode(
                                            $modulo["archivo"]
                                        ) ?>,
                                        <?= json_encode(
                                            $modulo["icono"]
                                        ) ?>,
                                        <?= json_encode(
                                            $modulo["descripcion"]
                                        ) ?>
                                    )'
                                >

                                    ✏️

                                </button>


                                <!-- ACTIVAR / DESACTIVAR -->

                                <form method="POST">

                                    <input
                                        type="hidden"
                                        name="accion"
                                        value="toggle"
                                    >

                                    <input
                                        type="hidden"
                                        name="id"
                                        value="<?= intval(
                                            $modulo["id"]
                                        ) ?>"
                                    >


                                    <?php if (
                                        $modulo["activo"]
                                    ): ?>

                                        <button
                                            type="submit"
                                            class="boton boton-desactivar"
                                            onclick="
                                                return confirm(
                                                    '¿Desactivar este botón?'
                                                );
                                            "
                                        >

                                            🚫

                                        </button>

                                    <?php else: ?>

                                        <button
                                            type="submit"
                                            class="boton boton-activar"
                                        >

                                            ✅

                                        </button>

                                    <?php endif; ?>


                                </form>


                                <!-- ABRIR -->

                                <?php if (
                                    $modulo["activo"]
                                ): ?>

                                    <a
                                        href="<?= htmlspecialchars(
                                            $modulo["archivo"]
                                        ) ?>"
                                        class="boton boton-ver"
                                    >

                                        👁️

                                    </a>

                                <?php endif; ?>


                            </div>


                        </td>


                    </tr>


                <?php endforeach; ?>


                </tbody>

            </table>


        </div>

    </div>


</div>


</main>


<!-- =========================================================
     MODAL EDITAR
========================================================= -->

<div
    id="modalEditar"
    class="modal"
>


    <div class="modal-contenido">


        <h2>
            ✏️ Editar módulo
        </h2>


        <form method="POST">


            <input
                type="hidden"
                name="accion"
                value="editar"
            >


            <input
                type="hidden"
                name="id"
                id="editar_id"
            >


            <div class="form-grupo">

                <label>
                    Nombre del botón
                </label>

                <input
                    type="text"
                    name="nombre"
                    id="editar_nombre"
                    required
                >

            </div>


            <div class="form-grupo">

                <label>
                    Archivo PHP
                </label>

                <input
                    type="text"
                    name="archivo"
                    id="editar_archivo"
                    required
                >

            </div>


            <div class="form-grupo">

                <label>
                    Icono
                </label>

                <input
                    type="text"
                    name="icono"
                    id="editar_icono"
                    maxlength="10"
                >

            </div>


            <div class="form-grupo">

                <label>
                    Descripción
                </label>

                <textarea
                    name="descripcion"
                    id="editar_descripcion"
                ></textarea>

            </div>


            <div class="modal-botones">


                <button
                    type="button"
                    class="boton boton-desactivar"
                    onclick="cerrarModal()"
                >

                    Cancelar

                </button>


                <button
                    type="submit"
                    class="boton boton-principal"
                >

                    💾 Guardar cambios

                </button>


            </div>


        </form>


    </div>


</div>


<!-- =========================================================
     JAVASCRIPT
========================================================= -->

<script>


function editarModulo(
    id,
    nombre,
    archivo,
    icono,
    descripcion
) {


    document.getElementById(
        "editar_id"
    ).value = id;


    document.getElementById(
        "editar_nombre"
    ).value = nombre;


    document.getElementById(
        "editar_archivo"
    ).value = archivo;


    document.getElementById(
        "editar_icono"
    ).value = icono;


    document.getElementById(
        "editar_descripcion"
    ).value = descripcion || "";


    document.getElementById(
        "modalEditar"
    ).style.display = "block";

}


function cerrarModal() {


    document.getElementById(
        "modalEditar"
    ).style.display = "none";

}


window.onclick = function(event) {


    const modal =
        document.getElementById(
            "modalEditar"
        );


    if (event.target === modal) {

        cerrarModal();

    }

};


</script>


<?php include 'footer.php'; ?>