<?php

require "conexion.php";

$mensaje = "";
$error = "";


// =====================================================
// PROCESAR SALIDA
// =====================================================

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $productos = $_POST["producto"] ?? [];

    if (empty($productos)) {

        $error = "No se agregaron productos a la salida.";

    } else {

        // =============================================
        // INICIAR TRANSACCIÓN
        // =============================================

        $conexion->begin_transaction();

        try {

            foreach ($productos as $producto) {

                // =========================================
                // DATOS
                // =========================================

                $inventario_id = intval(
                    $producto["inventario_id"] ?? 0
                );

                $cantidad_salida = floatval(
                    $producto["cantidad"] ?? 0
                );

                $observaciones = trim(
                    $producto["observaciones"] ?? ""
                );


                // =========================================
                // VALIDACIONES
                // =========================================

                if ($inventario_id <= 0) {

                    throw new Exception(
                        "Artículo inválido."
                    );

                }


                if ($cantidad_salida <= 0) {

                    throw new Exception(
                        "La cantidad de salida debe ser mayor que cero."
                    );

                }


                // =========================================
                // BUSCAR ARTÍCULO
                // =========================================

                $sql = "
                    SELECT
                        id,
                        codigo,
                        articulo_descripcion,
                        cantidad,
                        ubicacion
                    FROM inventario
                    WHERE id = ?
                    FOR UPDATE
                ";

                $stmt = $conexion->prepare($sql);

                if (!$stmt) {

                    throw new Exception(
                        "Error preparando consulta de inventario: "
                        . $conexion->error
                    );

                }


                $stmt->bind_param(
                    "i",
                    $inventario_id
                );


                if (!$stmt->execute()) {

                    $errorSql = $stmt->error;

                    $stmt->close();

                    throw new Exception(
                        "Error consultando inventario: "
                        . $errorSql
                    );

                }


                $resultado = $stmt->get_result();

                $articulo = $resultado->fetch_assoc();

                $stmt->close();


                // =========================================
                // VERIFICAR ARTÍCULO
                // =========================================

                if (!$articulo) {

                    throw new Exception(
                        "El artículo seleccionado no existe en el inventario."
                    );

                }


                // =========================================
                // EXISTENCIA ANTERIOR
                // =========================================

                $cantidad_anterior = floatval(
                    $articulo["cantidad"]
                );


                // =========================================
                // COMPROBAR EXISTENCIA
                // =========================================

                if ($cantidad_salida > $cantidad_anterior) {

                    throw new Exception(
                        "No hay suficiente existencia para "
                        . $articulo["codigo"]
                        . ". Disponible: "
                        . number_format(
                            $cantidad_anterior,
                            3
                        )
                    );

                }


                // =========================================
                // CALCULAR NUEVA EXISTENCIA
                // =========================================

                $cantidad_nueva =
                    $cantidad_anterior
                    - $cantidad_salida;


                $cantidad_nueva =
                    round(
                        $cantidad_nueva,
                        3
                    );


                // =========================================
                // ACTUALIZAR INVENTARIO
                // =========================================

                $sqlUpdate = "
                    UPDATE inventario
                    SET cantidad = ?
                    WHERE id = ?
                ";

                $stmtUpdate =
                    $conexion->prepare(
                        $sqlUpdate
                    );


                if (!$stmtUpdate) {

                    throw new Exception(
                        "Error preparando actualización del inventario: "
                        . $conexion->error
                    );

                }


                $stmtUpdate->bind_param(
                    "di",
                    $cantidad_nueva,
                    $inventario_id
                );


                if (!$stmtUpdate->execute()) {

                    $errorSql =
                        $stmtUpdate->error;

                    $stmtUpdate->close();

                    throw new Exception(
                        "Error actualizando inventario: "
                        . $errorSql
                    );

                }


                $stmtUpdate->close();


                // =========================================
                // REGISTRAR MOVIMIENTO
                // =========================================

                $tipo = "SALIDA";

                // Salida manual no tiene factura
                $factura_id = null;


                $sqlMovimiento = "
                    INSERT INTO movimientos_inventario
                    (
                        inventario_id,
                        tipo,
                        cantidad,
                        cantidad_anterior,
                        cantidad_nueva,
                        factura_id,
                        observaciones
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ";


                $stmtMovimiento =
                    $conexion->prepare(
                        $sqlMovimiento
                    );


                if (!$stmtMovimiento) {

                    throw new Exception(
                        "Error preparando registro del movimiento: "
                        . $conexion->error
                    );

                }


                /*
                 * i = inventario_id
                 * s = tipo
                 * d = cantidad
                 * d = cantidad_anterior
                 * d = cantidad_nueva
                 * i = factura_id
                 * s = observaciones
                 */

                $stmtMovimiento->bind_param(
                    "isdddis",
                    $inventario_id,
                    $tipo,
                    $cantidad_salida,
                    $cantidad_anterior,
                    $cantidad_nueva,
                    $factura_id,
                    $observaciones
                );


                // =========================================
                // EJECUTAR INSERT
                // =========================================

                if (!$stmtMovimiento->execute()) {

                    $errorSql =
                        $stmtMovimiento->error;

                    $stmtMovimiento->close();

                    throw new Exception(
                        "Error registrando el movimiento: "
                        . $errorSql
                    );

                }


                // =========================================
                // CERRAR STATEMENT
                // =========================================

                $stmtMovimiento->close();

            }


            // =============================================
            // CONFIRMAR TRANSACCIÓN
            // =============================================

            $conexion->commit();


            $mensaje =
                "✅ Salida registrada correctamente.";


        } catch (Throwable $e) {

            // =============================================
            // DESHACER CAMBIOS
            // =============================================

            $conexion->rollback();


            $error =
                "❌ No se pudo registrar la salida: "
                . $e->getMessage();

        }

    }

}


// =====================================================
// OBTENER INVENTARIO
// =====================================================

$sqlInventario = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        ubicacion
    FROM inventario
    ORDER BY codigo
";


$resultadoInventario =
    $conexion->query(
        $sqlInventario
    );


if (!$resultadoInventario) {

    die(
        "Error obteniendo inventario: "
        . $conexion->error
    );

}

?>


<?php require "header.php"; ?>


<style>

/* =====================================================
   CONTENEDOR
===================================================== */

.contenedor-salida {

    background: white;

    padding: 20px;

    border-radius: 10px;

    box-shadow:
        0 2px 10px rgba(0,0,0,.10);

}


/* =====================================================
   TITULO
===================================================== */

.titulo {

    border-bottom: 3px solid #dc3545;

    padding-bottom: 8px;

    margin-bottom: 15px;

}


/* =====================================================
   ACCESO HISTORIAL
===================================================== */

.acceso-historial {

    margin-bottom: 20px;

}


/* =====================================================
   ALERTAS
===================================================== */

.alerta {

    padding: 12px;

    margin-bottom: 15px;

    border-radius: 6px;

}


.exito {

    background: #d1e7dd;

    color: #0f5132;

}


.error {

    background: #f8d7da;

    color: #842029;

}


/* =====================================================
   TABLA
===================================================== */

.tabla-salida {

    width: 100%;

    border-collapse: collapse;

}


.tabla-salida th {

    background: #212529;

    color: white;

    padding: 10px;

    text-align: left;

}


.tabla-salida td {

    padding: 8px;

    border-bottom: 1px solid #ddd;

    vertical-align: middle;

}


/* =====================================================
   CAMPOS
===================================================== */

.tabla-salida select,
.tabla-salida input {

    width: 100%;

    box-sizing: border-box;

    padding: 9px;

    border: 1px solid #ccc;

    border-radius: 5px;

}


/* =====================================================
   EXISTENCIA
===================================================== */

.existencia {

    font-weight: bold;

    color: #198754;

    white-space: nowrap;

}


.existencia.sin-stock {

    color: #dc3545;

}


/* =====================================================
   BOTONES
===================================================== */

.btn {

    border: none;

    padding: 10px 16px;

    border-radius: 5px;

    cursor: pointer;

    text-decoration: none;

    display: inline-block;

    font-size: 15px;

}


/* AGREGAR */

.btn-agregar {

    background: #198754;

    color: white;

}


.btn-agregar:hover {

    background: #157347;

}


/* SALIDA */

.btn-salida {

    background: #dc3545;

    color: white;

    font-size: 16px;

}


.btn-salida:hover {

    background: #bb2d3b;

}


/* ELIMINAR */

.btn-eliminar {

    background: #dc3545;

    color: white;

}


.btn-eliminar:hover {

    background: #bb2d3b;

}


/* HISTORIAL */

.btn-historial {

    background: #0d6efd;

    color: white;

}


.btn-historial:hover {

    background: #0b5ed7;

    color: white;

}


/* =====================================================
   ACCIONES
===================================================== */

.acciones {

    display: flex;

    gap: 10px;

    margin-top: 20px;

    flex-wrap: wrap;

}


/* =====================================================
   RESPONSIVE
===================================================== */

@media(max-width:900px) {

    .contenedor-salida {

        overflow-x: auto;

    }

    .tabla-salida {

        min-width: 1000px;

    }

}

</style>


<div class="contenedor-salida">


    <!-- =================================================
         TITULO
    ================================================== -->

    <h1 class="titulo">

        📤 Salida de material

    </h1>


    <!-- =================================================
         ACCESO AL HISTORIAL
    ================================================== -->

    <div class="acceso-historial">

        <a
            href="historial_movimientos.php"
            class="btn btn-historial">

            📋 Historial de movimientos

        </a>

    </div>


    <!-- =================================================
         DESCRIPCIÓN
    ================================================== -->

    <p>

        Selecciona el material que sale del almacén.
        El sistema actualizará automáticamente la existencia
        y registrará el movimiento en el historial.

    </p>


    <!-- =================================================
         MENSAJE ÉXITO
    ================================================== -->

    <?php if ($mensaje): ?>

        <div class="alerta exito">

            <?= htmlspecialchars(
                $mensaje,
                ENT_QUOTES,
                "UTF-8"
            ) ?>

        </div>

    <?php endif; ?>


    <!-- =================================================
         MENSAJE ERROR
    ================================================== -->

    <?php if ($error): ?>

        <div class="alerta error">

            <?= htmlspecialchars(
                $error,
                ENT_QUOTES,
                "UTF-8"
            ) ?>

        </div>

    <?php endif; ?>


    <!-- =================================================
         FORMULARIO
    ================================================== -->

    <form
        method="POST"
        id="formSalida">


        <table class="tabla-salida">


            <thead>

                <tr>

                    <th>
                        Artículo
                    </th>

                    <th>
                        Existencia
                    </th>

                    <th>
                        Cantidad salida
                    </th>

                    <th>
                        Ubicación
                    </th>

                    <th>
                        Observaciones
                    </th>

                    <th>
                        Acción
                    </th>

                </tr>

            </thead>


            <tbody id="productos">


                <tr class="fila-producto">


                    <!-- ARTÍCULO -->

                    <td>

                        <select
                            name="producto[0][inventario_id]"
                            class="articulo"
                            required>

                            <option value="">

                                -- Seleccionar artículo --

                            </option>


                            <?php while (
                                $item =
                                $resultadoInventario->fetch_assoc()
                            ): ?>

                                <option
                                    value="<?= (int)$item["id"] ?>"
                                    data-cantidad="<?= htmlspecialchars(
                                        $item["cantidad"],
                                        ENT_QUOTES,
                                        "UTF-8"
                                    ) ?>"
                                    data-ubicacion="<?= htmlspecialchars(
                                        $item["ubicacion"] ?? "",
                                        ENT_QUOTES,
                                        "UTF-8"
                                    ) ?>">

                                    <?= htmlspecialchars(
                                        $item["codigo"],
                                        ENT_QUOTES,
                                        "UTF-8"
                                    ) ?>

                                    -

                                    <?= htmlspecialchars(
                                        $item["articulo_descripcion"],
                                        ENT_QUOTES,
                                        "UTF-8"
                                    ) ?>

                                </option>

                            <?php endwhile; ?>

                        </select>

                    </td>


                    <!-- EXISTENCIA -->

                    <td>

                        <span class="existencia">

                            0.000

                        </span>

                    </td>


                    <!-- CANTIDAD -->

                    <td>

                        <input
                            type="number"
                            name="producto[0][cantidad]"
                            class="cantidad-salida"
                            min="0.001"
                            step="0.001"
                            placeholder="0.000"
                            required>

                    </td>


                    <!-- UBICACIÓN -->

                    <td>

                        <input
                            type="text"
                            class="ubicacion"
                            readonly>

                    </td>


                    <!-- OBSERVACIONES -->

                    <td>

                        <input
                            type="text"
                            name="producto[0][observaciones]"
                            placeholder="Motivo de salida">

                    </td>


                    <!-- ELIMINAR -->

                    <td>

                        <button
                            type="button"
                            class="btn btn-eliminar"
                            onclick="eliminarFila(this)">

                            🗑️

                        </button>

                    </td>


                </tr>


            </tbody>

        </table>


        <!-- =================================================
             BOTONES
        ================================================== -->

        <div class="acciones">


            <button
                type="button"
                class="btn btn-agregar"
                onclick="agregarProducto()">

                ➕ Agregar otro producto

            </button>


            <button
                type="submit"
                class="btn btn-salida">

                📤 Registrar salida

            </button>


            <a
                href="historial_movimientos.php"
                class="btn btn-historial">

                📋 Ver historial

            </a>


        </div>


    </form>


</div>


<script>


// =====================================================
// CONTADOR
// =====================================================

let contador = 1;


// =====================================================
// AGREGAR PRODUCTO
// =====================================================

function agregarProducto() {

    const tabla =
        document.getElementById(
            "productos"
        );


    const primeraFila =
        document.querySelector(
            ".fila-producto"
        );


    if (!primeraFila) {

        return;

    }


    const nuevaFila =
        primeraFila.cloneNode(true);


    // =========================================
    // CAMBIAR NOMBRES
    // =========================================

    nuevaFila
        .querySelector(".articulo")
        .name =
        `producto[${contador}][inventario_id]`;


    nuevaFila
        .querySelector(".cantidad-salida")
        .name =
        `producto[${contador}][cantidad]`;


    nuevaFila
        .querySelector(
            'input[name*="[observaciones]"]'
        )
        .name =
        `producto[${contador}][observaciones]`;


    // =========================================
    // LIMPIAR
    // =========================================

    nuevaFila
        .querySelector(".articulo")
        .selectedIndex = 0;


    nuevaFila
        .querySelector(".existencia")
        .textContent =
        "0.000";


    nuevaFila
        .querySelector(".existencia")
        .classList.remove(
            "sin-stock"
        );


    nuevaFila
        .querySelector(".cantidad-salida")
        .value = "";


    nuevaFila
        .querySelector(".ubicacion")
        .value = "";


    nuevaFila
        .querySelector(
            'input[name*="[observaciones]"]'
        )
        .value = "";


    // =========================================
    // AGREGAR
    // =========================================

    tabla.appendChild(
        nuevaFila
    );


    contador++;

}


// =====================================================
// ELIMINAR FILA
// =====================================================

function eliminarFila(boton) {

    const filas =
        document.querySelectorAll(
            ".fila-producto"
        );


    if (filas.length <= 1) {

        alert(
            "Debe existir al menos un producto."
        );

        return;

    }


    boton
        .closest(".fila-producto")
        .remove();

}


// =====================================================
// CAMBIAR ARTÍCULO
// =====================================================

document.addEventListener(
    "change",
    function(event) {

        if (
            !event.target.classList.contains(
                "articulo"
            )
        ) {

            return;

        }


        const select =
            event.target;


        const fila =
            select.closest(
                ".fila-producto"
            );


        const opcion =
            select.options[
                select.selectedIndex
            ];


        const campoExistencia =
            fila.querySelector(
                ".existencia"
            );


        const campoUbicacion =
            fila.querySelector(
                ".ubicacion"
            );


        // =========================================
        // SIN ARTÍCULO
        // =========================================

        if (
            !opcion ||
            !opcion.value
        ) {

            campoExistencia.textContent =
                "0.000";


            campoExistencia.classList.remove(
                "sin-stock"
            );


            campoUbicacion.value = "";


            return;

        }


        // =========================================
        // EXISTENCIA
        // =========================================

        const existencia =
            parseFloat(
                opcion.dataset.cantidad
            ) || 0;


        // =========================================
        // UBICACIÓN
        // =========================================

        const ubicacion =
            opcion.dataset.ubicacion || "";


        campoExistencia.textContent =
            existencia.toFixed(3);


        campoUbicacion.value =
            ubicacion;


        // =========================================
        // COLOR
        // =========================================

        if (existencia <= 0) {

            campoExistencia.classList.add(
                "sin-stock"
            );

        } else {

            campoExistencia.classList.remove(
                "sin-stock"
            );

        }

    }
);


// =====================================================
// VALIDAR CANTIDAD
// =====================================================

document.addEventListener(
    "input",
    function(event) {

        if (
            !event.target.classList.contains(
                "cantidad-salida"
            )
        ) {

            return;

        }


        const campo =
            event.target;


        const fila =
            campo.closest(
                ".fila-producto"
            );


        const select =
            fila.querySelector(
                ".articulo"
            );


        const opcion =
            select.options[
                select.selectedIndex
            ];


        if (
            !opcion ||
            !opcion.value
        ) {

            campo.setCustomValidity("");

            return;

        }


        const existencia =
            parseFloat(
                opcion.dataset.cantidad
            ) || 0;


        const cantidad =
            parseFloat(
                campo.value
            ) || 0;


        if (
            cantidad > existencia
        ) {

            campo.setCustomValidity(
                "La cantidad de salida supera la existencia disponible."
            );


            campo.style.borderColor =
                "#dc3545";

        } else {

            campo.setCustomValidity("");

            campo.style.borderColor =
                "#ccc";

        }

    }
);


// =====================================================
// CONFIRMAR SALIDA
// =====================================================

document.getElementById(
    "formSalida"
).addEventListener(
    "submit",
    function(event) {

        const confirmar =
            confirm(
                "¿Deseas registrar esta salida de material?"
            );


        if (!confirmar) {

            event.preventDefault();

        }

    }
);


</script>


<?php require "footer.php"; ?>
