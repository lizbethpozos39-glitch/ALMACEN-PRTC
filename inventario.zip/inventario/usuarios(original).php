<?php

// ==========================================
// CONEXIÓN Y SEGURIDAD
// ==========================================

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_admin();


// ==========================================
// MENSAJES
// ==========================================

$mensaje = "";
$error = "";


// ==========================================
// CREAR USUARIO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["crear_usuario"])) {

    $empleado_id = intval($_POST["empleado_id"] ?? 0);
    $usuario = trim($_POST["usuario"] ?? "");
    $password = $_POST["password"] ?? "";
    $rol = $_POST["rol"] ?? "USUARIO";


    // ------------------------------------------
    // VALIDACIONES
    // ------------------------------------------

    if ($empleado_id <= 0) {

        $error = "Debes seleccionar un empleado.";

    } elseif ($usuario === "") {

        $error = "Debes indicar un nombre de usuario.";

    } elseif (strlen($usuario) < 3) {

        $error = "El usuario debe tener al menos 3 caracteres.";

    } elseif ($password === "") {

        $error = "Debes indicar una contraseña.";

    } elseif (strlen($password) < 6) {

        $error = "La contraseña debe tener al menos 6 caracteres.";

    } elseif (!in_array($rol, ["ADMIN", "USUARIO"], true)) {

        $error = "El rol seleccionado no es válido.";

    } else {


        // ------------------------------------------
        // VERIFICAR EMPLEADO
        // ------------------------------------------

        $stmt = $conexion->prepare("
            SELECT id
            FROM empleados
            WHERE id = ?
              AND activo = 1
            LIMIT 1
        ");

        $stmt->bind_param("i", $empleado_id);

        $stmt->execute();

        $resultado_empleado = $stmt->get_result();

        if ($resultado_empleado->num_rows === 0) {

            $error = "El empleado seleccionado no existe o está inactivo.";

        }

        $stmt->close();


        // ------------------------------------------
        // VERIFICAR SI YA TIENE USUARIO
        // ------------------------------------------

        if ($error === "") {

            $stmt = $conexion->prepare("
                SELECT id
                FROM usuarios
                WHERE empleado_id = ?
                LIMIT 1
            ");

            $stmt->bind_param("i", $empleado_id);

            $stmt->execute();

            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {

                $error = "Este empleado ya tiene un usuario.";

            }

            $stmt->close();
        }


        // ------------------------------------------
        // VERIFICAR NOMBRE DE USUARIO
        // ------------------------------------------

        if ($error === "") {

            $stmt = $conexion->prepare("
                SELECT id
                FROM usuarios
                WHERE usuario = ?
                LIMIT 1
            ");

            $stmt->bind_param("s", $usuario);

            $stmt->execute();

            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {

                $error = "El nombre de usuario ya está registrado.";

            }

            $stmt->close();
        }


        // ------------------------------------------
        // CREAR USUARIO
        // ------------------------------------------

        if ($error === "") {

            $password_hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );


            $stmt = $conexion->prepare("
                INSERT INTO usuarios
                (
                    empleado_id,
                    usuario,
                    password_hash,
                    rol,
                    activo
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    1
                )
            ");

            $stmt->bind_param(
                "isss",
                $empleado_id,
                $usuario,
                $password_hash,
                $rol
            );


            if ($stmt->execute()) {

                $mensaje = "Usuario creado correctamente.";

            } else {

                $error = "Error al crear el usuario: " . $stmt->error;

            }

            $stmt->close();
        }
    }
}


// ==========================================
// ACTIVAR / DESACTIVAR USUARIO
// ==========================================

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["cambiar_estado"])
) {

    $usuario_id = intval($_POST["usuario_id"] ?? 0);


    if ($usuario_id > 0) {

        $stmt = $conexion->prepare("
            UPDATE usuarios
            SET activo = IF(activo = 1, 0, 1)
            WHERE id = ?
        ");

        $stmt->bind_param("i", $usuario_id);

        if ($stmt->execute()) {

            $mensaje = "Estado del usuario actualizado correctamente.";

        } else {

            $error = "No fue posible cambiar el estado del usuario.";

        }

        $stmt->close();
    }
}


// ==========================================
// ELIMINAR USUARIO
// ==========================================

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["eliminar_usuario"])
) {

    $usuario_id = intval($_POST["usuario_id"] ?? 0);


    // ------------------------------------------
    // NO PERMITIR ELIMINAR EL USUARIO ACTUAL
    // ------------------------------------------

    if (
        isset($_SESSION["usuario_id"])
        && $usuario_id == $_SESSION["usuario_id"]
    ) {

        $error = "No puedes eliminar el usuario con el que estás conectado.";

    } elseif ($usuario_id > 0) {

        $stmt = $conexion->prepare("
            DELETE FROM usuarios
            WHERE id = ?
        ");

        $stmt->bind_param("i", $usuario_id);

        if ($stmt->execute()) {

            $mensaje = "Usuario eliminado correctamente.";

        } else {

            $error = "No fue posible eliminar el usuario.";

        }

        $stmt->close();
    }
}


// ==========================================
// CAMBIAR CONTRASEÑA
// ==========================================

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["cambiar_password"])
) {

    $usuario_id = intval($_POST["usuario_id"] ?? 0);
    $nueva_password = $_POST["nueva_password"] ?? "";


    if ($usuario_id <= 0) {

        $error = "Usuario no válido.";

    } elseif (strlen($nueva_password) < 6) {

        $error = "La nueva contraseña debe tener al menos 6 caracteres.";

    } else {

        $password_hash = password_hash(
            $nueva_password,
            PASSWORD_DEFAULT
        );


        $stmt = $conexion->prepare("
            UPDATE usuarios
            SET password_hash = ?
            WHERE id = ?
        ");

        $stmt->bind_param(
            "si",
            $password_hash,
            $usuario_id
        );


        if ($stmt->execute()) {

            $mensaje = "Contraseña actualizada correctamente.";

        } else {

            $error = "No fue posible actualizar la contraseña.";

        }

        $stmt->close();
    }
}


// ==========================================
// EMPLEADOS DISPONIBLES
// ==========================================

$empleados = [];

$sql_empleados = "
    SELECT
        e.id,
        e.nombre,
        e.numero_empleado,
        e.puesto,
        a.nombre AS area
    FROM empleados e
    LEFT JOIN areas a
        ON a.id = e.area_id
    LEFT JOIN usuarios u
        ON u.empleado_id = e.id
    WHERE e.activo = 1
      AND u.id IS NULL
    ORDER BY e.nombre ASC
";

$resultado_empleados = $conexion->query($sql_empleados);

if ($resultado_empleados) {

    while ($fila = $resultado_empleados->fetch_assoc()) {

        $empleados[] = $fila;

    }
}


// ==========================================
// USUARIOS REGISTRADOS
// ==========================================

$sql_usuarios = "
    SELECT
        u.id,
        u.usuario,
        u.rol,
        u.activo,
        u.ultimo_acceso,
        u.fecha_registro,

        e.id AS empleado_id,
        e.nombre AS empleado,
        e.numero_empleado,
        e.puesto,

        a.nombre AS area

    FROM usuarios u

    INNER JOIN empleados e
        ON e.id = u.empleado_id

    LEFT JOIN areas a
        ON a.id = e.area_id

    ORDER BY e.nombre ASC
";

$resultado_usuarios = $conexion->query($sql_usuarios);

?>

<!DOCTYPE html>

<html lang="es">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Administración de Usuarios</title>


<style>

* {
    box-sizing: border-box;
}

body {

    margin: 0;

    font-family: Arial, sans-serif;

    background: #f4f6f8;

    color: #333;
}


/* ==========================================
   BARRA SUPERIOR
========================================== */

.barra {

    background: #212529;

    color: white;

    padding: 15px 30px;

    display: flex;

    justify-content: space-between;

    align-items: center;

    flex-wrap: wrap;

    gap: 10px;
}


.barra h1 {

    margin: 0;

    font-size: 20px;
}


.barra-derecha {

    display: flex;

    align-items: center;

    gap: 15px;
}


.usuario {

    font-size: 13px;

    text-align: right;
}


.usuario strong {

    display: block;
}


.usuario small {

    color: #ced4da;
}


.salir {

    background: #dc3545;

    color: white;

    text-decoration: none;

    padding: 8px 12px;

    border-radius: 5px;

    font-size: 13px;
}


.salir:hover {

    background: #bb2d3b;
}


/* ==========================================
   CONTENEDOR
========================================== */

.contenedor {

    width: 95%;

    max-width: 1400px;

    margin: 30px auto;
}


/* ==========================================
   TARJETAS
========================================== */

.tarjeta {

    background: white;

    padding: 25px;

    border-radius: 10px;

    box-shadow: 0 2px 8px rgba(0,0,0,.10);

    margin-bottom: 25px;
}


.tarjeta h2 {

    margin-top: 0;

    margin-bottom: 20px;
}


/* ==========================================
   MENSAJES
========================================== */

.mensaje {

    padding: 12px 15px;

    border-radius: 6px;

    margin-bottom: 20px;

    background: #d1e7dd;

    color: #0f5132;

    border: 1px solid #badbcc;
}


.error {

    padding: 12px 15px;

    border-radius: 6px;

    margin-bottom: 20px;

    background: #f8d7da;

    color: #842029;

    border: 1px solid #f5c2c7;
}


/* ==========================================
   FORMULARIO
========================================== */

.form-grid {

    display: grid;

    grid-template-columns:
        repeat(auto-fit, minmax(220px, 1fr));

    gap: 15px;
}


.campo label {

    display: block;

    font-size: 13px;

    font-weight: bold;

    margin-bottom: 6px;
}


.campo input,
.campo select {

    width: 100%;

    padding: 10px;

    border: 1px solid #ccc;

    border-radius: 5px;

    font-size: 14px;
}


.boton-crear {

    margin-top: 20px;

    padding: 11px 20px;

    border: none;

    border-radius: 5px;

    background: #198754;

    color: white;

    cursor: pointer;

    font-size: 14px;

    font-weight: bold;
}


.boton-crear:hover {

    background: #157347;
}


/* ==========================================
   TABLA
========================================== */

.tabla-contenedor {

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 1000px;
}


th {

    background: #212529;

    color: white;

    padding: 12px;

    text-align: left;

    font-size: 13px;
}


td {

    padding: 11px;

    border-bottom: 1px solid #ddd;

    font-size: 13px;
}


tr:hover {

    background: #f8f9fa;
}


/* ==========================================
   ESTADOS
========================================== */

.estado-activo {

    display: inline-block;

    padding: 5px 9px;

    border-radius: 20px;

    background: #d1e7dd;

    color: #0f5132;

    font-weight: bold;

    font-size: 11px;
}


.estado-inactivo {

    display: inline-block;

    padding: 5px 9px;

    border-radius: 20px;

    background: #f8d7da;

    color: #842029;

    font-weight: bold;

    font-size: 11px;
}


/* ==========================================
   ROLES
========================================== */

.rol-admin {

    font-weight: bold;

    color: #6f42c1;
}


.rol-usuario {

    color: #0d6efd;

    font-weight: bold;
}


/* ==========================================
   BOTONES DE TABLA
========================================== */

.btn {

    border: none;

    padding: 7px 10px;

    border-radius: 5px;

    cursor: pointer;

    font-size: 12px;

    color: white;

    margin: 2px;
}


.btn-estado {

    background: #6c757d;
}


.btn-password {

    background: #0d6efd;
}


.btn-eliminar {

    background: #dc3545;
}


.btn:hover {

    opacity: .85;
}


/* ==========================================
   CONTRASEÑA
========================================== */

.password-box {

    display: none;

    margin-top: 10px;

    padding: 10px;

    background: #f8f9fa;

    border-radius: 5px;
}


.password-box input {

    padding: 7px;

    border: 1px solid #ccc;

    border-radius: 4px;
}


.password-box button {

    padding: 7px 10px;

    border: none;

    background: #198754;

    color: white;

    border-radius: 4px;

    cursor: pointer;
}


/* ==========================================
   FOOTER
========================================== */

.footer {

    width: 100%;

    margin-top: 40px;

    padding: 20px;

    text-align: center;

    color: #6c757d;

    font-size: 13px;

    border-top: 1px solid #ddd;

    background: white;
}

</style>


<script>

function mostrarPassword(id) {

    const elemento =
        document.getElementById("password-" + id);

    if (elemento.style.display === "block") {

        elemento.style.display = "none";

    } else {

        elemento.style.display = "block";

    }
}


function confirmarEliminar(nombre) {

    return confirm(
        "¿Seguro que deseas eliminar el usuario de " +
        nombre +
        "?"
    );
}

</script>

</head>


<body>


<!-- ==========================================
     BARRA
========================================== -->

<header class="barra">


    <h1>
        👥 Administración de Usuarios
    </h1>


    <div class="barra-derecha">


        <div class="usuario">

            <strong>
                👤 <?= htmlspecialchars(
                    $_SESSION['nombre_empleado'] ?? 'Administrador'
                ) ?>
            </strong>

            <small>
                <?= htmlspecialchars(
                    $_SESSION['rol'] ?? 'ADMIN'
                ) ?>
            </small>

        </div>


        <a
            href="logout.php"
            class="salir"
        >
            🚪 Salir
        </a>


    </div>


</header>


<!-- ==========================================
     CONTENEDOR
========================================== -->

<div class="contenedor">


    <?php if ($mensaje !== ""): ?>

        <div class="mensaje">

            ✅ <?= htmlspecialchars($mensaje) ?>

        </div>

    <?php endif; ?>


    <?php if ($error !== ""): ?>

        <div class="error">

            ⚠️ <?= htmlspecialchars($error) ?>

        </div>

    <?php endif; ?>


    <!-- ======================================
         CREAR USUARIO
    ======================================= -->

    <div class="tarjeta">


        <h2>
            ➕ Crear usuario
        </h2>


        <?php if (count($empleados) > 0): ?>


            <form
                method="POST"
            >


                <div class="form-grid">


                    <!-- EMPLEADO -->

                    <div class="campo">

                        <label>
                            Empleado
                        </label>

                        <select
                            name="empleado_id"
                            required
                        >

                            <option value="">
                                Seleccionar empleado
                            </option>


                            <?php foreach ($empleados as $empleado): ?>

                                <option
                                    value="<?= $empleado['id'] ?>"
                                >

                                    <?= htmlspecialchars(
                                        $empleado['nombre']
                                    ) ?>

                                    <?php if (
                                        !empty($empleado['numero_empleado'])
                                    ): ?>

                                        -
                                        <?= htmlspecialchars(
                                            $empleado['numero_empleado']
                                        ) ?>

                                    <?php endif; ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- USUARIO -->

                    <div class="campo">

                        <label>
                            Nombre de usuario
                        </label>

                        <input
                            type="text"
                            name="usuario"
                            required
                            minlength="3"
                            maxlength="100"
                            placeholder="Ej. iram"
                        >

                    </div>


                    <!-- CONTRASEÑA -->

                    <div class="campo">

                        <label>
                            Contraseña
                        </label>

                        <input
                            type="password"
                            name="password"
                            required
                            minlength="6"
                            maxlength="100"
                            placeholder="Mínimo 6 caracteres"
                        >

                    </div>


                    <!-- ROL -->

                    <div class="campo">

                        <label>
                            Rol
                        </label>

                        <select
                            name="rol"
                            required
                        >

                            <option value="USUARIO">
                                USUARIO
                            </option>

                            <option value="ADMIN">
                                ADMIN
                            </option>

                        </select>

                    </div>


                </div>


                <button
                    type="submit"
                    name="crear_usuario"
                    class="boton-crear"
                >

                    ➕ Crear usuario

                </button>


            </form>


        <?php else: ?>


            <div class="mensaje">

                ℹ️ Todos los empleados activos ya tienen
                un usuario registrado.

            </div>


        <?php endif; ?>


    </div>


    <!-- ======================================
         USUARIOS REGISTRADOS
    ======================================= -->

    <div class="tarjeta">


        <h2>
            👥 Usuarios registrados
        </h2>


        <div class="tabla-contenedor">


            <table>


                <thead>

                    <tr>

                        <th>
                            ID
                        </th>

                        <th>
                            Empleado
                        </th>

                        <th>
                            No. empleado
                        </th>

                        <th>
                            Área
                        </th>

                        <th>
                            Puesto
                        </th>

                        <th>
                            Usuario
                        </th>

                        <th>
                            Rol
                        </th>

                        <th>
                            Estado
                        </th>

                        <th>
                            Último acceso
                        </th>

                        <th>
                            Acciones
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php if (
                    $resultado_usuarios
                    && $resultado_usuarios->num_rows > 0
                ): ?>


                    <?php while (
                        $usuario = $resultado_usuarios->fetch_assoc()
                    ): ?>


                        <tr>


                            <td>

                                <?= $usuario["id"] ?>

                            </td>


                            <td>

                                <strong>

                                    <?= htmlspecialchars(
                                        $usuario["empleado"]
                                    ) ?>

                                </strong>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $usuario["numero_empleado"]
                                    ?? ""
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $usuario["area"]
                                    ?? ""
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $usuario["puesto"]
                                    ?? ""
                                ) ?>

                            </td>


                            <td>

                                <strong>

                                    <?= htmlspecialchars(
                                        $usuario["usuario"]
                                    ) ?>

                                </strong>

                            </td>


                            <td>

                                <?php if (
                                    $usuario["rol"] === "ADMIN"
                                ): ?>

                                    <span class="rol-admin">
                                        🛡️ ADMIN
                                    </span>

                                <?php else: ?>

                                    <span class="rol-usuario">
                                        👤 USUARIO
                                    </span>

                                <?php endif; ?>

                            </td>


                            <td>

                                <?php if (
                                    $usuario["activo"] == 1
                                ): ?>

                                    <span class="estado-activo">
                                        ACTIVO
                                    </span>

                                <?php else: ?>

                                    <span class="estado-inactivo">
                                        INACTIVO
                                    </span>

                                <?php endif; ?>

                            </td>


                            <td>

                                <?php if (
                                    !empty($usuario["ultimo_acceso"])
                                ): ?>

                                    <?= htmlspecialchars(
                                        $usuario["ultimo_acceso"]
                                    ) ?>

                                <?php else: ?>

                                    Nunca

                                <?php endif; ?>

                            </td>


                            <td>


                                <!-- ACTIVAR / DESACTIVAR -->

                                <form
                                    method="POST"
                                    style="display:inline;"
                                >

                                    <input
                                        type="hidden"
                                        name="usuario_id"
                                        value="<?= $usuario["id"] ?>"
                                    >

                                    <button
                                        type="submit"
                                        name="cambiar_estado"
                                        class="btn btn-estado"
                                    >

                                        <?= $usuario["activo"] == 1
                                            ? "⛔ Desactivar"
                                            : "✅ Activar"
                                        ?>

                                    </button>

                                </form>


                                <!-- CAMBIAR PASSWORD -->

                                <button
                                    type="button"
                                    class="btn btn-password"
                                    onclick="mostrarPassword(
                                        <?= $usuario["id"] ?>
                                    )"
                                >

                                    🔑 Contraseña

                                </button>


                                <div
                                    id="password-<?= $usuario["id"] ?>"
                                    class="password-box"
                                >

                                    <form
                                        method="POST"
                                    >

                                        <input
                                            type="hidden"
                                            name="usuario_id"
                                            value="<?= $usuario["id"] ?>"
                                        >

                                        <input
                                            type="password"
                                            name="nueva_password"
                                            minlength="6"
                                            maxlength="100"
                                            placeholder="Nueva contraseña"
                                            required
                                        >

                                        <button
                                            type="submit"
                                            name="cambiar_password"
                                        >

                                            Guardar

                                        </button>

                                    </form>

                                </div>


                                <!-- ELIMINAR -->

                                <?php if (
                                    $usuario["id"]
                                    != ($_SESSION["usuario_id"] ?? 0)
                                ): ?>


                                    <form
                                        method="POST"
                                        style="display:inline;"
                                        onsubmit="return confirmarEliminar(
                                            '<?= htmlspecialchars(
                                                $usuario["empleado"],
                                                ENT_QUOTES
                                            ) ?>'
                                        );"
                                    >

                                        <input
                                            type="hidden"
                                            name="usuario_id"
                                            value="<?= $usuario["id"] ?>"
                                        >

                                        <button
                                            type="submit"
                                            name="eliminar_usuario"
                                            class="btn btn-eliminar"
                                        >

                                            🗑️ Eliminar

                                        </button>

                                    </form>


                                <?php endif; ?>


                            </td>


                        </tr>


                    <?php endwhile; ?>


                <?php else: ?>


                    <tr>

                        <td
                            colspan="10"
                            style="text-align:center;padding:30px;"
                        >

                            No hay usuarios registrados.

                        </td>

                    </tr>


                <?php endif; ?>


                </tbody>


            </table>


        </div>


    </div>


</div>


<!-- ==========================================
     FOOTER
========================================== -->

<footer class="footer">

    © <?= date("Y") ?> Sistema de Inventario

    |

    Administración de Usuarios

    |

    <strong>Grupo Protec</strong>

</footer>


</body>

</html>


<?php

$conexion->close();

?>
