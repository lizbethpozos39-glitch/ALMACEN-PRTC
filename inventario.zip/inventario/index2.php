<?php
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

require "conexion.php";

// ==========================================
// FILTROS
// ==========================================

$descripcion = $_GET["descripcion"] ?? "";
$cantidad    = $_GET["cantidad"] ?? "";
$ubicacion   = $_GET["ubicacion"] ?? "";
$maximo      = $_GET["maximo"] ?? "";
$minimo      = $_GET["minimo"] ?? "";
$proveedor   = $_GET["proveedor"] ?? "";

// ==========================================
// CONSULTA
// ==========================================

$sql = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        ubicacion,
        maximo,
        minimo,
        proveedor_marca
    FROM inventario
    WHERE 1=1
";

$parametros = [];
$tipos = "";

// Descripción
if ($descripcion !== "") {

    $sql .= " AND articulo_descripcion LIKE ?";

    $parametros[] = "%$descripcion%";
    $tipos .= "s";
}

// Cantidad
if ($cantidad !== "") {

    $sql .= " AND cantidad = ?";

    $parametros[] = $cantidad;
    $tipos .= "i";
}

// Ubicación
if ($ubicacion !== "") {

    $sql .= " AND ubicacion LIKE ?";

    $parametros[] = "%$ubicacion%";
    $tipos .= "s";
}

// Máximo
if ($maximo !== "") {

    $sql .= " AND maximo = ?";

    $parametros[] = $maximo;
    $tipos .= "i";
}

// Mínimo
if ($minimo !== "") {

    $sql .= " AND minimo = ?";

    $parametros[] = $minimo;
    $tipos .= "i";
}

// Proveedor / Marca
if ($proveedor !== "") {

    $sql .= " AND proveedor_marca LIKE ?";

    $parametros[] = "%$proveedor%";
    $tipos .= "s";
}

$sql .= " ORDER BY id DESC";

$stmt = $conexion->prepare($sql);

if (!empty($parametros)) {

    $stmt->bind_param(
        $tipos,
        ...$parametros
    );
}

$stmt->execute();

$resultado = $stmt->get_result();

?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Inventario</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            color: #333;
        }

        .contenedor {
            width: 95%;
            max-width: 1400px;
            margin: 30px auto;
        }

        h1 {
            margin-bottom: 20px;
        }

        .filtros {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,.10);
            margin-bottom: 20px;
        }

        .filtros-grid {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
        }

        .campo label {
            display: block;
            font-size: 13px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .campo input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .botones {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }

        button,
        .boton {
            padding: 10px 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .buscar {
            background: #007bff;
            color: white;
        }

        .limpiar {
            background: #6c757d;
            color: white;
        }

        .importar {
            background: #198754;
            color: white;
        }

        .tabla-contenedor {
            background: white;
            border-radius: 10px;
            overflow-x: auto;
            box-shadow: 0 2px 8px rgba(0,0,0,.10);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        th {
            background: #212529;
            color: white;
            padding: 12px;
            text-align: left;
        }

        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background: #f8f9fa;
        }

        .editar {
            background: #ffc107;
            color: #000;
        }

        .eliminar {
            background: #dc3545;
            color: white;
        }

        .bajo {
            background: #ffe0e0;
            color: #b00000;
            font-weight: bold;
        }

        .normal {
            background: #e0ffe7;
            color: #08752a;
        }

        .acciones {
            white-space: nowrap;
        }

        .sin-registros {
            text-align: center;
            padding: 30px;
        }

        .nuevo {
            background: #6f42c1;
            color: white;
        }


    </style>

</head>

<body>

<div class="contenedor">

    <h1>📦 Inventario</h1>

    <!-- =====================================
         FILTROS
    ====================================== -->

    <div class="filtros">

        <form method="GET">

            <div class="filtros-grid">

                <div class="campo">

                    <label>
                        Artículo / Descripción
                    </label>

                    <input
                        type="text"
                        name="descripcion"
                        value="<?= htmlspecialchars($descripcion) ?>"
                        placeholder="Ej. abanico"
                    >

                </div>

                <div class="campo">

                    <label>
                        Cantidad
                    </label>

                    <input
                        type="number"
                        name="cantidad"
                        value="<?= htmlspecialchars($cantidad) ?>"
                        placeholder="Cantidad"
                    >

                </div>

                <div class="campo">

                    <label>
                        Ubicación
                    </label>

                    <input
                        type="text"
                        name="ubicacion"
                        value="<?= htmlspecialchars($ubicacion) ?>"
                        placeholder="Ej. A-01"
                    >

                </div>

                <div class="campo">

                    <label>
                        Máximo
                    </label>

                    <input
                        type="number"
                        name="maximo"
                        value="<?= htmlspecialchars($maximo) ?>"
                    >

                </div>

                <div class="campo">

                    <label>
                        Mínimo
                    </label>

                    <input
                        type="number"
                        name="minimo"
                        value="<?= htmlspecialchars($minimo) ?>"
                    >

                </div>

                <div class="campo">

                    <label>
                        Proveedor / Marca
                    </label>

                    <input
                        type="text"
                        name="proveedor"
                        value="<?= htmlspecialchars($proveedor) ?>"
                        placeholder="Proveedor o marca"
                    >

                </div>

            </div>

            <div class="botones">

                <button
                    type="submit"
                    class="buscar">
                    🔎 Buscar
                </button>

                <a
                    href="index.php"
                    class="boton limpiar">
                    🔄 Limpiar
                </a>

                <a
                    href="importar.php"
                    class="boton importar">
                    📥 Importar Excel
                </a>

                <a
                    href="nuevo_articulo.php"
                    class="boton nuevo">
                    ➕ Nuevo artículo
                </a>

                <a
                    href="entrada_almacen.php"
                    class="boton"
                    style="background:#198754;color:white;">
                    📥 Entrada de almacén
                </a>

            </div>

        </form>

    </div>

    <!-- =====================================
         TABLA
    ====================================== -->

    <div class="tabla-contenedor">

        <table>

            <thead>

                <tr>

                    <th>ID</th>
                    <th>Código</th>
                    <th>Descripción</th>
                    <th>Cantidad</th>
                    <th>Ubicación</th>
                    <th>Máximo</th>
                    <th>Mínimo</th>
                    <th>Proveedor / Marca</th>
                    <th>Acciones</th>

                </tr>

            </thead>

            <tbody>

            <?php if ($resultado->num_rows > 0): ?>

                <?php while ($producto = $resultado->fetch_assoc()): ?>

                    <tr>

                        <td>
                            <?= $producto["id"] ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $producto["codigo"]
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $producto["articulo_descripcion"]
                            ) ?>
                        </td>

                        <td class="<?=
                            $producto["cantidad"]
                            <= $producto["minimo"]
                            ? "bajo"
                            : "normal"
                        ?>">

                            <?= $producto["cantidad"] ?>

                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $producto["ubicacion"]
                            ) ?>
                        </td>

                        <td>
                            <?= $producto["maximo"] ?>
                        </td>

                        <td>
                            <?= $producto["minimo"] ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $producto["proveedor_marca"]
                            ) ?>
                        </td>

                        <td class="acciones">

                            <a
                                class="boton editar"
                                href="editar.php?id=<?= $producto["id"] ?>">
                                ✏️ Editar
                            </a>

                            <a
                                class="boton eliminar"
                                href="eliminar.php?id=<?= $producto["id"] ?>"
                                onclick="return confirm('¿Seguro que deseas eliminar este artículo?');">
                                🗑️ Eliminar
                            </a>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td
                        colspan="9"
                        class="sin-registros">

                        No se encontraron productos.

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>

<?php

$stmt->close();
$conexion->close();

?>
