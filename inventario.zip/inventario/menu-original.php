<?php

// ==========================================
// DATOS DEL USUARIO
// ==========================================

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';
$rol_usuario     = $_SESSION['rol'] ?? 'USUARIO';


// ==========================================
// PÁGINA ACTUAL
// ==========================================

$pagina_actual = basename($_SERVER['PHP_SELF']);

?>

<style>

/* ==========================================
   FUENTE GENERAL DEL MENÚ
========================================== */

.barra-lateral {

    font-family: Arial, sans-serif;

}


/* ==========================================
   BARRA LATERAL FIJA
========================================== */

.barra-lateral {

    position: fixed;

    top: 0;
    left: 0;
    bottom: 0;

    width: 240px;

    background: #212529;

    color: white;

    z-index: 1000;

    overflow-y: auto;

    box-shadow: 2px 0 8px rgba(0,0,0,.20);
}


/* ==========================================
   ENCABEZADO DEL MENÚ
========================================== */

.logo-menu {

    padding: 22px 18px;

    border-bottom: 1px solid #343a40;

    font-size: 18px;

    font-weight: bold;

    text-align: center;
}


.subtitulo-menu {

    font-size: 11px;

    font-weight: normal;

    color: #ced4da;

    margin-top: 5px;
}


/* ==========================================
   NAVEGACIÓN
========================================== */

.menu-navegacion {

    padding: 10px 0;
}


/* ==========================================
   OPCIONES
========================================== */

.menu-navegacion a {

    display: block;

    padding: 12px 16px;

    color: #ffffff;

    text-decoration: none;

    font-family: Arial, sans-serif;

    font-size: 14px;

    font-weight: normal;

    border-bottom: 1px solid #343a40;

    transition: background .2s;
}


/* ==========================================
   EFECTO AL PASAR EL CURSOR
========================================== */

.menu-navegacion a:hover {

    background: #495057;

    color: #ffffff;
}


/* ==========================================
   OPCIÓN ACTIVA
========================================== */

.menu-navegacion a.activo {

    background: #343a40;

    color: #ffffff;

    font-weight: bold;

    border-left: 4px solid #0d6efd;

    padding-left: 12px;
}


/* ==========================================
   USUARIO
========================================== */

.usuario-menu {

    position: absolute;

    bottom: 0;

    left: 0;

    right: 0;

    padding: 15px;

    border-top: 1px solid #343a40;

    background: #1c1f22;

    font-family: Arial, sans-serif;
}


.usuario-nombre {

    font-size: 13px;

    font-weight: bold;

    color: #ffffff;

    margin-bottom: 4px;

    word-break: break-word;
}


.usuario-rol {

    font-size: 11px;

    color: #ced4da;

    margin-bottom: 12px;
}


/* ==========================================
   BOTÓN SALIR
========================================== */

.boton-salir {

    display: block;

    width: 100%;

    padding: 8px 12px;

    background: #dc3545;

    color: #ffffff;

    text-decoration: none;

    text-align: center;

    border-radius: 5px;

    font-family: Arial, sans-serif;

    font-size: 14px;
}


.boton-salir:hover {

    background: #bb2d3b;

    color: #ffffff;
}


/* ==========================================
   CONTENIDO PRINCIPAL
========================================== */

.contenido-principal {

    margin-left: 240px;

    min-height: 100vh;
}


/* ==========================================
   BARRA SUPERIOR
========================================== */

.barra-superior {

    height: 70px;

    background: #ffffff;

    border-bottom: 1px solid #ddd;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow: 0 1px 5px rgba(0,0,0,.08);

    font-family: Arial, sans-serif;
}


.titulo-superior {

    font-size: 20px;

    font-weight: bold;

    color: #212529;
}


.usuario-superior {

    font-size: 13px;

    color: #555;
}


/* ==========================================
   RESPONSIVE
========================================== */

@media (max-width: 850px) {

    .barra-lateral {

        width: 210px;
    }


    .contenido-principal {

        margin-left: 210px;
    }

}


@media (max-width: 650px) {

    .barra-lateral {

        position: relative;

        width: 100%;

        height: auto;

        min-height: auto;
    }


    .usuario-menu {

        position: relative;

        margin-top: 10px;
    }


    .contenido-principal {

        margin-left: 0;
    }


    .barra-superior {

        height: auto;

        padding: 15px;

        flex-direction: column;

        align-items: flex-start;

        gap: 8px;
    }

}

</style>


<!-- ==========================================
     BARRA LATERAL
========================================== -->

<aside class="barra-lateral">


    <!-- ======================================
         ENCABEZADO
    ======================================= -->

    <div class="logo-menu">

        📦 Sistema de Almacén

        <div class="subtitulo-menu">

            Grupo Protec

        </div>

    </div>


    <!-- ======================================
         MENÚ PRINCIPAL
    ======================================= -->

    <nav class="menu-navegacion">


        <!-- INVENTARIO -->

        <a
            href="index.php"
            class="<?= $pagina_actual == 'index.php' ? 'activo' : '' ?>"
        >

            🏠 &nbsp; Inventario

        </a>


        <!-- NUEVO ARTÍCULO -->

        <a
            href="nuevo_articulo.php"
            class="<?= $pagina_actual == 'nuevo_articulo.php' ? 'activo' : '' ?>"
        >

            ➕ &nbsp; Nuevo artículo

        </a>


        <!-- ENTRADA -->

        <a
            href="entrada.php"
            class="<?= $pagina_actual == 'entrada.php' ? 'activo' : '' ?>"
        >

            📥 &nbsp; Entrada de almacén

        </a>


        <!-- SALIDA -->

        <a
            href="salida.php"
            class="<?= $pagina_actual == 'salida.php' ? 'activo' : '' ?>"
        >

            📤 &nbsp; Salida de almacén

        </a>


        <!-- HISTORIAL -->

        <a
            href="historial_movimientos.php"
            class="<?= $pagina_actual == 'historial_movimientos.php' ? 'activo' : '' ?>"
        >

            📋 &nbsp; Historial de movimientos

        </a>


        <!-- FACTURAS -->

        <a
            href="facturas.php"
            class="<?= $pagina_actual == 'facturas.php' ? 'activo' : '' ?>"
        >

            🧾 &nbsp; Facturas

        </a>


    </nav>


    <!-- ======================================
         USUARIO Y SALIR
    ======================================= -->

    <div class="usuario-menu">


        <div class="usuario-nombre">

            👤 <?= htmlspecialchars($nombre_empleado) ?>

        </div>


        <div class="usuario-rol">

            <?= htmlspecialchars($rol_usuario) ?>

        </div>


        <a
            href="logout.php"
            class="boton-salir"
        >

            🚪 Salir

        </a>


    </div>


</aside>