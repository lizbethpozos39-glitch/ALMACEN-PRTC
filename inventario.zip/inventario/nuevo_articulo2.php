<?php

// ==========================================
// SEGURIDAD
// ==========================================

require_once __DIR__ . '/seguridad.php';

verificar_sesion();


// ==========================================
// CONEXIÓN
// ==========================================

require_once __DIR__ . '/conexion.php';


// ==========================================
// VARIABLES
// ==========================================

$mensaje = "";
$error = "";

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';


// ==========================================
// OBTENER UBICACIONES
// ==========================================

$ubicaciones = [];

$sql_ubicaciones = "
    SELECT
        id,
        codigo,
        descripcion,
        tipo
    FROM ubicaciones
    WHERE activo = 1
    ORDER BY
        CASE tipo
            WHEN 'RACK' THEN 1
            WHEN 'GAVETA' THEN 2
            WHEN 'ESPECIAL' THEN 3
            ELSE 4
        END,
        codigo ASC
";

$resultado_ubicaciones = $conexion->query($sql_ubicaciones);

if ($resultado_ubicaciones) {

    while ($fila = $resultado_ubicaciones->fetch_assoc()) {

        $ubicaciones[] = $fila;

    }

}


// ==========================================
// OBTENER ARTÍCULOS DEL INVENTARIO
// ==========================================

$articulos = [];

$sql_articulos = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        ubicacion,
        maximo,
        minimo,
        proveedor_marca
    FROM inventario
    ORDER BY articulo_descripcion ASC
";

$resultado_articulos = $conexion->query($sql_articulos);

if ($resultado_articulos) {

    while ($fila = $resultado_articulos->fetch_assoc()) {

        $articulos[] = $fila;

    }

}


// ==========================================
// PROCESAR FORMULARIO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $accion = $_POST["accion"] ?? "";


    // =====================================================
    // ACCIÓN 1: INGRESAR CANTIDAD A ARTÍCULO EXISTENTE
    // =====================================================

    if ($accion === "ingreso_existente") {

        $id_articulo = intval(
            $_POST["id_articulo"] ?? 0
        );

        $cantidad_reingreso = intval(
            $_POST["cantidad"] ?? 0
        );

        $ubicacion_nueva = trim(
            $_POST["ubicacion"] ?? ""
        );


        // ==============================================
        // VALIDACIONES
        // ==============================================

        if ($id_articulo <= 0) {

            $error = "Debes seleccionar un artículo.";

        } elseif ($cantidad_reingreso <= 0) {

            $error =
                "La cantidad a ingresar debe ser mayor a 0.";

        } else {


            // ==============================================
            // VALIDAR UBICACIÓN
            // ==============================================

            if ($ubicacion_nueva !== "") {

                $validar_ubicacion = $conexion->prepare("
                    SELECT id
                    FROM ubicaciones
                    WHERE codigo = ?
                    AND activo = 1
                    LIMIT 1
                ");

                if (!$validar_ubicacion) {

                    $error =
                        "Error al preparar la validación de ubicación: "
                        . $conexion->error;

                } else {

                    $validar_ubicacion->bind_param(
                        "s",
                        $ubicacion_nueva
                    );

                    $validar_ubicacion->execute();

                    $resultado_ubicacion =
                        $validar_ubicacion->get_result();

                    if ($resultado_ubicacion->num_rows === 0) {

                        $error =
                            "La ubicación seleccionada no es válida.";

                    }

                    $validar_ubicacion->close();

                }

            }


            // ==============================================
            // BUSCAR ARTÍCULO
            // ==============================================

            if ($error === "") {

                $buscar = $conexion->prepare("
                    SELECT
                        id,
                        codigo,
                        articulo_descripcion,
                        cantidad,
                        ubicacion,
                        maximo,
                        minimo,
                        proveedor_marca
                    FROM inventario
                    WHERE id = ?
                    LIMIT 1
                ");

                if (!$buscar) {

                    $error =
                        "Error al preparar la consulta: "
                        . $conexion->error;

                } else {

                    $buscar->bind_param(
                        "i",
                        $id_articulo
                    );

                    $buscar->execute();

                    $resultado = $buscar->get_result();


                    // ==========================================
                    // ARTÍCULO NO ENCONTRADO
                    // ==========================================

                    if ($resultado->num_rows === 0) {

                        $error =
                            "El artículo seleccionado no existe "
                            . "en el inventario.";

                    } else {


                        // ==========================================
                        // DATOS DEL ARTÍCULO
                        // ==========================================

                        $articulo = $resultado->fetch_assoc();

                        $cantidad_actual =
                            intval($articulo["cantidad"]);


                        // ==========================================
                        // NUEVA CANTIDAD
                        // ==========================================

                        $nueva_cantidad =
                            $cantidad_actual
                            + $cantidad_reingreso;


                        // ==========================================
                        // UBICACIÓN
                        // ==========================================

                        /*
                         * Si el usuario seleccionó una ubicación,
                         * se guarda.
                         *
                         * Si dejó "Sin ubicación", conservamos
                         * la ubicación que ya tenía el artículo.
                         */

                        if ($ubicacion_nueva === "") {

                            $ubicacion_guardar =
                                $articulo["ubicacion"];

                        } else {

                            $ubicacion_guardar =
                                $ubicacion_nueva;

                        }


                        // ==========================================
                        // ACTUALIZAR INVENTARIO
                        // ==========================================

                        $actualizar = $conexion->prepare("
                            UPDATE inventario
                            SET
                                cantidad = ?,
                                ubicacion = ?
                            WHERE id = ?
                        ");

                        if (!$actualizar) {

                            $error =
                                "Error al preparar la actualización: "
                                . $conexion->error;

                        } else {

                            $actualizar->bind_param(
                                "isi",
                                $nueva_cantidad,
                                $ubicacion_guardar,
                                $id_articulo
                            );


                            // ======================================
                            // GUARDAR
                            // ======================================

                            if ($actualizar->execute()) {

                                header(
                                    "Location: nuevo_articulo.php?"
                                    . "mensaje=reingreso_realizado"
                                );

                                exit;

                            } else {

                                $error =
                                    "Error al actualizar el inventario: "
                                    . $actualizar->error;

                            }


                            $actualizar->close();

                        }

                    }


                    $buscar->close();

                }

            }

        }

    }


    // =====================================================
    // ACCIÓN 2: CREAR ARTÍCULO NUEVO
    // =====================================================

    elseif ($accion === "nuevo_articulo") {

        $codigo = trim(
            $_POST["nuevo_codigo"] ?? ""
        );

        $descripcion = trim(
            $_POST["nueva_descripcion"] ?? ""
        );

        $cantidad = intval(
            $_POST["nueva_cantidad"] ?? 0
        );

        $ubicacion = trim(
            $_POST["nueva_ubicacion"] ?? ""
        );

        $maximo = intval(
            $_POST["nuevo_maximo"] ?? 0
        );

        $minimo = intval(
            $_POST["nuevo_minimo"] ?? 0
        );

        $proveedor = trim(
            $_POST["nuevo_proveedor"] ?? ""
        );


        // ==============================================
        // VALIDACIONES
        // ==============================================

        if ($codigo === "") {

            $error =
                "Debes ingresar el código del artículo.";

        } elseif ($descripcion === "") {

            $error =
                "Debes ingresar la descripción del artículo.";

        } elseif ($cantidad < 0) {

            $error =
                "La cantidad no puede ser negativa.";

        } elseif ($maximo < 0) {

            $error =
                "El máximo no puede ser negativo.";

        } elseif ($minimo < 0) {

            $error =
                "El mínimo no puede ser negativo.";

        }


        // ==============================================
        // VALIDAR CÓDIGO DUPLICADO
        // ==============================================

        if ($error === "") {

            $buscar_codigo = $conexion->prepare("
                SELECT id
                FROM inventario
                WHERE codigo = ?
                LIMIT 1
            ");

            if (!$buscar_codigo) {

                $error =
                    "Error al validar el código: "
                    . $conexion->error;

            } else {

                $buscar_codigo->bind_param(
                    "s",
                    $codigo
                );

                $buscar_codigo->execute();

                $resultado_codigo =
                    $buscar_codigo->get_result();

                if ($resultado_codigo->num_rows > 0) {

                    $error =
                        "El código "
                        . htmlspecialchars($codigo)
                        . " ya existe en el inventario.";

                }

                $buscar_codigo->close();

            }

        }


        // ==============================================
        // VALIDAR UBICACIÓN
        // ==============================================

        if (
            $error === ""
            && $ubicacion !== ""
        ) {

            $validar_ubicacion = $conexion->prepare("
                SELECT id
                FROM ubicaciones
                WHERE codigo = ?
                AND activo = 1
                LIMIT 1
            ");

            if (!$validar_ubicacion) {

                $error =
                    "Error al validar la ubicación: "
                    . $conexion->error;

            } else {

                $validar_ubicacion->bind_param(
                    "s",
                    $ubicacion
                );

                $validar_ubicacion->execute();

                $resultado_ubicacion =
                    $validar_ubicacion->get_result();

                if ($resultado_ubicacion->num_rows === 0) {

                    $error =
                        "La ubicación seleccionada no es válida.";

                }

                $validar_ubicacion->close();

            }

        }


        // ==============================================
        // INSERTAR ARTÍCULO
        // ==============================================

        if ($error === "") {

            /*
             * Si no seleccionó ubicación,
             * guardamos NULL.
             */

            if ($ubicacion === "") {

                $ubicacion_db = null;

            } else {

                $ubicacion_db = $ubicacion;

            }


            $insertar = $conexion->prepare("
                INSERT INTO inventario (
                    codigo,
                    articulo_descripcion,
                    cantidad,
                    costo_unitario,
                    ubicacion,
                    maximo,
                    minimo,
                    proveedor_marca
                )
                VALUES (
                    ?,
                    ?,
                    ?,
                    0,
                    ?,
                    ?,
                    ?,
                    ?
                )
            ");


            if (!$insertar) {

                $error =
                    "Error al preparar el registro del artículo: "
                    . $conexion->error;

            } else {

                $insertar->bind_param(
                    "ssisiis",
                    $codigo,
                    $descripcion,
                    $cantidad,
                    $ubicacion_db,
                    $maximo,
                    $minimo,
                    $proveedor
                );


                if ($insertar->execute()) {

                    header(
                        "Location: nuevo_articulo.php?"
                        . "mensaje=articulo_creado"
                    );

                    exit;

                } else {

                    $error =
                        "Error al registrar el artículo: "
                        . $insertar->error;

                }


                $insertar->close();

            }

        }

    }

}


// ==========================================
// MENSAJES POR GET
// ==========================================

if (
    isset($_GET["mensaje"])
) {

    if (
        $_GET["mensaje"] ===
        "reingreso_realizado"
    ) {

        $mensaje =
            "El ingreso se registró correctamente.";

    }

    elseif (
        $_GET["mensaje"] ===
        "articulo_creado"
    ) {

        $mensaje =
            "El nuevo artículo se agregó correctamente "
            . "al inventario.";

    }

}

?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Ingreso de artículo</title>


    <style>

        /* ==========================================
           CONFIGURACIÓN GENERAL
        =========================================== */

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            padding: 0;

            font-family: Arial, sans-serif;

            background: #f4f6f8;

            color: #333;

        }


        /* ==========================================
           CONTENIDO PRINCIPAL
        =========================================== */

        .contenido-principal {

            margin-left: 240px;

            min-height: 100vh;

        }


        /* ==========================================
           BARRA SUPERIOR
        =========================================== */

        .barra-superior {

            height: 70px;

            background: #ffffff;

            border-bottom: 1px solid #ddd;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 30px;

            box-shadow:
                0 1px 5px rgba(0,0,0,.08);

        }


        .titulo-superior {

            font-size: 20px;

            font-weight: bold;

            color: #212529;

        }


        .usuario-superior {

            font-size: 13px;

            color: #555;

        }


        /* ==========================================
           CONTENEDOR
        =========================================== */

        .contenedor {

            max-width: 700px;

            margin: 40px auto;

            background: white;

            padding: 30px;

            border-radius: 12px;

            box-shadow:
                0 3px 15px rgba(0,0,0,.15);

        }


        h1 {

            margin-top: 0;

            color: #333;

        }


        .descripcion-ayuda {

            color: #666;

            font-size: 14px;

            margin-bottom: 25px;

            line-height: 1.5;

        }


        /* ==========================================
           FORMULARIO
        =========================================== */

        .formulario {

            display: grid;

            grid-template-columns: 1fr 1fr;

            gap: 15px;

        }


        .campo {

            display: flex;

            flex-direction: column;

        }


        .campo-completo {

            grid-column: 1 / -1;

        }


        label {

            font-weight: bold;

            margin-bottom: 6px;

        }


        input,
        select {

            padding: 11px;

            border: 1px solid #ccc;

            border-radius: 6px;

            font-size: 15px;

            font-family: Arial, sans-serif;

        }


        input:focus,
        select:focus {

            outline: none;

            border-color: #0d6efd;

            box-shadow:
                0 0 0 2px rgba(13,110,253,.10);

        }


        input[readonly] {

            background: #f1f3f5;

            color: #555;

        }


        /* ==========================================
           INFORMACIÓN DEL ARTÍCULO
        =========================================== */

        .informacion-articulo {

            margin-top: 20px;

            padding: 15px;

            background: #f8f9fa;

            border: 1px solid #ddd;

            border-radius: 8px;

        }


        .informacion-articulo h3 {

            margin-top: 0;

            margin-bottom: 15px;

            font-size: 16px;

            color: #212529;

        }


        /* ==========================================
           NUEVO ARTÍCULO
        =========================================== */

        .nuevo-articulo {

            display: none;

            margin-top: 25px;

            padding: 20px;

            background: #f8f9fa;

            border: 1px solid #ddd;

            border-radius: 8px;

        }


        .nuevo-articulo h2 {

            margin-top: 0;

            font-size: 19px;

            color: #212529;

        }


        .ayuda-nuevo {

            color: #666;

            font-size: 13px;

            line-height: 1.5;

            margin-bottom: 20px;

        }


        /* ==========================================
           BOTONES
        =========================================== */

        .botones {

            margin-top: 25px;

            display: flex;

            gap: 10px;

            flex-wrap: wrap;

        }


        button,
        .cancelar {

            padding: 12px 20px;

            border: none;

            border-radius: 6px;

            text-decoration: none;

            cursor: pointer;

            font-size: 15px;

            font-family: Arial, sans-serif;

        }


        button {

            background: #198754;

            color: white;

        }


        button:hover {

            background: #157347;

        }


        .cancelar {

            background: #6c757d;

            color: white;

        }


        .cancelar:hover {

            background: #5a6268;

        }


        .boton-nuevo {

            background: #0d6efd;

            color: white;

        }


        .boton-nuevo:hover {

            background: #0b5ed7;

        }


        .boton-cerrar {

            background: #6c757d;

            color: white;

        }


        .boton-cerrar:hover {

            background: #5a6268;

        }


        /* ==========================================
           MENSAJES
        =========================================== */

        .error {

            background: #f8d7da;

            color: #842029;

            padding: 12px;

            margin-bottom: 20px;

            border-radius: 6px;

        }


        .mensaje {

            background: #d1e7dd;

            color: #0f5132;

            padding: 12px;

            margin-bottom: 20px;

            border-radius: 6px;

        }


        /* ==========================================
           TEXTO DE UBICACIÓN
        =========================================== */

        .ayuda-ubicacion {

            font-size: 12px;

            color: #666;

            margin-top: 5px;

        }


        /* ==========================================
           RESPONSIVE
        =========================================== */

        @media (max-width: 850px) {

            .contenido-principal {

                margin-left: 210px;

            }

        }


        @media (max-width: 650px) {

            .contenido-principal {

                margin-left: 0;

            }


            .barra-superior {

                height: auto;

                padding: 15px;

                flex-direction: column;

                align-items: flex-start;

                gap: 8px;

            }


            .contenedor {

                width: 92%;

                margin: 20px auto;

                padding: 20px;

            }


            .formulario {

                grid-template-columns: 1fr;

            }


            .campo-completo {

                grid-column: auto;

            }

        }

    </style>

</head>


<body>


<!-- ==========================================
     MENÚ LATERAL
========================================== -->

<?php include 'menu.php'; ?>


<!-- ==========================================
     CONTENIDO PRINCIPAL
========================================== -->

<main class="contenido-principal">


    <!-- ======================================
         BARRA SUPERIOR
    ======================================= -->

    <header class="barra-superior">

        <div class="titulo-superior">

            📥 Ingreso de artículo

        </div>


        <div class="usuario-superior">

            Usuario:

            <strong>

                <?= htmlspecialchars($nombre_empleado) ?>

            </strong>

        </div>

    </header>


    <!-- ======================================
         FORMULARIO
    ======================================= -->

    <div class="contenedor">


        <h1>

            📥 Ingreso de artículo

        </h1>


        <p class="descripcion-ayuda">

            Selecciona un artículo existente del inventario
            y registra la cantidad que está ingresando.
            Si el artículo no existe, puedes agregarlo
            directamente al inventario.

        </p>


        <!-- ==================================
             MENSAJE
        =================================== -->

        <?php if ($mensaje !== ""): ?>

            <div class="mensaje">

                ✅

                <?= htmlspecialchars($mensaje) ?>

            </div>

        <?php endif; ?>


        <!-- ==================================
             ERROR
        =================================== -->

        <?php if ($error !== ""): ?>

            <div class="error">

                ❌

                <?= htmlspecialchars($error) ?>

            </div>

        <?php endif; ?>


        <!-- ==================================================
             FORMULARIO ARTÍCULO EXISTENTE
        =================================================== -->

        <form method="POST">

            <input
                type="hidden"
                name="accion"
                value="ingreso_existente"
            >


            <div class="formulario">


                <!-- ==================================
                     SELECCIONAR ARTÍCULO
                =================================== -->

                <div class="campo campo-completo">

                    <label>

                        Artículo

                    </label>


                    <select
                        name="id_articulo"
                        id="id_articulo"
                        required
                    >

                        <option value="">

                            -- Selecciona un artículo --

                        </option>


                        <?php foreach ($articulos as $item): ?>

                            <option
                                value="<?= $item['id'] ?>"

                                data-descripcion="<?= htmlspecialchars(
                                    $item['articulo_descripcion'],
                                    ENT_QUOTES
                                ) ?>"

                                data-ubicacion="<?= htmlspecialchars(
                                    $item['ubicacion'] ?? '',
                                    ENT_QUOTES
                                ) ?>"

                                data-maximo="<?= $item['maximo'] ?>"

                                data-minimo="<?= $item['minimo'] ?>"

                                data-proveedor="<?= htmlspecialchars(
                                    $item['proveedor_marca'] ?? '',
                                    ENT_QUOTES
                                ) ?>"
                            >

                                <?= htmlspecialchars(
                                    $item['codigo']
                                ) ?>

                                -

                                <?= htmlspecialchars(
                                    $item['articulo_descripcion']
                                ) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <!-- ==================================
                     CANTIDAD
                =================================== -->

                <div class="campo campo-completo">

                    <label>

                        Cantidad a ingresar

                    </label>


                    <input
                        type="number"
                        name="cantidad"
                        min="1"
                        required
                        value="1"
                    >

                </div>


                <!-- ==================================
                     INFORMACIÓN AUTOMÁTICA
                =================================== -->

                <div
                    class="informacion-articulo campo-completo"
                >

                    <h3>

                        Información del artículo

                    </h3>


                    <div class="formulario">


                        <!-- DESCRIPCIÓN -->

                        <div class="campo campo-completo">

                            <label>

                                Artículo / Descripción

                            </label>


                            <input
                                type="text"
                                id="articulo_descripcion"
                                readonly
                                placeholder="Se llenará automáticamente"
                            >

                        </div>


                        <!-- UBICACIÓN -->

                        <div class="campo">

                            <label>

                                Ubicación

                            </label>


                            <select
                                name="ubicacion"
                                id="ubicacion"
                            >

                                <option value="">

                                    -- Sin ubicación --

                                </option>


                                <?php foreach ($ubicaciones as $ubicacion_item): ?>

                                    <option
                                        value="<?= htmlspecialchars(
                                            $ubicacion_item['codigo'],
                                            ENT_QUOTES
                                        ) ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $ubicacion_item['codigo']
                                        ) ?>

                                        <?php if (
                                            !empty(
                                                $ubicacion_item['descripcion']
                                            )
                                        ): ?>

                                            -
                                            <?= htmlspecialchars(
                                                $ubicacion_item['descripcion']
                                            ) ?>

                                        <?php endif; ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>


                            <div class="ayuda-ubicacion">

                                Si el artículo ya tiene ubicación,
                                se seleccionará automáticamente.

                            </div>

                        </div>


                        <!-- MÁXIMO -->

                        <div class="campo">

                            <label>

                                Máximo

                            </label>


                            <input
                                type="number"
                                id="maximo"
                                readonly
                            >

                        </div>


                        <!-- MÍNIMO -->

                        <div class="campo">

                            <label>

                                Mínimo

                            </label>


                            <input
                                type="number"
                                id="minimo"
                                readonly
                            >

                        </div>


                        <!-- PROVEEDOR -->

                        <div class="campo campo-completo">

                            <label>

                                Proveedor / Marca

                            </label>


                            <input
                                type="text"
                                id="proveedor_marca"
                                readonly
                            >

                        </div>


                    </div>

                </div>


            </div>


            <!-- ==================================
                 BOTONES
            =================================== -->

            <div class="botones">


                <button
                    type="submit"
                >

                    💾 Registrar ingreso

                </button>


                <button
                    type="button"
                    class="boton-nuevo"
                    onclick="mostrarNuevoArticulo()"
                >

                    ➕ Agregar nuevo artículo

                </button>


                <a
                    href="index.php"
                    class="cancelar"
                >

                    ↩️ Volver al inventario

                </a>


            </div>


        </form>


        <!-- ==================================================
             FORMULARIO NUEVO ARTÍCULO
        =================================================== -->

        <div
            class="nuevo-articulo"
            id="nuevo_articulo"
        >

            <h2>

                ➕ Agregar nuevo artículo

            </h2>


            <p class="ayuda-nuevo">

                Utiliza este formulario cuando el artículo
                todavía no exista en el inventario.

            </p>


            <form method="POST">


                <input
                    type="hidden"
                    name="accion"
                    value="nuevo_articulo"
                >


                <div class="formulario">


                    <!-- CÓDIGO -->

                    <div class="campo">

                        <label>

                            Código *

                        </label>


                        <input
                            type="text"
                            name="nuevo_codigo"
                            required
                            maxlength="100"
                            value="<?= htmlspecialchars(
                                $_POST["nuevo_codigo"] ?? ""
                            ) ?>"
                        >

                    </div>


                    <!-- CANTIDAD -->

                    <div class="campo">

                        <label>

                            Cantidad inicial

                        </label>


                        <input
                            type="number"
                            name="nueva_cantidad"
                            min="0"
                            value="<?= htmlspecialchars(
                                $_POST["nueva_cantidad"] ?? "0"
                            ) ?>"
                        >

                    </div>


                    <!-- DESCRIPCIÓN -->

                    <div class="campo campo-completo">

                        <label>

                            Artículo / Descripción *

                        </label>


                        <input
                            type="text"
                            name="nueva_descripcion"
                            required
                            maxlength="255"
                            value="<?= htmlspecialchars(
                                $_POST["nueva_descripcion"] ?? ""
                            ) ?>"
                        >

                    </div>


                    <!-- UBICACIÓN -->

                    <div class="campo campo-completo">

                        <label>

                            Ubicación

                        </label>


                        <select
                            name="nueva_ubicacion"
                        >

                            <option value="">

                                -- Sin ubicación --

                            </option>


                            <?php foreach ($ubicaciones as $ubicacion_item): ?>

                                <option
                                    value="<?= htmlspecialchars(
                                        $ubicacion_item['codigo'],
                                        ENT_QUOTES
                                    ) ?>"

                                    <?= (
                                        (
                                            $_POST["nueva_ubicacion"]
                                            ?? ""
                                        )
                                        ===
                                        $ubicacion_item['codigo']
                                    )
                                    ? "selected"
                                    : ""
                                    ?>
                                >

                                    <?= htmlspecialchars(
                                        $ubicacion_item['codigo']
                                    ) ?>

                                    <?php if (
                                        !empty(
                                            $ubicacion_item['descripcion']
                                        )
                                    ): ?>

                                        -
                                        <?= htmlspecialchars(
                                            $ubicacion_item['descripcion']
                                        ) ?>

                                    <?php endif; ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- MÁXIMO -->

                    <div class="campo">

                        <label>

                            Máximo

                        </label>


                        <input
                            type="number"
                            name="nuevo_maximo"
                            min="0"
                            value="<?= htmlspecialchars(
                                $_POST["nuevo_maximo"] ?? "0"
                            ) ?>"
                        >

                    </div>


                    <!-- MÍNIMO -->

                    <div class="campo">

                        <label>

                            Mínimo

                        </label>


                        <input
                            type="number"
                            name="nuevo_minimo"
                            min="0"
                            value="<?= htmlspecialchars(
                                $_POST["nuevo_minimo"] ?? "0"
                            ) ?>"
                        >

                    </div>


                    <!-- PROVEEDOR -->

                    <div class="campo campo-completo">

                        <label>

                            Proveedor / Marca

                        </label>


                        <input
                            type="text"
                            name="nuevo_proveedor"
                            maxlength="255"
                            value="<?= htmlspecialchars(
                                $_POST["nuevo_proveedor"] ?? ""
                            ) ?>"
                        >

                    </div>


                </div>


                <!-- ==================================
                     BOTONES NUEVO ARTÍCULO
                =================================== -->

                <div class="botones">


                    <button
                        type="submit"
                    >

                        💾 Guardar artículo

                    </button>


                    <button
                        type="button"
                        class="boton-cerrar"
                        onclick="ocultarNuevoArticulo()"
                    >

                        ✖ Cancelar

                    </button>


                </div>


            </form>

        </div>


    </div>


</main>


<!-- ==========================================
     JAVASCRIPT
========================================== -->

<script>


// ==========================================
// ELEMENTOS
// ==========================================

const selector =
    document.getElementById("id_articulo");

const descripcion =
    document.getElementById("articulo_descripcion");

const ubicacion =
    document.getElementById("ubicacion");

const maximo =
    document.getElementById("maximo");

const minimo =
    document.getElementById("minimo");

const proveedor =
    document.getElementById("proveedor_marca");

const nuevoArticulo =
    document.getElementById("nuevo_articulo");


// ==========================================
// CAMBIO DE ARTÍCULO
// ==========================================

selector.addEventListener(
    "change",
    function () {

        const opcion =
            this.options[this.selectedIndex];


        if (!this.value) {

            descripcion.value = "";

            ubicacion.value = "";

            maximo.value = "";

            minimo.value = "";

            proveedor.value = "";

            return;

        }


        // ==================================
        // DESCRIPCIÓN
        // ==================================

        descripcion.value =
            opcion.dataset.descripcion || "";


        // ==================================
        // UBICACIÓN
        // ==================================

        const ubicacionArticulo =
            opcion.dataset.ubicacion || "";


        /*
         * Si el artículo ya tiene ubicación
         * y esa ubicación existe en el select,
         * la seleccionamos automáticamente.
         */

        if (ubicacionArticulo !== "") {

            ubicacion.value =
                ubicacionArticulo;

        } else {

            /*
             * Si no tiene ubicación,
             * dejamos el selector en
             * "Sin ubicación".
             */

            ubicacion.value = "";

        }


        // ==================================
        // MÁXIMO
        // ==================================

        maximo.value =
            opcion.dataset.maximo || "0";


        // ==================================
        // MÍNIMO
        // ==================================

        minimo.value =
            opcion.dataset.minimo || "0";


        // ==================================
        // PROVEEDOR
        // ==================================

        proveedor.value =
            opcion.dataset.proveedor || "";

    }
);


// ==========================================
// MOSTRAR NUEVO ARTÍCULO
// ==========================================

function mostrarNuevoArticulo() {

    nuevoArticulo.style.display = "block";


    nuevoArticulo.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

}


// ==========================================
// OCULTAR NUEVO ARTÍCULO
// ==========================================

function ocultarNuevoArticulo() {

    nuevoArticulo.style.display = "none";

}


// ==========================================
// SI HUBO ERROR AL CREAR ARTÍCULO
// MOSTRAR AUTOMÁTICAMENTE EL FORMULARIO
// ==========================================

<?php if (
    isset($_POST["accion"])
    &&
    $_POST["accion"] === "nuevo_articulo"
    &&
    $error !== ""
): ?>

mostrarNuevoArticulo();

<?php endif; ?>


</script>


</body>

</html>