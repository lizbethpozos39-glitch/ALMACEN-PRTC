<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_gerencia();

include __DIR__ . '/menu.php';

?>

<style>

/* ==========================================
   PORTAL DE GERENCIA
========================================== */

.portal-gerencia {

    width: 100%;

    box-sizing: border-box;

    padding: 30px 25px 50px 25px;

    font-family: Georgia, "Times New Roman", serif;

}


/* ==========================================
   ENCABEZADO
========================================== */

.encabezado-gerencia {

    background: #ffffff;

    border-radius: 0 0 14px 14px;

    padding: 30px 35px;

    margin-bottom: 35px;

    box-shadow:
        0 3px 12px rgba(0,0,0,.08);

    border: 1px solid #e5e5e5;

}


.encabezado-contenido {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 25px;

}


.encabezado-gerencia h1 {

    margin: 0 0 8px 0;

    color: #212529;

    font-size: 30px;

}


.encabezado-gerencia p {

    margin: 0;

    color: #6c757d;

    font-size: 15px;

}


.badge-gerencia {

    background: #212529;

    color: #ffffff;

    padding: 10px 18px;

    border-radius: 25px;

    font-family: Arial, sans-serif;

    font-size: 12px;

    font-weight: bold;

    white-space: nowrap;

}


/* ==========================================
   SECCIONES
========================================== */

.seccion-gerencia {

    margin-bottom: 38px;

}


.titulo-seccion {

    display: flex;

    align-items: center;

    gap: 12px;

    margin-bottom: 18px;

}


.titulo-seccion h2 {

    margin: 0;

    font-size: 21px;

    color: #212529;

    white-space: nowrap;

}


.linea-seccion {

    height: 1px;

    background: #d9d9d9;

    flex: 1;

}


/* ==========================================
   GRID
========================================== */

.grid-gerencia {

    display: grid;

    grid-template-columns:
        repeat(3, minmax(0, 1fr));

    gap: 20px;

}


/* ==========================================
   TARJETAS
========================================== */

.tarjeta-gerencia {

    background: #ffffff;

    border: 1px solid #e1e5e8;

    border-radius: 12px;

    padding: 22px;

    min-height: 230px;

    box-sizing: border-box;

    display: flex;

    flex-direction: column;

    box-shadow:
        0 4px 12px rgba(0,0,0,.07);

    transition:
        transform .2s ease,
        box-shadow .2s ease;

}


.tarjeta-gerencia:hover {

    transform: translateY(-3px);

    box-shadow:
        0 7px 18px rgba(0,0,0,.12);

}


/* ==========================================
   ICONO
========================================== */

.icono-gerencia {

    width: 48px;

    height: 48px;

    display: flex;

    align-items: center;

    justify-content: center;

    background: #f1f3f5;

    border-radius: 11px;

    font-size: 24px;

    margin-bottom: 16px;

}


/* ==========================================
   TEXTO
========================================== */

.tarjeta-gerencia h3 {

    margin: 0 0 9px 0;

    font-size: 18px;

    color: #212529;

}


.tarjeta-gerencia p {

    margin: 0;

    color: #6c757d;

    font-family: Arial, sans-serif;

    font-size: 13px;

    line-height: 1.5;

    flex: 1;

}


/* ==========================================
   BOTÓN
========================================== */

.tarjeta-boton {

    margin-top: 20px;

}


.boton-gerencia {

    display: flex;

    align-items: center;

    justify-content: center;

    width: 100%;

    min-height: 40px;

    box-sizing: border-box;

    padding: 10px 15px;

    background: #212529;

    color: #ffffff;

    text-decoration: none;

    border-radius: 6px;

    font-family: Arial, sans-serif;

    font-size: 13px;

    font-weight: bold;

    transition:
        background .2s ease,
        transform .2s ease;

}


.boton-gerencia:hover {

    background: #343a40;

    color: #ffffff;

    transform: translateY(-1px);

}


.flecha-boton {

    margin-left: 7px;

}


/* ==========================================
   PIE DEL PORTAL
========================================== */

.pie-portal {

    margin-top: 10px;

    padding: 20px;

    text-align: center;

    color: #868e96;

    font-family: Arial, sans-serif;

    font-size: 12px;

    border-top: 1px solid #e1e1e1;

}


/* ==========================================
   TABLET
========================================== */

@media (max-width: 1100px) {

    .grid-gerencia {

        grid-template-columns:
            repeat(2, minmax(0, 1fr));

    }

}


/* ==========================================
   TABLET PEQUEÑA
========================================== */

@media (max-width: 850px) {

    .portal-gerencia {

        padding:
            25px 20px 40px 20px;

    }


    .encabezado-gerencia {

        padding: 25px;

    }


    .encabezado-contenido {

        align-items: flex-start;

        flex-direction: column;

    }

}


/* ==========================================
   MÓVIL
========================================== */

@media (max-width: 650px) {

    .portal-gerencia {

        padding:
            20px 15px 35px 15px;

    }


    .encabezado-gerencia {

        padding: 22px;

        margin-bottom: 25px;

    }


    .encabezado-gerencia h1 {

        font-size: 24px;

    }


    .grid-gerencia {

        grid-template-columns: 1fr;

        gap: 15px;

    }


    .tarjeta-gerencia {

        min-height: 210px;

    }


    .titulo-seccion h2 {

        font-size: 18px;

    }

}

</style>


<!-- ==========================================
     CONTENIDO PRINCIPAL
========================================== -->

<div class="contenido-principal">


    <main class="portal-gerencia">


        <!-- ======================================
             ENCABEZADO
        ======================================= -->

        <section class="encabezado-gerencia">

            <div class="encabezado-contenido">

                <div>

                    <h1>
                        Portal de Gerencia
                    </h1>

                    <p>
                        Acceso centralizado a información,
                        documentación, capacitación,
                        sistemas y recursos de la empresa.
                    </p>

                </div>


                <div class="badge-gerencia">

                    🔐 Acceso autorizado

                </div>

            </div>

        </section>


        <!-- ======================================
             1. INFORMACIÓN OPERATIVA
        ======================================= -->

        <section class="seccion-gerencia">


            <div class="titulo-seccion">

                <h2>
                    Información operativa
                </h2>

                <div class="linea-seccion"></div>

            </div>


            <div class="grid-gerencia">


                <!-- INVENTARIO -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        📦
                    </div>

                    <h3>
                        Inventario
                    </h3>

                    <p>
                        Consulta información relacionada con el
                        inventario y los artículos registrados
                        en el sistema.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="index.php"
                            class="boton-gerencia"
                        >
                            Ver inventario
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


                <!-- REPORTES -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        📈
                    </div>

                    <h3>
                        Reportes
                    </h3>

                    <p>
                        Consulta de reportes e información
                        administrativa.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="#"
                            class="boton-gerencia"
                        >
                            Ver reportes
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


                <!-- PROCEDIMIENTOS -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        📋
                    </div>

                    <h3>
                        Procedimientos
                    </h3>

                    <p>
                        Consulta de procedimientos y
                        documentación operativa.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="#"
                            class="boton-gerencia"
                        >
                            Consultar
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


            </div>

        </section>


        <!-- ======================================
             2. DOCUMENTACIÓN Y RECURSOS
        ======================================= -->

        <section class="seccion-gerencia">


            <div class="titulo-seccion">

                <h2>
                    Documentación y recursos
                </h2>

                <div class="linea-seccion"></div>

            </div>


            <div class="grid-gerencia">


                <!-- GOOGLE DRIVE -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        📁
                    </div>

                    <h3>
                        Google Drive
                    </h3>

                    <p>
                        Acceso a carpetas y documentos
                        almacenados en Google Drive.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="https://drive.google.com/"
                            target="_blank"
                            rel="noopener noreferrer"
                            class="boton-gerencia"
                        >
                            Abrir Drive
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


                <!-- MANUALES -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        📄
                    </div>

                    <h3>
                        Manuales
                    </h3>

                    <p>
                        Consulta de manuales y documentos
                        de referencia de la empresa.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="#"
                            class="boton-gerencia"
                        >
                            Consultar
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


                <!-- FORMATOS -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        📝
                    </div>

                    <h3>
                        Formatos
                    </h3>

                    <p>
                        Acceso a formatos, plantillas y
                        documentos utilizados por la empresa.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="#"
                            class="boton-gerencia"
                        >
                            Ver formatos
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


            </div>

        </section>


        <!-- ======================================
             3. CAPACITACIÓN
        ======================================= -->

        <section class="seccion-gerencia">


            <div class="titulo-seccion">

                <h2>
                    Capacitación
                </h2>

                <div class="linea-seccion"></div>

            </div>


            <div class="grid-gerencia">


                <!-- CURSOS -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        🎓
                    </div>

                    <h3>
                        Cursos
                    </h3>

                    <p>
                        Acceso a cursos y programas de
                        capacitación disponibles.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="#"
                            class="boton-gerencia"
                        >
                            Ver cursos
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


                <!-- MATERIAL DE CAPACITACIÓN -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        📚
                    </div>

                    <h3>
                        Material de capacitación
                    </h3>

                    <p>
                        Material de apoyo, presentaciones,
                        videos y documentos de capacitación.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="#"
                            class="boton-gerencia"
                        >
                            Consultar material
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


                <!-- CERTIFICACIONES -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        🏆
                    </div>

                    <h3>
                        Certificaciones
                    </h3>

                    <p>
                        Consulta de certificaciones y
                        programas de acreditación.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="#"
                            class="boton-gerencia"
                        >
                            Consultar
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


            </div>

        </section>


        <!-- ======================================
             4. SISTEMAS Y ENLACES EXTERNOS
        ======================================= -->

        <section class="seccion-gerencia">


            <div class="titulo-seccion">

                <h2>
                    Sistemas y enlaces externos
                </h2>

                <div class="linea-seccion"></div>

            </div>


            <div class="grid-gerencia">


                <!-- SISTEMA INTERNO -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        💻
                    </div>

                    <h3>
                        Sistema interno
                    </h3>

                    <p>
                        Acceso a sistemas y aplicaciones
                        internas de la empresa.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="#"
                            class="boton-gerencia"
                        >
                            Abrir sistema
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


                <!-- SITIO EXTERNO -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        🌐
                    </div>

                    <h3>
                        Sitio externo
                    </h3>

                    <p>
                        Acceso a sitios web y recursos
                        externos relacionados con la empresa.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="https://www.google.com/"
                            target="_blank"
                            rel="noopener noreferrer"
                            class="boton-gerencia"
                        >
                            Abrir sitio
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


                <!-- OTROS RECURSOS -->

                <article class="tarjeta-gerencia">

                    <div class="icono-gerencia">
                        🔗
                    </div>

                    <h3>
                        Otros recursos
                    </h3>

                    <p>
                        Acceso a otros sistemas, herramientas
                        y recursos disponibles.
                    </p>

                    <div class="tarjeta-boton">

                        <a
                            href="#"
                            class="boton-gerencia"
                        >
                            Consultar
                            <span class="flecha-boton">→</span>
                        </a>

                    </div>

                </article>


            </div>

        </section>


        <!-- ======================================
             PIE DEL PORTAL
        ======================================= -->

        <div class="pie-portal">

            Portal de Gerencia · Recursos y accesos centralizados

        </div>


    </main>

</div>


<?php

include __DIR__ . '/footer.php';

?>
