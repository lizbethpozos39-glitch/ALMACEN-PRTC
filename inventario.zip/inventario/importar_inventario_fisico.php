php
<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

/*
|--------------------------------------------------------------------------
| CARGAR PHPSPREADSHEET
|--------------------------------------------------------------------------
*/

$autoloads = [
    __DIR__ . '/vendor/autoload.php',
    dirname(__DIR__) . '/vendor/autoload.php'
];

$autoloadEncontrado = false;

foreach ($autoloads as $autoload) {
    if (file_exists($autoload)) {
        require_once $autoload;
        $autoloadEncontrado = true;
        break;
    }
}

if (!$autoloadEncontrado) {
    die("No se encontró el autoload de Composer. Verifica que PhpSpreadsheet esté instalado.");
}

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;


/*
|--------------------------------------------------------------------------
| DATOS DEL USUARIO
|--------------------------------------------------------------------------
*/

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';
$rol_usuario     = strtoupper($_SESSION['rol'] ?? 'USUARIO');


/*
|--------------------------------------------------------------------------
| FUNCIONES AUXILIARES
|--------------------------------------------------------------------------
*/

function h($valor)
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}


/*
|--------------------------------------------------------------------------
| NORMALIZAR TEXTO
|--------------------------------------------------------------------------
*/

function normalizar_texto($valor)
{
    $valor = trim((string)$valor);

    $valor = mb_strtolower($valor, 'UTF-8');

    $buscar = [
        'á', 'é', 'í', 'ó', 'ú', 'ü', 'ñ'
    ];

    $reemplazar = [
        'a', 'e', 'i', 'o', 'u', 'u', 'n'
    ];

    $valor = str_replace($buscar, $reemplazar, $valor);

    $valor = preg_replace('/\s+/', ' ', $valor);

    return trim($valor);
}


/*
|--------------------------------------------------------------------------
| NORMALIZAR CÓDIGO
|--------------------------------------------------------------------------
*/

function normalizar_codigo($codigo)
{
    $codigo = trim((string)$codigo);

    $codigo = preg_replace('/\s+/', '', $codigo);

    return mb_strtoupper($codigo, 'UTF-8');
}


/*
|--------------------------------------------------------------------------
| CONVERTIR CANTIDAD
|--------------------------------------------------------------------------
*/

function convertir_cantidad($valor)
{
    if ($valor === null || $valor === '') {
        return null;
    }

    /*
     * Si PhpSpreadsheet ya devuelve un número,
     * simplemente lo convertimos.
     */
    if (is_numeric($valor)) {
        return (float)$valor;
    }

    $valor = trim((string)$valor);

    if ($valor === '') {
        return null;
    }

    /*
     * Eliminar espacios.
     */
    $valor = str_replace(' ', '', $valor);

    /*
     * Manejar formatos:
     *
     * 1,000.50
     * 1.000,50
     * 1000,50
     * 1000.50
     */

    if (strpos($valor, ',') !== false && strpos($valor, '.') !== false) {

        $ultimaComa  = strrpos($valor, ',');
        $ultimoPunto = strrpos($valor, '.');

        if ($ultimaComa > $ultimoPunto) {
            // Formato 1.000,50
            $valor = str_replace('.', '', $valor);
            $valor = str_replace(',', '.', $valor);
        } else {
            // Formato 1,000.50
            $valor = str_replace(',', '', $valor);
        }

    } elseif (strpos($valor, ',') !== false) {

        /*
         * Si solamente hay coma, asumimos que es decimal.
         */
        $valor = str_replace(',', '.', $valor);
    }

    if (!is_numeric($valor)) {
        return null;
    }

    return (float)$valor;
}


/*
|--------------------------------------------------------------------------
| OBTENER VALOR DE CELDA
|--------------------------------------------------------------------------
|
| Se utiliza getCell() porque algunas versiones de PhpSpreadsheet
| ya no disponen de getCellByColumnAndRow().
|
*/

function obtener_valor_celda($worksheet, $columna, $fila)
{
    $letra = Coordinate::stringFromColumnIndex((int)$columna);

    return $worksheet
        ->getCell($letra . $fila)
        ->getFormattedValue();
}


/*
|--------------------------------------------------------------------------
| OBTENER NOMBRE DE USUARIO
|--------------------------------------------------------------------------
*/

function obtener_nombre_usuario()
{
    return $_SESSION['nombre_empleado']
        ?? $_SESSION['usuario']
        ?? 'Usuario';
}


/*
|--------------------------------------------------------------------------
| OBTENER ID DE USUARIO
|--------------------------------------------------------------------------
*/

function obtener_usuario_id()
{
    if (isset($_SESSION['usuario_id'])) {
        return (int)$_SESSION['usuario_id'];
    }

    if (isset($_SESSION['id_usuario'])) {
        return (int)$_SESSION['id_usuario'];
    }

    if (isset($_SESSION['id'])) {
        return (int)$_SESSION['id'];
    }

    return null;
}


/*
|--------------------------------------------------------------------------
| VARIABLES
|--------------------------------------------------------------------------
*/

$error = '';
$mensaje = '';

$transaccionIniciada = false;


/*
|--------------------------------------------------------------------------
| PROCESAR ARCHIVO
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        /*
        |--------------------------------------------------------------------------
        | VALIDAR ARCHIVO
        |--------------------------------------------------------------------------
        */

        if (!isset($_FILES['archivo_excel'])) {
            throw new Exception('No se recibió ningún archivo.');
        }

        if ($_FILES['archivo_excel']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception(
                'Ocurrió un error al subir el archivo. Código: '
                . $_FILES['archivo_excel']['error']
            );
        }

        $nombreArchivo = $_FILES['archivo_excel']['name'];
        $rutaTemporal  = $_FILES['archivo_excel']['tmp_name'];

        $extension = strtolower(
            pathinfo($nombreArchivo, PATHINFO_EXTENSION)
        );

        if (!in_array($extension, ['xlsx', 'xls'], true)) {
            throw new Exception(
                'El archivo debe ser de Excel con extensión .xlsx o .xls.'
            );
        }

        if (!is_uploaded_file($rutaTemporal)) {
            throw new Exception(
                'No fue posible validar el archivo recibido.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | CARGAR EXCEL
        |--------------------------------------------------------------------------
        */

        $reader = IOFactory::createReaderForFile($rutaTemporal);

        $reader->setReadDataOnly(true);

        $spreadsheet = $reader->load($rutaTemporal);

        $worksheet = $spreadsheet->getActiveSheet();


        /*
        |--------------------------------------------------------------------------
        | OBTENER DIMENSIONES
        |--------------------------------------------------------------------------
        */

        $highestRow = $worksheet->getHighestRow();

        $highestColumn = $worksheet->getHighestColumn();

        $highestColumnIndex =
            Coordinate::columnIndexFromString($highestColumn);


        /*
        |--------------------------------------------------------------------------
        | BUSCAR ENCABEZADOS
        |--------------------------------------------------------------------------
        |
        | El archivo exportado tiene:
        |
        | ID
        | Código
        | Descripción
        | Cantidad
        | Ubicación
        | Máximo
        | Mínimo
        | Proveedor / Marca
        |
        | No dependemos de que estén exactamente en una fila
        | específica.
        |--------------------------------------------------------------------------
        */

        $filaEncabezados = null;

        $colID          = null;
        $colCodigo      = null;
        $colDescripcion = null;
        $colCantidad    = null;

        /*
         * Buscar hasta las primeras 50 filas.
         */
        $limiteFilasBusqueda = min(50, $highestRow);

        for ($fila = 1; $fila <= $limiteFilasBusqueda; $fila++) {

            $columnasEncontradas = [];

            for ($columna = 1; $columna <= $highestColumnIndex; $columna++) {

                $valor = obtener_valor_celda(
                    $worksheet,
                    $columna,
                    $fila
                );

                $normalizado = normalizar_texto($valor);

                if ($normalizado !== '') {
                    $columnasEncontradas[$normalizado] = $columna;
                }
            }

            /*
             * Buscar las columnas necesarias.
             */

            $idEncontrado = null;
            $codigoEncontrado = null;
            $descripcionEncontrada = null;
            $cantidadEncontrada = null;


            /*
             * ID
             */

            foreach (
                ['id'] as $nombrePosible
            ) {
                if (isset($columnasEncontradas[$nombrePosible])) {
                    $idEncontrado =
                        $columnasEncontradas[$nombrePosible];
                    break;
                }
            }


            /*
             * CÓDIGO
             */

            foreach (
                ['codigo', 'código', 'cod'] as $nombrePosible
            ) {

                $nombrePosible =
                    normalizar_texto($nombrePosible);

                if (isset($columnasEncontradas[$nombrePosible])) {

                    $codigoEncontrado =
                        $columnasEncontradas[$nombrePosible];

                    break;
                }
            }


            /*
             * DESCRIPCIÓN
             */

            foreach (
                [
                    'descripcion',
                    'descripción',
                    'articulo',
                    'articulo descripcion',
                    'articulo descripcion'
                ] as $nombrePosible
            ) {

                $nombrePosible =
                    normalizar_texto($nombrePosible);

                if (isset($columnasEncontradas[$nombrePosible])) {

                    $descripcionEncontrada =
                        $columnasEncontradas[$nombrePosible];

                    break;
                }
            }


            /*
             * CANTIDAD
             */

            foreach (
                [
                    'cantidad',
                    'cant',
                    'existencia',
                    'existencias'
                ] as $nombrePosible
            ) {

                $nombrePosible =
                    normalizar_texto($nombrePosible);

                if (isset($columnasEncontradas[$nombrePosible])) {

                    $cantidadEncontrada =
                        $columnasEncontradas[$nombrePosible];

                    break;
                }
            }


            /*
             * Tenemos suficiente para considerar encontrada
             * la fila de encabezados.
             *
             * ID no es indispensable para realizar la comparación,
             * porque el código es la referencia principal.
             */

            if (
                $codigoEncontrado !== null &&
                $descripcionEncontrada !== null &&
                $cantidadEncontrada !== null
            ) {

                $filaEncabezados = $fila;

                $colID          = $idEncontrado;
                $colCodigo      = $codigoEncontrado;
                $colDescripcion = $descripcionEncontrada;
                $colCantidad    = $cantidadEncontrada;

                break;
            }
        }


        /*
        |--------------------------------------------------------------------------
        | VALIDAR ENCABEZADOS
        |--------------------------------------------------------------------------
        */

        if ($filaEncabezados === null) {

            /*
             * Generar información útil para detectar cómo está leyendo
             * realmente el Excel.
             */

            $encabezadosDetectados = [];

            for (
                $columna = 1;
                $columna <= $highestColumnIndex;
                $columna++
            ) {

                $valor = obtener_valor_celda(
                    $worksheet,
                    $columna,
                    1
                );

                if (trim((string)$valor) !== '') {
                    $encabezadosDetectados[] =
                        trim((string)$valor);
                }
            }

            $detalle = '';

            if (!empty($encabezadosDetectados)) {

                $detalle =
                    ' Se detectó en la primera fila: '
                    . implode(' | ', $encabezadosDetectados)
                    . '.';
            }

            throw new Exception(
                'No se encontró la fila de encabezados del inventario.'
                . ' El archivo debe contener las columnas ID, Código, '
                . 'Descripción y Cantidad.'
                . $detalle
            );
        }


        /*
        |--------------------------------------------------------------------------
        | CARGAR INVENTARIO ACTUAL
        |--------------------------------------------------------------------------
        */

        $inventarioActual = [];

        $sqlInventario = "
            SELECT
                id,
                codigo,
                articulo_descripcion,
                cantidad,
                ubicacion,
                maximo,
                minimo,
                proveedor_marca
            FROM inventario
        ";

        $resultadoInventario = $conexion->query($sqlInventario);

        if (!$resultadoInventario) {
            throw new Exception(
                'No fue posible consultar el inventario actual: '
                . $conexion->error
            );
        }


        while ($filaInventario = $resultadoInventario->fetch_assoc()) {

            $codigoNormalizado =
                normalizar_codigo(
                    $filaInventario['codigo']
                );

            if ($codigoNormalizado === '') {
                continue;
            }

            $inventarioActual[$codigoNormalizado] =
                $filaInventario;
        }


        /*
        |--------------------------------------------------------------------------
        | LEER ARTÍCULOS DEL EXCEL
        |--------------------------------------------------------------------------
        */

        $articulosExcel = [];

        $codigosExcel = [];

        $filasConDatos = 0;


        for (
            $fila = $filaEncabezados + 1;
            $fila <= $highestRow;
            $fila++
        ) {

            $codigo = obtener_valor_celda(
                $worksheet,
                $colCodigo,
                $fila
            );

            $descripcion = obtener_valor_celda(
                $worksheet,
                $colDescripcion,
                $fila
            );

            $cantidadExcel = obtener_valor_celda(
                $worksheet,
                $colCantidad,
                $fila
            );


            /*
             * ID es opcional.
             */

            $idExcel = '';

            if ($colID !== null) {

                $idExcel = obtener_valor_celda(
                    $worksheet,
                    $colID,
                    $fila
                );
            }


            /*
             * Si toda la fila está vacía, ignorarla.
             */

            if (
                trim((string)$codigo) === '' &&
                trim((string)$descripcion) === '' &&
                trim((string)$cantidadExcel) === '' &&
                trim((string)$idExcel) === ''
            ) {
                continue;
            }

            $filasConDatos++;


            /*
             * Código obligatorio.
             */

            $codigoNormalizado =
                normalizar_codigo($codigo);

            if ($codigoNormalizado === '') {

                throw new Exception(
                    'La fila ' . $fila
                    . ' no contiene Código.'
                );
            }


            /*
             * Evitar códigos duplicados dentro del Excel.
             */

            if (isset($codigosExcel[$codigoNormalizado])) {

                throw new Exception(
                    'El código "' . $codigo
                    . '" aparece más de una vez en el archivo Excel.'
                    . ' Filas: '
                    . $codigosExcel[$codigoNormalizado]
                    . ' y '
                    . $fila
                    . '.'
                );
            }

            $codigosExcel[$codigoNormalizado] = $fila;


            /*
             * Cantidad física.
             */

            $cantidadFisica =
                convertir_cantidad($cantidadExcel);

            if ($cantidadFisica === null) {

                throw new Exception(
                    'La cantidad física del código "'
                    . $codigo
                    . '" en la fila '
                    . $fila
                    . ' no es válida.'
                );
            }


            if ($cantidadFisica < 0) {

                throw new Exception(
                    'La cantidad física del código "'
                    . $codigo
                    . '" en la fila '
                    . $fila
                    . ' no puede ser negativa.'
                );
            }


            /*
             * Buscar artículo en inventario.
             */

            $registroSistema =
                $inventarioActual[$codigoNormalizado]
                ?? null;


            if ($registroSistema !== null) {

                $inventarioId =
                    (int)$registroSistema['id'];

                $descripcionSistema =
                    $registroSistema['articulo_descripcion'];

                $cantidadSistema =
                    (float)$registroSistema['cantidad'];

                $descripcionFinal =
                    trim((string)$descripcion) !== ''
                    ? trim((string)$descripcion)
                    : $descripcionSistema;

                $diferencia =
                    $cantidadFisica - $cantidadSistema;


                if (abs($diferencia) < 0.00001) {

                    $estado = 'CORRECTO';

                } elseif ($diferencia < 0) {

                    $estado = 'FALTANTE';

                } else {

                    $estado = 'SOBRANTE';
                }

            } else {

                /*
                 * El artículo está en Excel pero no existe
                 * actualmente en el inventario.
                 */

                $inventarioId = null;

                $cantidadSistema = 0;

                $descripcionFinal =
                    trim((string)$descripcion);

                $diferencia =
                    $cantidadFisica;

                $estado =
                    'NO_ENCONTRADO';
            }


            $articulosExcel[] = [
                'inventario_id'      => $inventarioId,
                'codigo'             => $codigo,
                'descripcion'        => $descripcionFinal,
                'cantidad_sistema'   => $cantidadSistema,
                'cantidad_fisica'    => $cantidadFisica,
                'diferencia'         => $diferencia,
                'estado'             => $estado
            ];
        }


        /*
        |--------------------------------------------------------------------------
        | VALIDAR QUE HAYA ARTÍCULOS
        |--------------------------------------------------------------------------
        */

        if ($filasConDatos === 0) {

            throw new Exception(
                'El archivo contiene los encabezados, '
                . 'pero no se encontraron artículos para importar.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | AGREGAR ARTÍCULOS DEL SISTEMA QUE NO APARECEN EN EXCEL
        |--------------------------------------------------------------------------
        */

        foreach ($inventarioActual as $codigoNormalizado => $registroSistema) {

            if (isset($codigosExcel[$codigoNormalizado])) {
                continue;
            }


            $articulosExcel[] = [
                'inventario_id'      => (int)$registroSistema['id'],
                'codigo'             => $registroSistema['codigo'],
                'descripcion'        => $registroSistema['articulo_descripcion'],
                'cantidad_sistema'   => (float)$registroSistema['cantidad'],
                'cantidad_fisica'    => null,
                'diferencia'         => null,
                'estado'             => 'NO_REPORTADO'
            ];
        }


        /*
        |--------------------------------------------------------------------------
        | INICIAR TRANSACCIÓN
        |--------------------------------------------------------------------------
        */

        $conexion->begin_transaction();

        $transaccionIniciada = true;


        /*
        |--------------------------------------------------------------------------
        | CREAR CABECERA DE INVENTARIO FÍSICO
        |--------------------------------------------------------------------------
        */

        $usuarioId =
            obtener_usuario_id();

        $usuarioNombre =
            obtener_nombre_usuario();

        $totalArticulos =
            count($articulosExcel);

        $totalCorrectos = 0;
        $totalFaltantes = 0;
        $totalSobrantes = 0;
        $totalNoEncontrados = 0;


        foreach ($articulosExcel as $articulo) {

            switch ($articulo['estado']) {

                case 'CORRECTO':
                    $totalCorrectos++;
                    break;

                case 'FALTANTE':
                    $totalFaltantes++;
                    break;

                case 'SOBRANTE':
                    $totalSobrantes++;
                    break;

                case 'NO_ENCONTRADO':
                    $totalNoEncontrados++;
                    break;
            }
        }


        $sqlCabecera = "
            INSERT INTO inventarios_fisicos (
                fecha_revision,
                usuario_id,
                usuario_nombre,
                archivo_nombre,
                total_articulos,
                total_correctos,
                total_faltantes,
                total_sobrantes,
                total_no_encontrados,
                estado
            )
            VALUES (
                NOW(),
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                'EN_REVISION'
            )
        ";


        $stmtCabecera =
            $conexion->prepare($sqlCabecera);

        if (!$stmtCabecera) {

            throw new Exception(
                'No fue posible preparar la cabecera de la revisión: '
                . $conexion->error
            );
        }


        $stmtCabecera->bind_param(
            "issiiiii",
            $usuarioId,
            $usuarioNombre,
            $nombreArchivo,
            $totalArticulos,
            $totalCorrectos,
            $totalFaltantes,
            $totalSobrantes,
            $totalNoEncontrados
        );


        if (!$stmtCabecera->execute()) {

            throw new Exception(
                'No fue posible crear la revisión de inventario: '
                . $stmtCabecera->error
            );
        }


        $inventarioFisicoId =
            $conexion->insert_id;


        $stmtCabecera->close();


        /*
        |--------------------------------------------------------------------------
        | INSERTAR DETALLES
        |--------------------------------------------------------------------------
        */

        $sqlDetalle = "
            INSERT INTO inventario_fisico_detalle (
                inventario_fisico_id,
                inventario_id,
                codigo,
                articulo_descripcion,
                cantidad_sistema,
                cantidad_fisica,
                diferencia,
                estado,
                comentario,
                incluir_ajuste,
                ajuste_aplicado
            )
            VALUES (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                NULL,
                0,
                0
            )
        ";


        $stmtDetalle =
            $conexion->prepare($sqlDetalle);

        if (!$stmtDetalle) {

            throw new Exception(
                'No fue posible preparar el detalle del inventario: '
                . $conexion->error
            );
        }


        foreach ($articulosExcel as $articulo) {

            $inventarioId =
                $articulo['inventario_id'];

            $codigo =
                $articulo['codigo'];

            $descripcion =
                $articulo['descripcion'];

            $cantidadSistema =
                $articulo['cantidad_sistema'];

            $cantidadFisica =
                $articulo['cantidad_fisica'];

            $diferencia =
                $articulo['diferencia'];

            $estado =
                $articulo['estado'];


            /*
             * IMPORTANTE:
             *
             * Para NO_REPORTADO se conservan NULL en:
             *
             * cantidad_fisica
             * diferencia
             *
             * porque no significa que físicamente haya cero.
             */

            $stmtDetalle->bind_param(
                "iissddds",
                $inventarioFisicoId,
                $inventarioId,
                $codigo,
                $descripcion,
                $cantidadSistema,
                $cantidadFisica,
                $diferencia,
                $estado
            );


            if (!$stmtDetalle->execute()) {

                throw new Exception(
                    'No fue posible guardar el artículo "'
                    . $codigo
                    . '": '
                    . $stmtDetalle->error
                );
            }
        }


        $stmtDetalle->close();


        /*
        |--------------------------------------------------------------------------
        | ACTUALIZAR RESUMEN
        |--------------------------------------------------------------------------
        */

        $sqlResumen = "
            UPDATE inventarios_fisicos
            SET
                total_articulos = ?,
                total_correctos = ?,
                total_faltantes = ?,
                total_sobrantes = ?,
                total_no_encontrados = ?
            WHERE id = ?
        ";


        $stmtResumen =
            $conexion->prepare($sqlResumen);

        if (!$stmtResumen) {

            throw new Exception(
                'No fue posible preparar el resumen: '
                . $conexion->error
            );
        }


        $stmtResumen->bind_param(
            "iiiiii",
            $totalArticulos,
            $totalCorrectos,
            $totalFaltantes,
            $totalSobrantes,
            $totalNoEncontrados,
            $inventarioFisicoId
        );


        if (!$stmtResumen->execute()) {

            throw new Exception(
                'No fue posible actualizar el resumen: '
                . $stmtResumen->error
            );
        }


        $stmtResumen->close();


        /*
        |--------------------------------------------------------------------------
        | CONFIRMAR
        |--------------------------------------------------------------------------
        */

        $conexion->commit();

        $transaccionIniciada = false;


        /*
        |--------------------------------------------------------------------------
        | GUARDAR ID EN SESIÓN
        |--------------------------------------------------------------------------
        */

        $_SESSION['inventario_fisico_id'] =
            $inventarioFisicoId;


        /*
        |--------------------------------------------------------------------------
        | REDIRECCIÓN
        |--------------------------------------------------------------------------
        */

        header(
            'Location: inventario_fisico.php?revision='
            . $inventarioFisicoId
            . '&importado=1'
        );

        exit;


    } catch (Throwable $e) {

        /*
        |--------------------------------------------------------------------------
        | ROLLBACK
        |--------------------------------------------------------------------------
        */

        if ($transaccionIniciada) {

            try {
                $conexion->rollback();
            } catch (Throwable $rollbackError) {
                // No hacemos nada adicional.
            }
        }


        $error =
            $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Importar inventario físico</title>

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f8;
            color: #222;
        }

        .contenido {
            margin-left: 240px;
            padding: 25px;
        }

        .barra-superior {
            background: #ffffff;
            border-bottom: 1px solid #ddd;
            padding: 15px 20px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .barra-superior h1 {
            margin: 0;
            font-size: 24px;
        }

        .usuario {
            font-size: 14px;
            color: #555;
        }

        .contenedor {
            background: #ffffff;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .contenedor h2 {
            margin-top: 0;
            font-size: 21px;
        }

        .descripcion {
            color: #555;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .alerta {
            background: #fff3cd;
            border: 1px solid #ffe69c;
            color: #664d03;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            border: 1px solid #f1aeb5;
            color: #842029;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            white-space: pre-wrap;
        }

        .formulario {
            border: 1px solid #ddd;
            border-radius: 7px;
            padding: 20px;
            background: #fafafa;
        }

        .campo {
            margin-bottom: 18px;
        }

        .campo label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
        }

        .campo input[type="file"] {
            width: 100%;
            padding: 10px;
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .botones {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            border-radius: 5px;
            border: none;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
        }

        .btn-importar {
            background: #198754;
            color: white;
        }

        .btn-importar:hover {
            background: #157347;
        }

        .btn-regresar {
            background: #6c757d;
            color: white;
        }

        .btn-regresar:hover {
            background: #5c636a;
        }

        .formato {
            margin-top: 25px;
            padding: 18px;
            background: #f8f9fa;
            border-left: 4px solid #0d6efd;
            border-radius: 5px;
        }

        .formato h3 {
            margin-top: 0;
            font-size: 17px;
        }

        .columnas {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
        }

        .columna {
            background: #ffffff;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 7px 10px;
            font-size: 13px;
        }

    </style>

</head>

<body>


<?php
/*
|--------------------------------------------------------------------------
| MENÚ LATERAL
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/menu.php';
?>


<div class="contenido">

    <div class="barra-superior">

        <h1>
            Importar inventario físico
        </h1>

        <div class="usuario">
            Usuario:
            <strong>
                <?= h($nombre_empleado) ?>
            </strong>
        </div>

    </div>


    <div class="contenedor">

        <h2>
            Cargar archivo de inventario físico
        </h2>


        <p class="descripcion">

            Utiliza el mismo archivo de Excel que se obtiene
            mediante la opción <strong>Exportar Excel</strong>
            del inventario.

            Después de realizar el conteo físico, modifica la columna
            <strong>Cantidad</strong> con la cantidad realmente encontrada
            y vuelve a cargar el archivo aquí.

        </p>


        <?php if ($error !== ''): ?>

            <div class="error">

                <strong>
                    No fue posible importar el inventario físico.
                </strong>

                <br><br>

                <strong>Detalle:</strong>
                <?= h($error) ?>

            </div>

        <?php endif; ?>


        <div class="alerta">

            <strong>Importante:</strong>

            Esta importación solamente crea una
            <strong>revisión de inventario físico</strong>.

            <br>

            <strong>
                No modifica todavía las cantidades del inventario.
            </strong>

            Los ajustes deberán ser revisados y aplicados
            posteriormente.

        </div>


        <form
            method="POST"
            enctype="multipart/form-data"
            class="formulario"
        >

            <div class="campo">

                <label for="archivo_excel">
                    Seleccionar archivo Excel
                </label>

                <input
                    type="file"
                    name="archivo_excel"
                    id="archivo_excel"
                    accept=".xlsx,.xls"
                    required
                >

            </div>


            <div class="botones">

                <button
                    type="submit"
                    class="btn btn-importar"
                >
                    Importar inventario
                </button>


                <a
                    href="inventario_fisico.php"
                    class="btn btn-regresar"
                >
                    Regresar
                </a>

            </div>

        </form>


        <div class="formato">

            <h3>
                Formato esperado
            </h3>

            <p>
                El archivo debe ser el Excel generado desde
                el inventario del sistema.
            </p>

            <div class="columnas">

                <div class="columna">
                    ID
                </div>

                <div class="columna">
                    Código
                </div>

                <div class="columna">
                    Descripción
                </div>

                <div class="columna">
                    Cantidad
                </div>

                <div class="columna">
                    Ubicación
                </div>

                <div class="columna">
                    Máximo
                </div>

                <div class="columna">
                    Mínimo
                </div>

                <div class="columna">
                    Proveedor / Marca
                </div>

            </div>

        </div>

    </div>

</div>

</body>

</html>
Entendido. Entonces el importador **sí carga el Excel**, pero al modificar la columna **Cantidad**, la revisión sigue mostrando los valores originales o no refleja la diferencia.

Eso apunta a que debemos revisar `inventario_fisico.php`, específicamente cómo está mostrando `cantidad_fisica`, `diferencia` y `estado`. El importador ya está leyendo el archivo; ahora hay que verificar que la pantalla esté mostrando los datos importados correctamente.

**Pásame el `inventario_fisico.php` completo que tienes actualmente** y te lo regreso corregido, conservando exactamente el diseño que ya tienes.
