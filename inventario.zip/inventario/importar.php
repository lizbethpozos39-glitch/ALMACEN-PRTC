<?php

require "conexion.php";
require "vendor/autoload.php";

use PhpOffice\PhpSpreadsheet\IOFactory;

// ==========================================
// COMPROBAR ARCHIVO
// ==========================================

if (!isset($_FILES["archivo_excel"])) {
    die("❌ No se recibió ningún archivo.");
}

$archivo = $_FILES["archivo_excel"];

if ($archivo["error"] !== UPLOAD_ERR_OK) {
    die("❌ Error al subir el archivo.");
}

// ==========================================
// COMPROBAR EXTENSIÓN
// ==========================================

$extension = strtolower(
    pathinfo($archivo["name"], PATHINFO_EXTENSION)
);

if (!in_array($extension, ["xlsx", "xls"])) {
    die("❌ El archivo debe ser .xlsx o .xls");
}

try {

    // ==========================================
    // LEER EXCEL
    // ==========================================

    $documento = IOFactory::load(
        $archivo["tmp_name"]
    );

    $hoja = $documento->getActiveSheet();

    $filas = $hoja->toArray(
        null,
        true,
        true,
        true
    );

    $insertados = 0;
    $actualizados = 0;
    $errores = 0;

    // ==========================================
    // PREPARAR SQL
    // ==========================================

    $sql = "
        INSERT INTO inventario
        (
            codigo,
            articulo_descripcion,
            cantidad,
            ubicacion,
            maximo,
            minimo,
            proveedor_marca
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)

        ON DUPLICATE KEY UPDATE

            articulo_descripcion = VALUES(articulo_descripcion),
            cantidad = VALUES(cantidad),
            ubicacion = VALUES(ubicacion),
            maximo = VALUES(maximo),
            minimo = VALUES(minimo),
            proveedor_marca = VALUES(proveedor_marca)
    ";

    $stmt = $conexion->prepare($sql);

    // ==========================================
    // RECORRER EXCEL
    // ==========================================

    foreach ($filas as $numero => $fila) {

        // Saltar encabezado
        if ($numero == 1) {
            continue;
        }

        $codigo = trim(
            $fila["A"] ?? ""
        );

        $descripcion = trim(
            $fila["B"] ?? ""
        );

        $cantidad = intval(
            $fila["C"] ?? 0
        );

        $ubicacion = trim(
            $fila["D"] ?? ""
        );

        $maximo = intval(
            $fila["E"] ?? 0
        );

        $minimo = intval(
            $fila["F"] ?? 0
        );

        $proveedor = trim(
            $fila["G"] ?? ""
        );

        // Ignorar filas sin código
        if ($codigo === "") {
            continue;
        }

        // ==========================================
        // INSERTAR / ACTUALIZAR
        // ==========================================

        $stmt->bind_param(
            "ssisiis",
            $codigo,
            $descripcion,
            $cantidad,
            $ubicacion,
            $maximo,
            $minimo,
            $proveedor
        );

        if ($stmt->execute()) {

            if ($stmt->affected_rows == 1) {
                $insertados++;
            } else {
                $actualizados++;
            }

        } else {

            $errores++;

            echo "Error en código: "
                . htmlspecialchars($codigo)
                . "<br>";

        }
    }

    $stmt->close();

    // ==========================================
    // RESULTADO
    // ==========================================

    echo "
    <!DOCTYPE html>

    <html lang='es'>

    <head>

        <meta charset='UTF-8'>

        <title>Importación</title>

        <style>

            body {
                font-family: Arial;
                background: #f1f3f5;
                padding: 50px;
            }

            .resultado {
                max-width: 600px;
                margin: auto;
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 3px 15px rgba(0,0,0,.15);
                text-align: center;
            }

            .ok {
                color: green;
            }

            .error {
                color: red;
            }

            a {
                display: inline-block;
                margin-top: 20px;
                padding: 12px 20px;
                background: #007bff;
                color: white;
                text-decoration: none;
                border-radius: 5px;
            }

        </style>

    </head>

    <body>

        <div class='resultado'>

            <h1>✅ Importación terminada</h1>

            <p>
                <strong>Insertados:</strong>
                $insertados
            </p>

            <p>
                <strong>Actualizados:</strong>
                $actualizados
            </p>

            <p class='error'>
                <strong>Errores:</strong>
                $errores
            </p>

            <a href='index.php'>
                Volver al inventario
            </a>

        </div>

    </body>

    </html>
    ";

} catch (Exception $e) {

    echo "
    <h2>❌ Error al procesar Excel</h2>

    <p>
        " . htmlspecialchars($e->getMessage()) . "
    </p>
    ";

}

$conexion->close();

?>
