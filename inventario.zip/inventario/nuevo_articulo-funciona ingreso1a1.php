<?php

// ==========================================
// SEGURIDAD
// ==========================================

require_once __DIR__ . '/seguridad.php';

verificar_sesion();


// ==========================================
// CONEXIÓN
// ==========================================

require_once __DIR__ . '/conexion.php';


// ==========================================
// VARIABLES
// ==========================================

$mensaje = "";
$error = "";

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';


// ==========================================
// OBTENER ARTÍCULOS DEL INVENTARIO
// ==========================================

$articulos = [];

$sql_articulos = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        ubicacion,
        maximo,
        minimo,
        proveedor_marca
    FROM inventario
    ORDER BY articulo_descripcion ASC
";

$resultado_articulos = $conexion->query($sql_articulos);

if ($resultado_articulos) {

    while ($fila = $resultado_articulos->fetch_assoc()) {

        $articulos[] = $fila;

    }

}


// ==========================================
// OBTENER UBICACIONES ACTIVAS
// ==========================================

$ubicaciones = [];

$sql_ubicaciones = "
    SELECT
        id,
        codigo,
        descripcion,
        tipo
    FROM ubicaciones
    WHERE activo = 1
    ORDER BY
        tipo ASC,
        codigo ASC
";

$resultado_ubicaciones = $conexion->query($sql_ubicaciones);

if ($resultado_ubicaciones) {

    while ($fila = $resultado_ubicaciones->fetch_assoc()) {

        $ubicaciones[] = $fila;

    }

}


// ==========================================
// PROCESAR FORMULARIO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $accion = $_POST["accion"] ?? "";


    // ==================================================
    // ==================================================
    // INGRESO DE ARTÍCULO EXISTENTE
    // ==================================================
    // ==================================================

    if ($accion === "ingreso_existente") {

        $id_articulo = intval(
            $_POST["id_articulo"] ?? 0
        );

        $cantidad_reingreso = intval(
            $_POST["cantidad"] ?? 0
        );

        $ubicacion_nueva = trim(
            $_POST["ubicacion"] ?? ""
        );


        // ==========================================
        // VALIDACIONES
        // ==========================================

        if ($id_articulo <= 0) {

            $error = "Debes seleccionar un artículo.";

        } elseif ($cantidad_reingreso <= 0) {

            $error =
                "La cantidad a ingresar debe ser mayor a 0.";

        } else {


            // ==========================================
            // BUSCAR ARTÍCULO
            // ==========================================

            $buscar = $conexion->prepare("
                SELECT
                    id,
                    codigo,
                    articulo_descripcion,
                    cantidad,
                    ubicacion,
                    maximo,
                    minimo,
                    proveedor_marca
                FROM inventario
                WHERE id = ?
                LIMIT 1
            ");


            if (!$buscar) {

                $error =
                    "Error al preparar la consulta: "
                    . $conexion->error;

            } else {

                $buscar->bind_param(
                    "i",
                    $id_articulo
                );

                $buscar->execute();

                $resultado = $buscar->get_result();


                if ($resultado->num_rows === 0) {

                    $error =
                        "El artículo seleccionado no existe "
                        . "en el inventario.";

                } else {

                    $articulo = $resultado->fetch_assoc();


                    // ==================================
                    // CANTIDADES
                    // ==================================

                    $cantidad_actual =
                        intval($articulo["cantidad"]);

                    $nueva_cantidad =
                        $cantidad_actual
                        + $cantidad_reingreso;


                    // ==================================
                    // UBICACIÓN
                    // ==================================

                    /*
                     * Si el artículo ya tiene ubicación
                     * y no se seleccionó otra, se conserva.
                     *
                     * Si no tiene ubicación y se selecciona
                     * una nueva, se asigna.
                     */

                    $ubicacion_final =
                        $articulo["ubicacion"];


                    if ($ubicacion_nueva !== "") {

                        $ubicacion_final =
                            $ubicacion_nueva;

                    }


                    // ==================================
                    // INICIAR TRANSACCIÓN
                    // ==================================

                    $conexion->begin_transaction();


                    try {


                        // ==================================
                        // ACTUALIZAR INVENTARIO
                        // ==================================

                        $actualizar = $conexion->prepare("
                            UPDATE inventario
                            SET
                                cantidad = ?,
                                ubicacion = ?
                            WHERE id = ?
                        ");


                        if (!$actualizar) {

                            throw new Exception(
                                "Error al preparar la actualización: "
                                . $conexion->error
                            );

                        }


                        $actualizar->bind_param(
                            "isi",
                            $nueva_cantidad,
                            $ubicacion_final,
                            $id_articulo
                        );


                        if (!$actualizar->execute()) {

                            throw new Exception(
                                "Error al actualizar el inventario: "
                                . $actualizar->error
                            );

                        }


                        $actualizar->close();


                        // ==================================
                        // REGISTRAR MOVIMIENTO
                        // ==================================

                        $observaciones =
                            "Ingreso de artículo existente. "
                            . "Código: "
                            . $articulo["codigo"]
                            . ". "
                            . "Descripción: "
                            . $articulo["articulo_descripcion"]
                            . ". "
                            . "Ubicación: "
                            . ($ubicacion_final !== ""
                                ? $ubicacion_final
                                : "Sin ubicación");


                        $movimiento = $conexion->prepare("
                            INSERT INTO movimientos_inventario
                            (
                                inventario_id,
                                tipo,
                                cantidad,
                                cantidad_anterior,
                                cantidad_nueva,
                                factura_id,
                                observaciones
                            )
                            VALUES
                            (
                                ?,
                                'ENTRADA',
                                ?,
                                ?,
                                ?,
                                NULL,
                                ?
                            )
                        ");


                        if (!$movimiento) {

                            throw new Exception(
                                "Error al preparar el movimiento: "
                                . $conexion->error
                            );

                        }


                        $cantidad_movimiento =
                            (float)$cantidad_reingreso;

                        $cantidad_anterior_movimiento =
                            (float)$cantidad_actual;

                        $cantidad_nueva_movimiento =
                            (float)$nueva_cantidad;


                        $movimiento->bind_param(
                            "iddds",
                            $id_articulo,
                            $cantidad_movimiento,
                            $cantidad_anterior_movimiento,
                            $cantidad_nueva_movimiento,
                            $observaciones
                        );


                        if (!$movimiento->execute()) {

                            throw new Exception(
                                "Error al registrar el movimiento: "
                                . $movimiento->error
                            );

                        }


                        $movimiento->close();


                        // ==================================
                        // CONFIRMAR TRANSACCIÓN
                        // ==================================

                        $conexion->commit();


                        header(
                            "Location: index.php?"
                            . "mensaje=reingreso_realizado"
                        );

                        exit;


                    } catch (Exception $e) {


                        // ==================================
                        // CANCELAR TRANSACCIÓN
                        // ==================================

                        $conexion->rollback();


                        $error =
                            $e->getMessage();

                    }

                }


                $buscar->close();

            }

        }

    }


    // ==================================================
    // ==================================================
    // REGISTRAR ARTÍCULO NUEVO
    // ==================================================
    // ==================================================

    elseif ($accion === "nuevo_articulo") {


        $codigo = trim(
            $_POST["codigo_nuevo"] ?? ""
        );

        $descripcion_nueva = trim(
            $_POST["descripcion_nueva"] ?? ""
        );

        $cantidad_nueva = intval(
            $_POST["cantidad_nueva"] ?? 0
        );

        $ubicacion_nueva = trim(
            $_POST["ubicacion_nueva"] ?? ""
        );

        $maximo_nuevo = intval(
            $_POST["maximo_nuevo"] ?? 0
        );

        $minimo_nuevo = intval(
            $_POST["minimo_nuevo"] ?? 0
        );

        $proveedor_nuevo = trim(
            $_POST["proveedor_nuevo"] ?? ""
        );


        // ==========================================
        // VALIDACIONES
        // ==========================================

        if ($codigo === "") {

            $error =
                "Debes ingresar el código del artículo.";

        } elseif ($descripcion_nueva === "") {

            $error =
                "Debes ingresar la descripción del artículo.";

        } elseif ($cantidad_nueva < 0) {

            $error =
                "La cantidad inicial no puede ser negativa.";

        } elseif ($maximo_nuevo < 0) {

            $error =
                "El máximo no puede ser negativo.";

        } elseif ($minimo_nuevo < 0) {

            $error =
                "El mínimo no puede ser negativo.";

        } else {


            // ==========================================
            // VERIFICAR CÓDIGO EXISTENTE
            // ==========================================

            $verificar_codigo = $conexion->prepare("
                SELECT id
                FROM inventario
                WHERE codigo = ?
                LIMIT 1
            ");


            if (!$verificar_codigo) {

                $error =
                    "Error al verificar el código: "
                    . $conexion->error;

            } else {

                $verificar_codigo->bind_param(
                    "s",
                    $codigo
                );

                $verificar_codigo->execute();

                $resultado_codigo =
                    $verificar_codigo->get_result();


                if ($resultado_codigo->num_rows > 0) {

                    $error =
                        "El código "
                        . $codigo
                        . " ya existe en el inventario.";

                } else {


                    // ==================================
                    // INICIAR TRANSACCIÓN
                    // ==================================

                    $conexion->begin_transaction();


                    try {


                        // ==================================
                        // INSERTAR ARTÍCULO
                        // ==================================

                        $insertar = $conexion->prepare("
                            INSERT INTO inventario
                            (
                                codigo,
                                articulo_descripcion,
                                cantidad,
                                costo_unitario,
                                ubicacion,
                                maximo,
                                minimo,
                                proveedor_marca
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?,
                                0,
                                ?,
                                ?,
                                ?,
                                ?
                            )
                        ");


                        if (!$insertar) {

                            throw new Exception(
                                "Error al preparar el nuevo artículo: "
                                . $conexion->error
                            );

                        }


                        $insertar->bind_param(
                            "ssisiis",
                            $codigo,
                            $descripcion_nueva,
                            $cantidad_nueva,
                            $ubicacion_nueva,
                            $maximo_nuevo,
                            $minimo_nuevo,
                            $proveedor_nuevo
                        );


                        if (!$insertar->execute()) {

                            throw new Exception(
                                "Error al registrar el artículo: "
                                . $insertar->error
                            );

                        }


                        // ==================================
                        // ID DEL ARTÍCULO NUEVO
                        // ==================================

                        $id_nuevo =
                            $conexion->insert_id;


                        $insertar->close();


                        // ==================================
                        // REGISTRAR EN MOVIMIENTOS
                        // SOLAMENTE SI HAY CANTIDAD INICIAL
                        // ==================================

                        if ($cantidad_nueva > 0) {


                            $observaciones =
                                "Alta de artículo nuevo con "
                                . "cantidad inicial. "
                                . "Código: "
                                . $codigo
                                . ". "
                                . "Descripción: "
                                . $descripcion_nueva
                                . ". "
                                . "Ubicación: "
                                . ($ubicacion_nueva !== ""
                                    ? $ubicacion_nueva
                                    : "Sin ubicación");


                            $movimiento_nuevo =
                                $conexion->prepare("
                                    INSERT INTO movimientos_inventario
                                    (
                                        inventario_id,
                                        tipo,
                                        cantidad,
                                        cantidad_anterior,
                                        cantidad_nueva,
                                        factura_id,
                                        observaciones
                                    )
                                    VALUES
                                    (
                                        ?,
                                        'ENTRADA',
                                        ?,
                                        0,
                                        ?,
                                        NULL,
                                        ?
                                    )
                                ");


                            if (!$movimiento_nuevo) {

                                throw new Exception(
                                    "Error al preparar el movimiento "
                                    . "del nuevo artículo: "
                                    . $conexion->error
                                );

                            }


                            $cantidad_inicial_movimiento =
                                (float)$cantidad_nueva;

                            $cantidad_cero =
                                0.0;


                            $movimiento_nuevo->bind_param(
                                "idds",
                                $id_nuevo,
                                $cantidad_inicial_movimiento,
                                $cantidad_inicial_movimiento,
                                $observaciones
                            );


                            if (!$movimiento_nuevo->execute()) {

                                throw new Exception(
                                    "Error al registrar el movimiento "
                                    . "del nuevo artículo: "
                                    . $movimiento_nuevo->error
                                );

                            }


                            $movimiento_nuevo->close();

                        }


                        // ==================================
                        // CONFIRMAR TRANSACCIÓN
                        // ==================================

                        $conexion->commit();


                        header(
                            "Location: index.php?"
                            . "mensaje=articulo_creado"
                        );

                        exit;


                    } catch (Exception $e) {


                        // ==================================
                        // CANCELAR TRANSACCIÓN
                        // ==================================

                        $conexion->rollback();


                        $error =
                            $e->getMessage();

                    }

                }


                $verificar_codigo->close();

            }

        }

    }

    else {

        $error =
            "La operación seleccionada no es válida.";

    }

}

?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Ingreso de artículo</title>


    <style>

        /* ==========================================
           CONFIGURACIÓN GENERAL
        =========================================== */

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            padding: 0;

            font-family: Arial, sans-serif;

            background: #f4f6f8;

            color: #333;

        }


        /* ==========================================
           CONTENIDO PRINCIPAL
        =========================================== */

        .contenido-principal {

            margin-left: 240px;

            min-height: 100vh;

        }


        /* ==========================================
           BARRA SUPERIOR
        =========================================== */

        .barra-superior {

            height: 70px;

            background: #ffffff;

            border-bottom: 1px solid #ddd;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 30px;

            box-shadow:
                0 1px 5px rgba(0,0,0,.08);

        }


        .titulo-superior {

            font-size: 20px;

            font-weight: bold;

            color: #212529;

        }


        .usuario-superior {

            font-size: 13px;

            color: #555;

        }


        /* ==========================================
           CONTENEDOR
        =========================================== */

        .contenedor {

            max-width: 700px;

            margin: 40px auto;

            background: white;

            padding: 30px;

            border-radius: 12px;

            box-shadow:
                0 3px 15px rgba(0,0,0,.15);

        }


        h1 {

            margin-top: 0;

            color: #333;

        }


        .descripcion-ayuda {

            color: #666;

            font-size: 14px;

            margin-bottom: 25px;

            line-height: 1.5;

        }


        /* ==========================================
           SELECTOR DE OPERACIÓN
        =========================================== */

        .selector-operacion {

            display: flex;

            gap: 10px;

            margin-bottom: 25px;

            flex-wrap: wrap;

        }


        .opcion-operacion {

            flex: 1;

            min-width: 220px;

        }


        .opcion-operacion input {

            display: none;

        }


        .opcion-operacion label {

            display: block;

            padding: 14px;

            border: 1px solid #ccc;

            border-radius: 7px;

            background: #f8f9fa;

            cursor: pointer;

            text-align: center;

            margin: 0;

        }


        .opcion-operacion input:checked + label {

            border-color: #0d6efd;

            background: #e9f2ff;

            color: #0d6efd;

        }


        /* ==========================================
           FORMULARIO
        =========================================== */

        .formulario {

            display: grid;

            grid-template-columns: 1fr 1fr;

            gap: 15px;

        }


        .campo {

            display: flex;

            flex-direction: column;

        }


        .campo-completo {

            grid-column: 1 / -1;

        }


        label {

            font-weight: bold;

            margin-bottom: 6px;

        }


        input,
        select {

            padding: 11px;

            border: 1px solid #ccc;

            border-radius: 6px;

            font-size: 15px;

            font-family: Arial, sans-serif;

        }


        input:focus,
        select:focus {

            outline: none;

            border-color: #0d6efd;

            box-shadow:
                0 0 0 2px rgba(13,110,253,.10);

        }


        input[readonly] {

            background: #f1f3f5;

            color: #555;

        }


        /* ==========================================
           INFORMACIÓN DEL ARTÍCULO
        =========================================== */

        .informacion-articulo {

            margin-top: 20px;

            padding: 15px;

            background: #f8f9fa;

            border: 1px solid #ddd;

            border-radius: 8px;

        }


        .informacion-articulo h3 {

            margin-top: 0;

            margin-bottom: 15px;

            font-size: 16px;

            color: #212529;

        }


        /* ==========================================
           BOTONES
        =========================================== */

        .botones {

            margin-top: 25px;

            display: flex;

            gap: 10px;

            flex-wrap: wrap;

        }


        button,
        .cancelar {

            padding: 12px 20px;

            border: none;

            border-radius: 6px;

            text-decoration: none;

            cursor: pointer;

            font-size: 15px;

            font-family: Arial, sans-serif;

        }


        button {

            background: #198754;

            color: white;

        }


        button:hover {

            background: #157347;

        }


        .cancelar {

            background: #6c757d;

            color: white;

        }


        .cancelar:hover {

            background: #5a6268;

        }


        /* ==========================================
           ERROR
        =========================================== */

        .error {

            background: #f8d7da;

            color: #842029;

            padding: 12px;

            margin-bottom: 20px;

            border-radius: 6px;

        }


        /* ==========================================
           SECCIONES
        =========================================== */

        .seccion-operacion {

            display: none;

        }


        .seccion-operacion.activa {

            display: block;

        }


        /* ==========================================
           RESPONSIVE
        =========================================== */

        @media (max-width: 850px) {

            .contenido-principal {

                margin-left: 210px;

            }

        }


        @media (max-width: 650px) {

            .contenido-principal {

                margin-left: 0;

            }


            .barra-superior {

                height: auto;

                padding: 15px;

                flex-direction: column;

                align-items: flex-start;

                gap: 8px;

            }


            .contenedor {

                width: 92%;

                margin: 20px auto;

                padding: 20px;

            }


            .formulario {

                grid-template-columns: 1fr;

            }


            .campo-completo {

                grid-column: auto;

            }

        }

    </style>

</head>


<body>


<!-- ==========================================
     MENÚ LATERAL
========================================== -->

<?php include 'menu.php'; ?>


<!-- ==========================================
     CONTENIDO PRINCIPAL
========================================== -->

<main class="contenido-principal">


    <!-- ======================================
         BARRA SUPERIOR
    ======================================= -->

    <header class="barra-superior">

        <div class="titulo-superior">

            📥 Ingreso de artículo

        </div>


        <div class="usuario-superior">

            Usuario:

            <strong>

                <?= htmlspecialchars($nombre_empleado) ?>

            </strong>

        </div>

    </header>


    <!-- ======================================
         CONTENEDOR
    ======================================= -->

    <div class="contenedor">


        <h1>

            📥 Ingreso de artículo

        </h1>


        <p class="descripcion-ayuda">

            Puedes ingresar mercancía a un artículo existente
            o registrar un artículo nuevo en el inventario.

        </p>


        <!-- ==================================
             ERROR
        =================================== -->

        <?php if ($error !== ""): ?>

            <div class="error">

                ❌

                <?= htmlspecialchars($error) ?>

            </div>

        <?php endif; ?>


        <!-- ==================================
             SELECCIÓN DE OPERACIÓN
        =================================== -->

        <div class="selector-operacion">


            <div class="opcion-operacion">

                <input
                    type="radio"
                    name="tipo_operacion"
                    id="operacion_existente"
                    value="existente"
                    checked
                >

                <label for="operacion_existente">

                    📦 Ingresar artículo existente

                </label>

            </div>


            <div class="opcion-operacion">

                <input
                    type="radio"
                    name="tipo_operacion"
                    id="operacion_nuevo"
                    value="nuevo"
                >

                <label for="operacion_nuevo">

                    ➕ Registrar artículo nuevo

                </label>

            </div>


        </div>


        <!-- ==========================================
             ARTÍCULO EXISTENTE
        =========================================== -->

        <div
            id="seccion_existente"
            class="seccion-operacion activa"
        >


            <form method="POST">


                <input
                    type="hidden"
                    name="accion"
                    value="ingreso_existente"
                >


                <div class="formulario">


                    <!-- ==================================
                         SELECCIONAR ARTÍCULO
                    =================================== -->

                    <div class="campo campo-completo">

                        <label>

                            Artículo

                        </label>


                        <select
                            name="id_articulo"
                            id="id_articulo"
                            required
                        >

                            <option value="">

                                -- Selecciona un artículo --

                            </option>


                            <?php foreach ($articulos as $item): ?>

                                <option
                                    value="<?= $item['id'] ?>"
                                    data-descripcion="<?= htmlspecialchars(
                                        $item['articulo_descripcion'],
                                        ENT_QUOTES
                                    ) ?>"
                                    data-ubicacion="<?= htmlspecialchars(
                                        $item['ubicacion'],
                                        ENT_QUOTES
                                    ) ?>"
                                    data-maximo="<?= $item['maximo'] ?>"
                                    data-minimo="<?= $item['minimo'] ?>"
                                    data-proveedor="<?= htmlspecialchars(
                                        $item['proveedor_marca'],
                                        ENT_QUOTES
                                    ) ?>"
                                >

                                    <?= htmlspecialchars(
                                        $item['codigo']
                                    ) ?>

                                    -

                                    <?= htmlspecialchars(
                                        $item['articulo_descripcion']
                                    ) ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- ==================================
                         CANTIDAD
                    =================================== -->

                    <div class="campo campo-completo">

                        <label>

                            Cantidad a ingresar

                        </label>


                        <input
                            type="number"
                            name="cantidad"
                            min="1"
                            required
                            value="<?= htmlspecialchars(
                                $_POST["cantidad"] ?? "1"
                            ) ?>"
                        >

                    </div>


                    <!-- ==================================
                         UBICACIÓN
                    =================================== -->

                    <div class="campo campo-completo">

                        <label>

                            Ubicación

                        </label>


                        <select
                            name="ubicacion"
                            id="ubicacion_select"
                        >

                            <option value="">

                                -- Conservar ubicación actual --

                            </option>


                            <?php

                            $tipo_actual = "";

                            foreach ($ubicaciones as $ubicacion_item):

                                if (
                                    $tipo_actual !==
                                    $ubicacion_item["tipo"]
                                ):

                                    $tipo_actual =
                                        $ubicacion_item["tipo"];

                            ?>

                                    <optgroup
                                        label="<?= htmlspecialchars(
                                            $tipo_actual
                                        ) ?>"
                                    >

                            <?php endif; ?>


                                <option
                                    value="<?= htmlspecialchars(
                                        $ubicacion_item["codigo"],
                                        ENT_QUOTES
                                    ) ?>"
                                >

                                    <?= htmlspecialchars(
                                        $ubicacion_item["codigo"]
                                    ) ?>

                                    <?php if (
                                        !empty(
                                            $ubicacion_item["descripcion"]
                                        )
                                    ): ?>

                                        -
                                        <?= htmlspecialchars(
                                            $ubicacion_item["descripcion"]
                                        ) ?>

                                    <?php endif; ?>

                                </option>


                            <?php

                                $siguiente_tipo = "";

                            endforeach;

                            ?>


                        </select>

                    </div>


                    <!-- ==================================
                         INFORMACIÓN
                    =================================== -->

                    <div
                        class="informacion-articulo campo-completo"
                    >

                        <h3>

                            Información del artículo

                        </h3>


                        <div class="formulario">


                            <!-- DESCRIPCIÓN -->

                            <div
                                class="campo campo-completo"
                            >

                                <label>

                                    Artículo / Descripción

                                </label>


                                <input
                                    type="text"
                                    id="articulo_descripcion"
                                    readonly
                                    placeholder="Se llenará automáticamente"
                                >

                            </div>


                            <!-- UBICACIÓN ACTUAL -->

                            <div class="campo">

                                <label>

                                    Ubicación actual

                                </label>


                                <input
                                    type="text"
                                    id="ubicacion_actual"
                                    readonly
                                >

                            </div>


                            <!-- MÁXIMO -->

                            <div class="campo">

                                <label>

                                    Máximo

                                </label>


                                <input
                                    type="number"
                                    id="maximo"
                                    readonly
                                >

                            </div>


                            <!-- MÍNIMO -->

                            <div class="campo">

                                <label>

                                    Mínimo

                                </label>


                                <input
                                    type="number"
                                    id="minimo"
                                    readonly
                                >

                            </div>


                            <!-- PROVEEDOR -->

                            <div
                                class="campo campo-completo"
                            >

                                <label>

                                    Proveedor / Marca

                                </label>


                                <input
                                    type="text"
                                    id="proveedor_marca"
                                    readonly
                                >

                            </div>


                        </div>

                    </div>


                </div>


                <!-- ==================================
                     BOTONES
                =================================== -->

                <div class="botones">

                    <button type="submit">

                        💾 Registrar ingreso

                    </button>


                    <a
                        href="index.php"
                        class="cancelar"
                    >

                        ↩️ Volver al inventario

                    </a>

                </div>


            </form>


        </div>


        <!-- ==========================================
             ARTÍCULO NUEVO
        =========================================== -->

        <div
            id="seccion_nuevo"
            class="seccion-operacion"
        >


            <form method="POST">


                <input
                    type="hidden"
                    name="accion"
                    value="nuevo_articulo"
                >


                <div class="formulario">


                    <!-- CÓDIGO -->

                    <div class="campo">

                        <label>

                            Código

                        </label>


                        <input
                            type="text"
                            name="codigo_nuevo"
                            maxlength="100"
                            required
                            value="<?= htmlspecialchars(
                                $_POST["codigo_nuevo"] ?? ""
                            ) ?>"
                        >

                    </div>


                    <!-- CANTIDAD -->

                    <div class="campo">

                        <label>

                            Cantidad inicial

                        </label>


                        <input
                            type="number"
                            name="cantidad_nueva"
                            min="0"
                            required
                            value="<?= htmlspecialchars(
                                $_POST["cantidad_nueva"] ?? "0"
                            ) ?>"
                        >

                    </div>


                    <!-- DESCRIPCIÓN -->

                    <div class="campo campo-completo">

                        <label>

                            Artículo / Descripción

                        </label>


                        <input
                            type="text"
                            name="descripcion_nueva"
                            maxlength="255"
                            required
                            value="<?= htmlspecialchars(
                                $_POST["descripcion_nueva"] ?? ""
                            ) ?>"
                        >

                    </div>


                    <!-- UBICACIÓN -->

                    <div class="campo campo-completo">

                        <label>

                            Ubicación

                        </label>


                        <select
                            name="ubicacion_nueva"
                        >

                            <option value="">

                                -- Sin ubicación --

                            </option>


                            <?php

                            $tipo_actual_nuevo = "";

                            foreach (
                                $ubicaciones
                                as $ubicacion_item
                            ):

                                if (
                                    $tipo_actual_nuevo !==
                                    $ubicacion_item["tipo"]
                                ):

                                    if (
                                        $tipo_actual_nuevo !== ""
                                    ):

                            ?>

                                    </optgroup>

                            <?php

                                    endif;

                                    $tipo_actual_nuevo =
                                        $ubicacion_item["tipo"];

                            ?>

                                    <optgroup
                                        label="<?= htmlspecialchars(
                                            $tipo_actual_nuevo
                                        ) ?>"
                                    >

                            <?php

                                endif;

                            ?>

                                <option
                                    value="<?= htmlspecialchars(
                                        $ubicacion_item["codigo"],
                                        ENT_QUOTES
                                    ) ?>"
                                    <?= (
                                        ($_POST[
                                            "ubicacion_nueva"
                                        ] ?? "") ===
                                        $ubicacion_item["codigo"]
                                    )
                                        ? "selected"
                                        : ""
                                    ?>
                                >

                                    <?= htmlspecialchars(
                                        $ubicacion_item["codigo"]
                                    ) ?>

                                    <?php if (
                                        !empty(
                                            $ubicacion_item[
                                                "descripcion"
                                            ]
                                        )
                                    ): ?>

                                        -
                                        <?= htmlspecialchars(
                                            $ubicacion_item[
                                                "descripcion"
                                            ]
                                        ) ?>

                                    <?php endif; ?>

                                </option>


                            <?php endforeach; ?>


                            <?php if (
                                $tipo_actual_nuevo !== ""
                            ): ?>

                                </optgroup>

                            <?php endif; ?>


                        </select>

                    </div>


                    <!-- MÁXIMO -->

                    <div class="campo">

                        <label>

                            Máximo

                        </label>


                        <input
                            type="number"
                            name="maximo_nuevo"
                            min="0"
                            value="<?= htmlspecialchars(
                                $_POST["maximo_nuevo"] ?? "0"
                            ) ?>"
                        >

                    </div>


                    <!-- MÍNIMO -->

                    <div class="campo">

                        <label>

                            Mínimo

                        </label>


                        <input
                            type="number"
                            name="minimo_nuevo"
                            min="0"
                            value="<?= htmlspecialchars(
                                $_POST["minimo_nuevo"] ?? "0"
                            ) ?>"
                        >

                    </div>


                    <!-- PROVEEDOR -->

                    <div class="campo campo-completo">

                        <label>

                            Proveedor / Marca

                        </label>


                        <input
                            type="text"
                            name="proveedor_nuevo"
                            maxlength="255"
                            value="<?= htmlspecialchars(
                                $_POST["proveedor_nuevo"] ?? ""
                            ) ?>"
                        >

                    </div>


                </div>


                <!-- ==================================
                     BOTONES
                =================================== -->

                <div class="botones">

                    <button type="submit">

                        💾 Registrar artículo nuevo

                    </button>


                    <a
                        href="index.php"
                        class="cancelar"
                    >

                        ↩️ Volver al inventario

                    </a>

                </div>


            </form>


        </div>


    </div>


</main>


<!-- ==========================================
     JAVASCRIPT
========================================== -->

<script>

const operacionExistente =
    document.getElementById(
        "operacion_existente"
    );

const operacionNuevo =
    document.getElementById(
        "operacion_nuevo"
    );

const seccionExistente =
    document.getElementById(
        "seccion_existente"
    );

const seccionNuevo =
    document.getElementById(
        "seccion_nuevo"
    );


// ==========================================
// CAMBIAR OPERACIÓN
// ==========================================

operacionExistente.addEventListener(
    "change",
    function () {

        if (this.checked) {

            seccionExistente.classList.add(
                "activa"
            );

            seccionNuevo.classList.remove(
                "activa"
            );

        }

    }
);


operacionNuevo.addEventListener(
    "change",
    function () {

        if (this.checked) {

            seccionNuevo.classList.add(
                "activa"
            );

            seccionExistente.classList.remove(
                "activa"
            );

        }

    }
);


// ==========================================
// INFORMACIÓN DEL ARTÍCULO EXISTENTE
// ==========================================

const selector =
    document.getElementById(
        "id_articulo"
    );

const descripcion =
    document.getElementById(
        "articulo_descripcion"
    );

const ubicacionActual =
    document.getElementById(
        "ubicacion_actual"
    );

const ubicacionSelect =
    document.getElementById(
        "ubicacion_select"
    );

const maximo =
    document.getElementById(
        "maximo"
    );

const minimo =
    document.getElementById(
        "minimo"
    );

const proveedor =
    document.getElementById(
        "proveedor_marca"
    );


selector.addEventListener(
    "change",
    function () {


        const opcion =
            this.options[
                this.selectedIndex
            ];


        if (!this.value) {

            descripcion.value = "";

            ubicacionActual.value = "";

            maximo.value = "";

            minimo.value = "";

            proveedor.value = "";

            ubicacionSelect.value = "";

            return;

        }


        descripcion.value =
            opcion.dataset.descripcion || "";


        ubicacionActual.value =
            opcion.dataset.ubicacion || "";


        maximo.value =
            opcion.dataset.maximo || "0";


        minimo.value =
            opcion.dataset.minimo || "0";


        proveedor.value =
            opcion.dataset.proveedor || "";


        /*
         * Si el artículo ya tiene ubicación,
         * dejamos la opción de conservarla.
         *
         * Si no tiene ubicación, el usuario
         * puede seleccionar una nueva.
         */

        if (
            opcion.dataset.ubicacion &&
            opcion.dataset.ubicacion !== ""
        ) {

            ubicacionSelect.value = "";

        }

    }
);

</script>


</body>

</html>