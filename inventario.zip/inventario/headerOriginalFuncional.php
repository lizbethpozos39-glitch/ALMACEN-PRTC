<?php
// header.php
?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            color: #333;
        }

        .barra-superior {

            background: #212529;

            color: white;

            padding: 15px 30px;

            display: flex;

            justify-content: space-between;

            align-items: center;

            flex-wrap: wrap;

            gap: 10px;

        }

        .titulo-sistema {

            font-size: 20px;

            font-weight: bold;

        }

        .menu {

            display: flex;

            gap: 8px;

            flex-wrap: wrap;

        }

        .menu a {

            color: white;

            text-decoration: none;

            padding: 8px 12px;

            border-radius: 5px;

            font-size: 14px;

            background: #343a40;

        }

        .menu a:hover {

            background: #495057;

        }

        .pagina {

            width: 95%;

            max-width: 1400px;

            margin: 30px auto;

        }

    </style>

</head>

<body>

<header class="barra-superior">

    <div class="titulo-sistema">

        📦 Sistema de Almacén

    </div>

    <nav class="menu">

        <a href="index.php">
            📋 Inventario
        </a>

        <a href="nuevo_articulo.php">
            ➕ Nuevo artículo
        </a>

        <a href="entrada_almacen.php">
            📥 Entrada
        </a>

        <a href="importar.php">
            📊 Excel
        </a>

        <a href="entrada_almacen.php">
            📥 Entrada
        </a>


    </nav>

</header>

<div class="pagina">