<?php
/**
 * ============================================================
 * PANEL PRINCIPAL - SISTEMA DE INVENTARIO
 * Archivo: panel.php
 * Base de datos: inventario_db
 * ============================================================
 */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

require_once 'conexion.php';

/* ============================================================
   FUNCIONES AUXILIARES
   ============================================================ */

function obtenerValor($conexion, $sql, $campo, $default = 0)
{
    $resultado = $conexion->query($sql);

    if (!$resultado) {
        return $default;
    }

    $fila = $resultado->fetch_assoc();

    return isset($fila[$campo]) ? $fila[$campo] : $default;
}

function escapar($valor)
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

function formatoNumero($valor, $decimales = 3)
{
    return number_format((float)$valor, $decimales, '.', ',');
}

function formatoMoneda($valor)
{
    return '$' . number_format((float)$valor, 2, '.', ',');
}


/* ============================================================
   1. INDICADORES PRINCIPALES
   ============================================================ */

/* Total de artículos */
$totalArticulos = obtenerValor(
    $conexion,
    "SELECT COUNT(*) AS total FROM inventario",
    "total"
);


/* Existencia total */
$existenciaTotal = obtenerValor(
    $conexion,
    "SELECT COALESCE(SUM(cantidad), 0) AS total FROM inventario",
    "total"
);


/* Artículos con existencia baja */
$articulosBajos = obtenerValor(
    $conexion,
    "SELECT COUNT(*) AS total
     FROM inventario
     WHERE cantidad > 0
     AND cantidad <= minimo",
    "total"
);


/* Artículos agotados */
$articulosAgotados = obtenerValor(
    $conexion,
    "SELECT COUNT(*) AS total
     FROM inventario
     WHERE cantidad <= 0",
    "total"
);


/* Entradas del día */
$entradasHoy = obtenerValor(
    $conexion,
    "SELECT COALESCE(SUM(cantidad), 0) AS total
     FROM movimientos_inventario
     WHERE tipo = 'ENTRADA'
     AND DATE(fecha_movimiento) = CURDATE()",
    "total"
);


/* Salidas del día */
$salidasHoy = obtenerValor(
    $conexion,
    "SELECT COALESCE(SUM(cantidad), 0) AS total
     FROM movimientos_inventario
     WHERE tipo = 'SALIDA'
     AND DATE(fecha_movimiento) = CURDATE()",
    "total"
);


/* Total de facturas */
$totalFacturas = obtenerValor(
    $conexion,
    "SELECT COUNT(*) AS total FROM facturas",
    "total"
);


/* Importe total de facturas */
$totalFacturado = obtenerValor(
    $conexion,
    "SELECT COALESCE(SUM(total), 0) AS total
     FROM facturas",
    "total"
);


/* ============================================================
   2. ÚLTIMOS MOVIMIENTOS
   ============================================================ */

$ultimosMovimientos = $conexion->query("
    SELECT
        m.id,
        m.tipo,
        m.cantidad,
        m.cantidad_anterior,
        m.cantidad_nueva,
        m.fecha_movimiento,
        m.observaciones,

        i.codigo,
        i.articulo_descripcion,

        f.numero_factura

    FROM movimientos_inventario m

    INNER JOIN inventario i
        ON i.id = m.inventario_id

    LEFT JOIN facturas f
        ON f.id = m.factura_id

    ORDER BY m.fecha_movimiento DESC

    LIMIT 10
");


/* ============================================================
   3. ARTÍCULOS CON EXISTENCIA BAJA
   ============================================================ */

$inventarioBajo = $conexion->query("
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        minimo,
        maximo,
        ubicacion,
        proveedor_marca

    FROM inventario

    WHERE cantidad <= minimo

    ORDER BY cantidad ASC, articulo_descripcion ASC

    LIMIT 10
");


/* ============================================================
   4. ÚLTIMAS FACTURAS
   ============================================================ */

$ultimasFacturas = $conexion->query("
    SELECT
        id,
        numero_factura,
        nombre_emisor,
        fecha_factura,
        subtotal,
        iva,
        total,
        moneda,
        fecha_registro

    FROM facturas

    ORDER BY fecha_registro DESC

    LIMIT 10
");


/* ============================================================
   5. CANTIDAD DE MOVIMIENTOS DEL DÍA
   ============================================================ */

$movimientosHoy = obtenerValor(
    $conexion,
    "SELECT COUNT(*) AS total
     FROM movimientos_inventario
     WHERE DATE(fecha_movimiento) = CURDATE()",
    "total"
);


/* ============================================================
   6. FECHA ACTUAL
   ============================================================ */

$fechaActual = date('d/m/Y');

?>
<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Panel - Inventario</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #1f2937;
        }

        .contenedor {
            width: 95%;
            max-width: 1500px;
            margin: 0 auto;
            padding: 25px 0 40px;
        }

        /* ====================================================
           ENCABEZADO
           ==================================================== */

        .encabezado {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            background: white;
            padding: 22px 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }

        .titulo h1 {
            margin: 0 0 6px;
            font-size: 28px;
            color: #1f2937;
        }

        .titulo p {
            margin: 0;
            color: #6b7280;
        }

        .fecha {
            text-align: right;
            color: #6b7280;
            font-size: 14px;
        }


        /* ====================================================
           TARJETAS
           ==================================================== */

        .tarjetas {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .tarjeta {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            border-left: 5px solid #2563eb;
        }

        .tarjeta.verde {
            border-left-color: #16a34a;
        }

        .tarjeta.amarilla {
            border-left-color: #f59e0b;
        }

        .tarjeta.roja {
            border-left-color: #dc2626;
        }

        .tarjeta.morada {
            border-left-color: #7c3aed;
        }

        .tarjeta.cian {
            border-left-color: #0891b2;
        }

        .tarjeta-grupo {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .tarjeta-titulo {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 10px;
        }

        .tarjeta-valor {
            font-size: 29px;
            font-weight: bold;
            color: #111827;
        }

        .tarjeta-icono {
            font-size: 32px;
        }


        /* ====================================================
           RESUMEN OPERATIVO
           ==================================================== */

        .resumen {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .resumen-item {
            background: white;
            padding: 18px 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }

        .resumen-item h3 {
            margin: 0 0 8px;
            font-size: 14px;
            color: #6b7280;
        }

        .resumen-item strong {
            font-size: 22px;
        }


        /* ====================================================
           GRID PRINCIPAL
           ==================================================== */

        .grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }

        .panel {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            overflow: hidden;
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 18px 20px;
            border-bottom: 1px solid #e5e7eb;
        }

        .panel-header h2 {
            margin: 0;
            font-size: 18px;
        }

        .panel-body {
            padding: 0;
        }


        /* ====================================================
           TABLAS
           ==================================================== */

        .tabla-contenedor {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #f9fafb;
            color: #6b7280;
            font-size: 12px;
            text-transform: uppercase;
            padding: 12px;
            text-align: left;
            white-space: nowrap;
        }

        td {
            padding: 12px;
            border-top: 1px solid #f0f0f0;
            font-size: 13px;
        }

        tr:hover td {
            background: #fafafa;
        }


        /* ====================================================
           ESTADOS
           ==================================================== */

        .estado {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
        }

        .entrada {
            background: #dcfce7;
            color: #166534;
        }

        .salida {
            background: #fee2e2;
            color: #991b1b;
        }

        .ajuste {
            background: #fef3c7;
            color: #92400e;
        }

        .agotado {
            background: #fee2e2;
            color: #991b1b;
        }

        .bajo {
            background: #fef3c7;
            color: #92400e;
        }

        .normal {
            background: #dcfce7;
            color: #166534;
        }


        /* ====================================================
           BOTONES
           ==================================================== */

        .boton {
            display: inline-block;
            padding: 8px 12px;
            background: #2563eb;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 12px;
        }

        .boton:hover {
            background: #1d4ed8;
        }

        .boton-secundario {
            background: #6b7280;
        }

        .boton-secundario:hover {
            background: #4b5563;
        }


        /* ====================================================
           SIN DATOS
           ==================================================== */

        .sin-datos {
            padding: 30px;
            text-align: center;
            color: #9ca3af;
        }


        /* ====================================================
           RESPONSIVE
           ==================================================== */

        @media (max-width: 1100px) {

            .tarjetas {
                grid-template-columns: repeat(2, 1fr);
            }

            .grid {
                grid-template-columns: 1fr;
            }

        }

        @media (max-width: 700px) {

            .contenedor {
                width: 92%;
            }

            .encabezado {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .fecha {
                text-align: left;
            }

            .tarjetas {
                grid-template-columns: 1fr;
            }

            .resumen {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>


<body>


<div class="contenedor">


    <!-- =====================================================
         ENCABEZADO
         ===================================================== -->

    <div class="encabezado">

        <div class="titulo">

            <h1>Panel de Inventario</h1>

            <p>
                Resumen general del almacén
            </p>

        </div>

        <div class="fecha">

            <strong>Fecha</strong><br>

            <?php echo escapar($fechaActual); ?>

        </div>

    </div>


    <!-- =====================================================
         TARJETAS PRINCIPALES
         ===================================================== -->

    <div class="tarjetas">


        <!-- ARTÍCULOS -->

        <div class="tarjeta">

            <div class="tarjeta-grupo">

                <div>

                    <div class="tarjeta-titulo">
                        Artículos registrados
                    </div>

                    <div class="tarjeta-valor">
                        <?php echo formatoNumero($totalArticulos, 0); ?>
                    </div>

                </div>

                <div class="tarjeta-icono">
                    📦
                </div>

            </div>

        </div>


        <!-- EXISTENCIA -->

        <div class="tarjeta verde">

            <div class="tarjeta-grupo">

                <div>

                    <div class="tarjeta-titulo">
                        Existencia total
                    </div>

                    <div class="tarjeta-valor">
                        <?php echo formatoNumero($existenciaTotal); ?>
                    </div>

                </div>

                <div class="tarjeta-icono">
                    📊
                </div>

            </div>

        </div>


        <!-- STOCK BAJO -->

        <div class="tarjeta amarilla">

            <div class="tarjeta-grupo">

                <div>

                    <div class="tarjeta-titulo">
                        Stock bajo
                    </div>

                    <div class="tarjeta-valor">
                        <?php echo formatoNumero($articulosBajos, 0); ?>
                    </div>

                </div>

                <div class="tarjeta-icono">
                    ⚠️
                </div>

            </div>

        </div>


        <!-- AGOTADOS -->

        <div class="tarjeta roja">

            <div class="tarjeta-grupo">

                <div>

                    <div class="tarjeta-titulo">
                        Agotados
                    </div>

                    <div class="tarjeta-valor">
                        <?php echo formatoNumero($articulosAgotados, 0); ?>
                    </div>

                </div>

                <div class="tarjeta-icono">
                    ❌
                </div>

            </div>

        </div>


        <!-- ENTRADAS -->

        <div class="tarjeta verde">

            <div class="tarjeta-grupo">

                <div>

                    <div class="tarjeta-titulo">
                        Entradas hoy
                    </div>

                    <div class="tarjeta-valor">
                        <?php echo formatoNumero($entradasHoy); ?>
                    </div>

                </div>

                <div class="tarjeta-icono">
                    📥
                </div>

            </div>

        </div>


        <!-- SALIDAS -->

        <div class="tarjeta roja">

            <div class="tarjeta-grupo">

                <div>

                    <div class="tarjeta-titulo">
                        Salidas hoy
                    </div>

                    <div class="tarjeta-valor">
                        <?php echo formatoNumero($salidasHoy); ?>
                    </div>

                </div>

                <div class="tarjeta-icono">
                    📤
                </div>

            </div>

        </div>


        <!-- FACTURAS -->

        <div class="tarjeta morada">

            <div class="tarjeta-grupo">

                <div>

                    <div class="tarjeta-titulo">
                        Facturas registradas
                    </div>

                    <div class="tarjeta-valor">
                        <?php echo formatoNumero($totalFacturas, 0); ?>
                    </div>

                </div>

                <div class="tarjeta-icono">
                    🧾
                </div>

            </div>

        </div>


        <!-- TOTAL FACTURADO -->

        <div class="tarjeta cian">

            <div class="tarjeta-grupo">

                <div>

                    <div class="tarjeta-titulo">
                        Total facturado
                    </div>

                    <div class="tarjeta-valor">
                        <?php echo formatoMoneda($totalFacturado); ?>
                    </div>

                </div>

                <div class="tarjeta-icono">
                    💰
                </div>

            </div>

        </div>


    </div>


    <!-- =====================================================
         RESUMEN DEL DÍA
         ===================================================== -->

    <div class="resumen">

        <div class="resumen-item">

            <h3>Movimientos realizados hoy</h3>

            <strong>
                <?php echo formatoNumero($movimientosHoy, 0); ?>
            </strong>

        </div>


        <div class="resumen-item">

            <h3>Entradas de mercancía</h3>

            <strong>
                <?php echo formatoNumero($entradasHoy); ?>
            </strong>

        </div>


        <div class="resumen-item">

            <h3>Salidas de mercancía</h3>

            <strong>
                <?php echo formatoNumero($salidasHoy); ?>
            </strong>

        </div>

    </div>


    <!-- =====================================================
         MOVIMIENTOS + STOCK BAJO
         ===================================================== -->

    <div class="grid">


        <!-- =================================================
             ÚLTIMOS MOVIMIENTOS
             ================================================= -->

        <div class="panel">

            <div class="panel-header">

                <h2>Últimos movimientos</h2>

                <a href="historial_movimientos.php" class="boton">
                    Ver historial
                </a>

            </div>


            <div class="panel-body tabla-contenedor">

                <?php if ($ultimosMovimientos && $ultimosMovimientos->num_rows > 0): ?>

                    <table>

                        <thead>

                            <tr>

                                <th>Fecha</th>

                                <th>Artículo</th>

                                <th>Tipo</th>

                                <th>Cantidad</th>

                                <th>Anterior</th>

                                <th>Nueva</th>

                                <th>Factura</th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php while ($movimiento = $ultimosMovimientos->fetch_assoc()): ?>

                            <tr>

                                <td>
                                    <?php
                                    echo escapar(
                                        date(
                                            'd/m/Y H:i',
                                            strtotime($movimiento['fecha_movimiento'])
                                        )
                                    );
                                    ?>
                                </td>


                                <td>

                                    <strong>
                                        <?php echo escapar($movimiento['codigo']); ?>
                                    </strong>

                                    <br>

                                    <?php echo escapar($movimiento['articulo_descripcion']); ?>

                                </td>


                                <td>

                                    <?php

                                    $tipo = $movimiento['tipo'];

                                    if ($tipo === 'ENTRADA') {

                                        echo '<span class="estado entrada">ENTRADA</span>';

                                    } elseif ($tipo === 'SALIDA') {

                                        echo '<span class="estado salida">SALIDA</span>';

                                    } else {

                                        echo '<span class="estado ajuste">AJUSTE</span>';

                                    }

                                    ?>

                                </td>


                                <td>
                                    <?php echo formatoNumero($movimiento['cantidad']); ?>
                                </td>


                                <td>
                                    <?php echo formatoNumero($movimiento['cantidad_anterior']); ?>
                                </td>


                                <td>
                                    <?php echo formatoNumero($movimiento['cantidad_nueva']); ?>
                                </td>


                                <td>

                                    <?php

                                    if (!empty($movimiento['numero_factura'])) {

                                        echo escapar(
                                            $movimiento['numero_factura']
                                        );

                                    } else {

                                        echo '<span style="color:#9ca3af;">Sin factura</span>';

                                    }

                                    ?>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                        </tbody>

                    </table>

                <?php else: ?>

                    <div class="sin-datos">
                        No existen movimientos registrados.
                    </div>

                <?php endif; ?>

            </div>

        </div>


        <!-- =================================================
             STOCK BAJO
             ================================================= -->

        <div class="panel">

            <div class="panel-header">

                <h2>Alertas de inventario</h2>

                <a href="index.php" class="boton">
                    Inventario
                </a>

            </div>


            <div class="panel-body tabla-contenedor">

                <?php if ($inventarioBajo && $inventarioBajo->num_rows > 0): ?>

                    <table>

                        <thead>

                            <tr>

                                <th>Artículo</th>

                                <th>Existencia</th>

                                <th>Mínimo</th>

                                <th>Estado</th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php while ($articulo = $inventarioBajo->fetch_assoc()): ?>

                            <tr>

                                <td>

                                    <strong>
                                        <?php echo escapar($articulo['codigo']); ?>
                                    </strong>

                                    <br>

                                    <?php echo escapar($articulo['articulo_descripcion']); ?>

                                </td>


                                <td>
                                    <?php echo formatoNumero($articulo['cantidad']); ?>
                                </td>


                                <td>
                                    <?php echo formatoNumero($articulo['minimo']); ?>
                                </td>


                                <td>

                                    <?php

                                    if ((float)$articulo['cantidad'] <= 0) {

                                        echo '<span class="estado agotado">
                                                AGOTADO
                                              </span>';

                                    } else {

                                        echo '<span class="estado bajo">
                                                STOCK BAJO
                                              </span>';

                                    }

                                    ?>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                        </tbody>

                    </table>

                <?php else: ?>

                    <div class="sin-datos">

                        ✅ No hay artículos debajo del mínimo.

                    </div>

                <?php endif; ?>

            </div>

        </div>


    </div>


    <!-- =====================================================
         ÚLTIMAS FACTURAS
         ===================================================== -->

    <div class="panel">

        <div class="panel-header">

            <h2>Últimas facturas</h2>

            <a href="facturas.php" class="boton">
                Ver facturas
            </a>

        </div>


        <div class="panel-body tabla-contenedor">

            <?php if ($ultimasFacturas && $ultimasFacturas->num_rows > 0): ?>

                <table>

                    <thead>

                        <tr>

                            <th>Factura</th>

                            <th>Proveedor / Emisor</th>

                            <th>Fecha</th>

                            <th>Subtotal</th>

                            <th>IVA</th>

                            <th>Total</th>

                            <th>Moneda</th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php while ($factura = $ultimasFacturas->fetch_assoc()): ?>

                        <tr>

                            <td>

                                <strong>
                                    <?php
                                    echo escapar(
                                        $factura['numero_factura']
                                    );
                                    ?>
                                </strong>

                            </td>


                            <td>
                                <?php
                                echo escapar(
                                    $factura['nombre_emisor']
                                );
                                ?>
                            </td>


                            <td>

                                <?php

                                if (!empty($factura['fecha_factura'])) {

                                    echo escapar(
                                        date(
                                            'd/m/Y',
                                            strtotime(
                                                $factura['fecha_factura']
                                            )
                                        )
                                    );

                                } else {

                                    echo '-';

                                }

                                ?>

                            </td>


                            <td>
                                <?php
                                echo formatoMoneda(
                                    $factura['subtotal']
                                );
                                ?>
                            </td>


                            <td>
                                <?php
                                echo formatoMoneda(
                                    $factura['iva']
                                );
                                ?>
                            </td>


                            <td>

                                <strong>
                                    <?php
                                    echo formatoMoneda(
                                        $factura['total']
                                    );
                                    ?>
                                </strong>

                            </td>


                            <td>
                                <?php
                                echo escapar(
                                    $factura['moneda']
                                );
                                ?>
                            </td>

                        </tr>

                    <?php endwhile; ?>

                    </tbody>

                </table>

            <?php else: ?>

                <div class="sin-datos">

                    No existen facturas registradas.

                </div>

            <?php endif; ?>

        </div>

    </div>


</div>


</body>

</html>
