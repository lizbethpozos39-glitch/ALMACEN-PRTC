<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';

$mensaje = "";
$error = "";


/*
|--------------------------------------------------------------------------
| OBTENER ARTÍCULOS DEL INVENTARIO
|--------------------------------------------------------------------------
*/

$articulos = [];

$sqlArticulos = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad
    FROM inventario
    ORDER BY articulo_descripcion ASC
";

$resultadoArticulos = $conexion->query($sqlArticulos);

if ($resultadoArticulos) {

    while ($fila = $resultadoArticulos->fetch_assoc()) {
        $articulos[] = $fila;
    }

} else {

    $error = "Error cargando los artículos del inventario: " . $conexion->error;

}


/*
|--------------------------------------------------------------------------
| PROCESAR FORMULARIO
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $folio = trim($_POST["folio"] ?? "");
    $nombre_emisor = trim($_POST["nombre_emisor"] ?? "");
    $rfc_emisor = trim($_POST["rfc_emisor"] ?? "");
    $fecha_factura = $_POST["fecha_factura"] ?? date("Y-m-d");

    $tasa_iva = isset($_POST["tasa_iva"])
        ? (float)$_POST["tasa_iva"]
        : 0;

    $observaciones = trim($_POST["observaciones"] ?? "");

    $inventario_ids = $_POST["inventario_id"] ?? [];
    $cantidades = $_POST["cantidad"] ?? [];
    $costos_unitarios = $_POST["costo_unitario"] ?? [];


    /*
    |--------------------------------------------------------------------------
    | VALIDACIONES GENERALES
    |--------------------------------------------------------------------------
    */

    if ($folio === "") {

        $error = "Debes ingresar el folio de la factura.";

    }

    elseif ($nombre_emisor === "") {

        $error = "Debes ingresar el nombre del emisor.";

    }

    elseif ($rfc_emisor === "") {

        $error = "Debes ingresar el RFC del emisor.";

    }

    elseif ($fecha_factura === "") {

        $error = "Debes ingresar la fecha de la factura.";

    }

    elseif ($tasa_iva < 0 || $tasa_iva > 100) {

        $error = "El IVA debe estar entre 0% y 100%.";

    }

    elseif (empty($inventario_ids)) {

        $error = "Debes agregar por lo menos un artículo.";

    }


    /*
    |--------------------------------------------------------------------------
    | PROCESAR ARTÍCULOS
    |--------------------------------------------------------------------------
    */

    if ($error === "") {

        $lineas = [];

        $subtotal = 0;


        for ($i = 0; $i < count($inventario_ids); $i++) {

            $inventario_id = (int)$inventario_ids[$i];

            $cantidad = isset($cantidades[$i])
                ? (float)$cantidades[$i]
                : 0;

            $costo_unitario = isset($costos_unitarios[$i])
                ? (float)$costos_unitarios[$i]
                : 0;


            /*
            |--------------------------------------------------------------------------
            | IGNORAR FILAS VACÍAS
            |--------------------------------------------------------------------------
            */

            if ($inventario_id <= 0) {
                continue;
            }


            if ($cantidad <= 0) {

                $error = "La cantidad debe ser mayor a cero.";

                break;
            }


            if ($costo_unitario < 0) {

                $error = "El costo unitario no puede ser negativo.";

                break;
            }


            $importe = $cantidad * $costo_unitario;

            $subtotal += $importe;


            $lineas[] = [

                "inventario_id" => $inventario_id,

                "cantidad" => $cantidad,

                "costo_unitario" => $costo_unitario,

                "importe" => $importe

            ];
        }


        if ($error === "" && empty($lineas)) {

            $error = "Debes agregar por lo menos un artículo.";

        }


        /*
        |--------------------------------------------------------------------------
        | CALCULAR IVA Y TOTAL
        |--------------------------------------------------------------------------
        */

        if ($error === "") {

            $iva = $subtotal * ($tasa_iva / 100);

            $total = $subtotal + $iva;


            /*
            |--------------------------------------------------------------------------
            | INICIAR TRANSACCIÓN
            |--------------------------------------------------------------------------
            */

            $conexion->begin_transaction();


            try {


                /*
                |--------------------------------------------------------------------------
                | INSERTAR FACTURA
                |--------------------------------------------------------------------------
                */

                $sqlFactura = "
                    INSERT INTO facturas
                    (
                        rfc_emisor,
                        nombre_emisor,
                        numero_factura,
                        fecha_factura,
                        subtotal,
                        tasa_iva,
                        iva,
                        total,
                        moneda
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        'MXN'
                    )
                ";


                $stmtFactura = $conexion->prepare($sqlFactura);


                if (!$stmtFactura) {

                    throw new Exception(
                        "Error preparando factura: " .
                        $conexion->error
                    );

                }


                $stmtFactura->bind_param(
                    "ssssdddd",
                    $rfc_emisor,
                    $nombre_emisor,
                    $folio,
                    $fecha_factura,
                    $subtotal,
                    $tasa_iva,
                    $iva,
                    $total
                );


                if (!$stmtFactura->execute()) {

                    throw new Exception(
                        "Error registrando la factura: " .
                        $stmtFactura->error
                    );

                }


                $factura_id = $conexion->insert_id;


                $stmtFactura->close();


                /*
                |--------------------------------------------------------------------------
                | CONSULTAR Y BLOQUEAR ARTÍCULO
                |--------------------------------------------------------------------------
                */

                $sqlArticulo = "
                    SELECT
                        id,
                        codigo,
                        articulo_descripcion,
                        cantidad
                    FROM inventario
                    WHERE id = ?
                    FOR UPDATE
                ";


                $stmtArticulo =
                    $conexion->prepare($sqlArticulo);


                if (!$stmtArticulo) {

                    throw new Exception(
                        "Error preparando consulta de inventario: " .
                        $conexion->error
                    );

                }


                /*
                |--------------------------------------------------------------------------
                | INSERTAR DETALLE DE FACTURA
                |
                | IMPORTANTE:
                | La tabla factura_detalles utiliza:
                |
                | clave_producto
                | valor_unitario
                | moneda
                |
                | NO utiliza:
                |
                | codigo
                | costo_unitario
                |--------------------------------------------------------------------------
                */

                $sqlDetalle = "
                    INSERT INTO factura_detalles
                    (
                        factura_id,
                        inventario_id,
                        clave_producto,
                        descripcion,
                        unidad,
                        cantidad,
                        valor_unitario,
                        moneda,
                        importe
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        ?,
                        ?,
                        'PZA',
                        ?,
                        ?,
                        'MXN',
                        ?
                    )
                ";


                $stmtDetalle =
                    $conexion->prepare($sqlDetalle);


                if (!$stmtDetalle) {

                    throw new Exception(
                        "Error preparando detalle de factura: " .
                        $conexion->error
                    );

                }


                /*
                |--------------------------------------------------------------------------
                | ACTUALIZAR INVENTARIO
                |--------------------------------------------------------------------------
                */

                $sqlActualizarInventario = "
                    UPDATE inventario
                    SET cantidad = cantidad + ?
                    WHERE id = ?
                ";


                $stmtActualizarInventario =
                    $conexion->prepare(
                        $sqlActualizarInventario
                    );


                if (!$stmtActualizarInventario) {

                    throw new Exception(
                        "Error preparando actualización de inventario: " .
                        $conexion->error
                    );

                }


                /*
                |--------------------------------------------------------------------------
                | REGISTRAR MOVIMIENTO
                |--------------------------------------------------------------------------
                */

                $sqlMovimiento = "
                    INSERT INTO movimientos_inventario
                    (
                        inventario_id,
                        tipo,
                        cantidad,
                        cantidad_anterior,
                        cantidad_nueva,
                        factura_id,
                        observaciones
                    )
                    VALUES
                    (
                        ?,
                        'ENTRADA',
                        ?,
                        ?,
                        ?,
                        ?,
                        ?
                    )
                ";


                $stmtMovimiento =
                    $conexion->prepare($sqlMovimiento);


                if (!$stmtMovimiento) {

                    throw new Exception(
                        "Error preparando movimiento: " .
                        $conexion->error
                    );

                }


                /*
                |--------------------------------------------------------------------------
                | PROCESAR CADA ARTÍCULO
                |--------------------------------------------------------------------------
                */

                foreach ($lineas as $linea) {

                    $inventario_id =
                        $linea["inventario_id"];

                    $cantidad =
                        $linea["cantidad"];

                    $costo_unitario =
                        $linea["costo_unitario"];

                    $importe =
                        $linea["importe"];


                    /*
                    |--------------------------------------------------------------------------
                    | OBTENER ARTÍCULO Y BLOQUEAR REGISTRO
                    |--------------------------------------------------------------------------
                    */

                    $stmtArticulo->bind_param(
                        "i",
                        $inventario_id
                    );


                    if (!$stmtArticulo->execute()) {

                        throw new Exception(
                            "Error consultando artículo."
                        );

                    }


                    $resultadoArticulo =
                        $stmtArticulo->get_result();


                    $articulo =
                        $resultadoArticulo->fetch_assoc();


                    if (!$articulo) {

                        throw new Exception(
                            "El artículo seleccionado no existe."
                        );

                    }


                    $codigo =
                        $articulo["codigo"];


                    $descripcion =
                        $articulo["articulo_descripcion"];


                    $cantidad_anterior =
                        (float)$articulo["cantidad"];


                    $cantidad_nueva =
                        $cantidad_anterior + $cantidad;


                    /*
                    |--------------------------------------------------------------------------
                    | INSERTAR DETALLE DE FACTURA
                    |--------------------------------------------------------------------------
                    */

                    $stmtDetalle->bind_param(
                        "iissddd",
                        $factura_id,
                        $inventario_id,
                        $codigo,
                        $descripcion,
                        $cantidad,
                        $costo_unitario,
                        $importe
                    );


                    if (!$stmtDetalle->execute()) {

                        throw new Exception(
                            "Error registrando detalle del artículo " .
                            $descripcion .
                            ": " .
                            $stmtDetalle->error
                        );

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | ACTUALIZAR EXISTENCIA
                    |--------------------------------------------------------------------------
                    */

                    $stmtActualizarInventario->bind_param(
                        "di",
                        $cantidad,
                        $inventario_id
                    );


                    if (!$stmtActualizarInventario->execute()) {

                        throw new Exception(
                            "Error actualizando inventario del artículo " .
                            $descripcion
                        );

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | REGISTRAR MOVIMIENTO
                    |--------------------------------------------------------------------------
                    */

                    $observacionMovimiento =
                        "Entrada por factura " . $folio;


                    if ($observaciones !== "") {

                        $observacionMovimiento .=
                            " - " . $observaciones;

                    }


                    $stmtMovimiento->bind_param(
                        "idddis",
                        $inventario_id,
                        $cantidad,
                        $cantidad_anterior,
                        $cantidad_nueva,
                        $factura_id,
                        $observacionMovimiento
                    );


                    if (!$stmtMovimiento->execute()) {

                        throw new Exception(
                            "Error registrando movimiento del artículo " .
                            $descripcion
                        );

                    }

                }


                /*
                |--------------------------------------------------------------------------
                | CERRAR CONSULTAS
                |--------------------------------------------------------------------------
                */

                $stmtArticulo->close();

                $stmtDetalle->close();

                $stmtActualizarInventario->close();

                $stmtMovimiento->close();


                /*
                |--------------------------------------------------------------------------
                | CONFIRMAR TRANSACCIÓN
                |--------------------------------------------------------------------------
                */

                $conexion->commit();


                $mensaje =
                    "Factura registrada correctamente. " .
                    "Folio: " .
                    htmlspecialchars($folio) .
                    " | Total: $" .
                    number_format($total, 2);


                /*
                |--------------------------------------------------------------------------
                | LIMPIAR FORMULARIO
                |--------------------------------------------------------------------------
                */

                $_POST = [];

            }

            catch (Exception $e) {

                if ($conexion->errno === 0) {
                    // No hacer nada
                }

                $conexion->rollback();

                $error = $e->getMessage();

            }

        }

    }

}

?>


<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Entrada de almacén</title>


    <style>

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            font-family: Arial, sans-serif;

            background: #f4f6f8;

            color: #212529;

        }


        /*
        |--------------------------------------------------------------------------
        | CONTENIDO PRINCIPAL
        |--------------------------------------------------------------------------
        */

        .contenido-principal {

            margin-left: 240px;

            min-height: 100vh;

        }


        /*
        |--------------------------------------------------------------------------
        | BARRA SUPERIOR
        |--------------------------------------------------------------------------
        */

        .barra-superior {

            height: 65px;

            background: #ffffff;

            border-bottom: 1px solid #ddd;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 25px;

            box-shadow:
                0 1px 4px rgba(0,0,0,0.08);

        }


        .titulo-superior {

            font-size: 21px;

            font-weight: bold;

        }


        .usuario-superior {

            font-size: 14px;

            color: #555;

        }


        /*
        |--------------------------------------------------------------------------
        | CONTENEDOR
        |--------------------------------------------------------------------------
        */

        .contenedor {

            padding: 25px;

            max-width: 1400px;

            margin: auto;

        }


        /*
        |--------------------------------------------------------------------------
        | FORMULARIO
        |--------------------------------------------------------------------------
        */

        .formulario {

            background: #ffffff;

            padding: 25px;

            border-radius: 10px;

            box-shadow:
                0 2px 8px rgba(0,0,0,0.08);

        }


        .titulo {

            margin-top: 0;

            margin-bottom: 25px;

            color: #212529;

        }


        .grid {

            display: grid;

            grid-template-columns:
                repeat(auto-fit, minmax(220px, 1fr));

            gap: 18px;

        }


        .campo {

            display: flex;

            flex-direction: column;

        }


        .campo label {

            font-weight: bold;

            margin-bottom: 6px;

        }


        .campo input,
        .campo select,
        .campo textarea {

            padding: 10px;

            border: 1px solid #ced4da;

            border-radius: 5px;

            font-size: 14px;

            font-family: Arial, sans-serif;

        }


        .campo input:focus,
        .campo select:focus,
        .campo textarea:focus {

            outline: none;

            border-color: #80bdff;

        }


        .campo small {

            color: #6c757d;

            margin-top: 5px;

        }


        /*
        |--------------------------------------------------------------------------
        | ARTÍCULOS
        |--------------------------------------------------------------------------
        */

        .seccion-articulos {

            margin-top: 30px;

        }


        .tabla-contenedor {

            overflow-x: auto;

        }


        .tabla {

            width: 100%;

            border-collapse: collapse;

            margin-top: 15px;

        }


        .tabla th {

            background: #212529;

            color: white;

            padding: 10px;

            text-align: left;

        }


        .tabla td {

            padding: 8px;

            border-bottom: 1px solid #ddd;

        }


        .tabla input,
        .tabla select {

            width: 100%;

            padding: 8px;

            border: 1px solid #ced4da;

            border-radius: 4px;

            font-family: Arial, sans-serif;

        }


        /*
        |--------------------------------------------------------------------------
        | BOTONES
        |--------------------------------------------------------------------------
        */

        .boton {

            border: none;

            border-radius: 5px;

            padding: 10px 16px;

            cursor: pointer;

            font-size: 14px;

        }


        .boton-agregar {

            background: #198754;

            color: white;

            margin-top: 15px;

        }


        .boton-agregar:hover {

            background: #157347;

        }


        .boton-eliminar {

            background: #dc3545;

            color: white;

            padding: 7px 10px;

        }


        .boton-eliminar:hover {

            background: #bb2d3b;

        }


        .resumen {

            max-width: 450px;

            margin-left: auto;

            margin-top: 25px;

            background: #f8f9fa;

            padding: 20px;

            border-radius: 8px;

        }


        .resumen-fila {

            display: flex;

            justify-content: space-between;

            padding: 8px 0;

            border-bottom: 1px solid #ddd;

        }


        .resumen-total {

            font-size: 20px;

            font-weight: bold;

            border-bottom: none;

        }


        .botones {

            display: flex;

            justify-content: flex-end;

            gap: 10px;

            margin-top: 25px;

        }


        .boton-cancelar {

            background: #6c757d;

            color: white;

        }


        .boton-registrar {

            background: #0d6efd;

            color: white;

        }


        .boton-registrar:hover {

            background: #0b5ed7;

        }


        /*
        |--------------------------------------------------------------------------
        | ALERTAS
        |--------------------------------------------------------------------------
        */

        .alerta {

            padding: 15px;

            border-radius: 6px;

            margin-bottom: 20px;

        }


        .alerta-exito {

            background: #d1e7dd;

            color: #0f5132;

        }


        .alerta-error {

            background: #f8d7da;

            color: #842029;

        }


        .texto-ayuda {

            color: #6c757d;

            font-size: 13px;

        }


        /*
        |--------------------------------------------------------------------------
        | RESPONSIVE
        |--------------------------------------------------------------------------
        */

        @media (max-width: 850px) {

            .contenido-principal {

                margin-left: 0;

            }

        }


        @media (max-width: 600px) {

            .barra-superior {

                padding: 0 15px;

            }


            .titulo-superior {

                font-size: 17px;

            }


            .usuario-superior {

                display: none;

            }


            .contenedor {

                padding: 15px;

            }

        }

    </style>

</head>


<body>


<?php include 'menu.php'; ?>


<main class="contenido-principal">


    <!-- ==========================================================
         BARRA SUPERIOR
    =========================================================== -->

    <header class="barra-superior">

        <div class="titulo-superior">

            📥 Entrada de almacén

        </div>


        <div class="usuario-superior">

            Usuario:

            <strong>
                <?= htmlspecialchars($nombre_empleado) ?>
            </strong>

        </div>

    </header>


    <div class="contenedor">


        <div class="formulario">


            <h1 class="titulo">

                📥 Entrada de mercancía

            </h1>


            <?php if ($mensaje !== ""): ?>

                <div class="alerta alerta-exito">

                    <?= $mensaje ?>

                </div>

            <?php endif; ?>


            <?php if ($error !== ""): ?>

                <div class="alerta alerta-error">

                    <?= htmlspecialchars($error) ?>

                </div>

            <?php endif; ?>


            <form
                method="POST"
                id="formEntrada"
            >


                <!-- ==================================================
                     DATOS DE FACTURA
                =================================================== -->

                <h2>

                    Datos de la factura

                </h2>


                <div class="grid">


                    <div class="campo">

                        <label for="folio">

                            Folio / Número de factura

                        </label>


                        <input
                            type="text"
                            name="folio"
                            id="folio"
                            value="<?= htmlspecialchars(
                                $_POST["folio"] ?? ""
                            ) ?>"
                            required
                        >

                    </div>


                    <div class="campo">

                        <label for="fecha_factura">

                            Fecha de factura

                        </label>


                        <input
                            type="date"
                            name="fecha_factura"
                            id="fecha_factura"
                            value="<?= htmlspecialchars(
                                $_POST["fecha_factura"]
                                ?? date("Y-m-d")
                            ) ?>"
                            required
                        >

                    </div>


                    <div class="campo">

                        <label for="nombre_emisor">

                            Nombre del emisor / proveedor

                        </label>


                        <input
                            type="text"
                            name="nombre_emisor"
                            id="nombre_emisor"
                            value="<?= htmlspecialchars(
                                $_POST["nombre_emisor"] ?? ""
                            ) ?>"
                            required
                        >

                    </div>


                    <div class="campo">

                        <label for="rfc_emisor">

                            RFC del emisor

                        </label>


                        <input
                            type="text"
                            name="rfc_emisor"
                            id="rfc_emisor"
                            value="<?= htmlspecialchars(
                                $_POST["rfc_emisor"] ?? ""
                            ) ?>"
                            maxlength="20"
                            required
                        >

                    </div>


                    <div class="campo">

                        <label for="tasa_iva">

                            IVA (%)

                        </label>


                        <input
                            type="number"
                            name="tasa_iva"
                            id="tasa_iva"
                            list="opciones_iva"
                            value="<?= htmlspecialchars(
                                $_POST["tasa_iva"] ?? "16"
                            ) ?>"
                            min="0"
                            max="100"
                            step="0.01"
                            placeholder="Ej. 0, 8, 16"
                            required
                        >


                        <datalist id="opciones_iva">

                            <option value="0">

                            <option value="8">

                            <option value="16">

                        </datalist>


                        <small>

                            Puedes seleccionar 0%, 8% o 16%,
                            o escribir otro porcentaje.

                        </small>

                    </div>


                    <div class="campo">

                        <label for="moneda">

                            Moneda

                        </label>


                        <input
                            type="text"
                            id="moneda"
                            value="MXN"
                            readonly
                        >

                    </div>


                </div>


                <!-- ==================================================
                     ARTÍCULOS
                =================================================== -->

                <div class="seccion-articulos">


                    <h2>

                        Artículos de la factura

                    </h2>


                    <p class="texto-ayuda">

                        Puedes agregar varios artículos
                        dentro de una misma factura.

                    </p>


                    <div class="tabla-contenedor">


                        <table class="tabla">


                            <thead>

                                <tr>

                                    <th style="width: 35%;">

                                        Artículo

                                    </th>


                                    <th style="width: 12%;">

                                        Cantidad

                                    </th>


                                    <th style="width: 15%;">

                                        Costo unitario

                                    </th>


                                    <th style="width: 15%;">

                                        Importe

                                    </th>


                                    <th style="width: 8%;">

                                        Acción

                                    </th>

                                </tr>

                            </thead>


                            <tbody
                                id="contenedorArticulos"
                            >


                                <tr
                                    class="fila-articulo"
                                >


                                    <td>

                                        <select
                                            name="inventario_id[]"
                                            class="articulo"
                                            required
                                        >

                                            <option value="">

                                                -- Seleccionar artículo --

                                            </option>


                                            <?php foreach (
                                                $articulos
                                                as $articulo
                                            ): ?>


                                                <option
                                                    value="<?= $articulo["id"] ?>"
                                                >

                                                    <?= htmlspecialchars(
                                                        $articulo["codigo"]
                                                    ) ?>

                                                    -

                                                    <?= htmlspecialchars(
                                                        $articulo[
                                                            "articulo_descripcion"
                                                        ]
                                                    ) ?>

                                                    |
                                                    Existencia:

                                                    <?= number_format(
                                                        $articulo["cantidad"],
                                                        3
                                                    ) ?>

                                                </option>


                                            <?php endforeach; ?>


                                        </select>

                                    </td>


                                    <td>

                                        <input
                                            type="number"
                                            name="cantidad[]"
                                            class="cantidad"
                                            min="0.001"
                                            step="0.001"
                                            value="1"
                                            required
                                        >

                                    </td>


                                    <td>

                                        <input
                                            type="number"
                                            name="costo_unitario[]"
                                            class="costo-unitario"
                                            min="0"
                                            step="0.01"
                                            value="0"
                                            required
                                        >

                                    </td>


                                    <td>

                                        <input
                                            type="number"
                                            class="importe-linea"
                                            value="0.00"
                                            readonly
                                        >

                                    </td>


                                    <td>

                                        <button
                                            type="button"
                                            class="boton boton-eliminar"
                                            onclick="eliminarFila(this)"
                                        >

                                            ✕

                                        </button>

                                    </td>


                                </tr>


                            </tbody>


                        </table>


                    </div>


                    <button
                        type="button"
                        class="boton boton-agregar"
                        onclick="agregarArticulo()"
                    >

                        + Agregar otro artículo

                    </button>


                </div>


                <!-- ==================================================
                     RESUMEN
                =================================================== -->

                <div class="resumen">


                    <div class="resumen-fila">

                        <span>

                            Subtotal:

                        </span>


                        <strong id="subtotal">

                            $0.00

                        </strong>

                    </div>


                    <div class="resumen-fila">

                        <span>

                            IVA:

                        </span>


                        <strong id="iva_monto">

                            $0.00

                        </strong>

                    </div>


                    <div class="resumen-fila">

                        <span>

                            Total:

                        </span>


                        <strong
                            id="total"
                            class="resumen-total"
                        >

                            $0.00

                        </strong>

                    </div>


                </div>


                <!-- ==================================================
                     OBSERVACIONES
                =================================================== -->

                <div
                    class="campo"
                    style="margin-top: 25px;"
                >


                    <label for="observaciones">

                        Observaciones

                    </label>


                    <textarea
                        name="observaciones"
                        id="observaciones"
                        rows="4"
                        placeholder="Observaciones de la entrada..."
                    ><?= htmlspecialchars(
                        $_POST["observaciones"] ?? ""
                    ) ?></textarea>


                </div>


                <!-- ==================================================
                     BOTONES
                =================================================== -->

                <div class="botones">


                    <a
                        href="index.php"
                        class="boton boton-cancelar"
                        style="text-decoration:none;"
                    >

                        Cancelar

                    </a>


                    <button
                        type="submit"
                        class="boton boton-registrar"
                    >

                        📥 Registrar entrada

                    </button>


                </div>


            </form>


        </div>


    </div>


</main>


<script>

/*
|--------------------------------------------------------------------------
| AGREGAR ARTÍCULO
|--------------------------------------------------------------------------
*/

function agregarArticulo() {

    const contenedor =
        document.getElementById(
            "contenedorArticulos"
        );


    const primeraFila =
        document.querySelector(
            ".fila-articulo"
        );


    const nuevaFila =
        primeraFila.cloneNode(true);


    nuevaFila
        .querySelector(".articulo")
        .value = "";


    nuevaFila
        .querySelector(".cantidad")
        .value = "1";


    nuevaFila
        .querySelector(".costo-unitario")
        .value = "0";


    nuevaFila
        .querySelector(".importe-linea")
        .value = "0.00";


    contenedor.appendChild(nuevaFila);


    calcularTotales();

}


/*
|--------------------------------------------------------------------------
| ELIMINAR ARTÍCULO
|--------------------------------------------------------------------------
*/

function eliminarFila(boton) {

    const filas =
        document.querySelectorAll(
            ".fila-articulo"
        );


    if (filas.length <= 1) {

        alert(
            "Debe existir por lo menos un artículo."
        );

        return;

    }


    boton
        .closest(".fila-articulo")
        .remove();


    calcularTotales();

}


/*
|--------------------------------------------------------------------------
| CALCULAR IMPORTE DE LÍNEA
|--------------------------------------------------------------------------
*/

function calcularImporteLinea(fila) {

    const cantidad =
        parseFloat(
            fila.querySelector(
                ".cantidad"
            ).value
        ) || 0;


    const costo =
        parseFloat(
            fila.querySelector(
                ".costo-unitario"
            ).value
        ) || 0;


    const importe =
        cantidad * costo;


    fila.querySelector(
        ".importe-linea"
    ).value =
        importe.toFixed(2);


    return importe;

}


/*
|--------------------------------------------------------------------------
| CALCULAR TOTALES
|--------------------------------------------------------------------------
*/

function calcularTotales() {

    let subtotal = 0;


    const filas =
        document.querySelectorAll(
            ".fila-articulo"
        );


    filas.forEach(function(fila) {

        subtotal +=
            calcularImporteLinea(fila);

    });


    const campoIva =
        document.getElementById(
            "tasa_iva"
        );


    let tasaIva =
        parseFloat(campoIva.value) || 0;


    if (tasaIva < 0) {

        tasaIva = 0;

    }


    if (tasaIva > 100) {

        tasaIva = 100;

    }


    const iva =
        subtotal * (tasaIva / 100);


    const total =
        subtotal + iva;


    document.getElementById(
        "subtotal"
    ).textContent =
        "$" + subtotal.toFixed(2);


    document.getElementById(
        "iva_monto"
    ).textContent =
        "$" + iva.toFixed(2);


    document.getElementById(
        "total"
    ).textContent =
        "$" + total.toFixed(2);

}


/*
|--------------------------------------------------------------------------
| EVENTOS DE CÁLCULO
|--------------------------------------------------------------------------
*/

document.addEventListener(
    "input",
    function(evento) {

        if (

            evento.target.classList.contains(
                "cantidad"
            )

            ||

            evento.target.classList.contains(
                "costo-unitario"
            )

            ||

            evento.target.id === "tasa_iva"

        ) {

            calcularTotales();

        }

    }
);


/*
|--------------------------------------------------------------------------
| VALIDACIÓN ANTES DE ENVIAR
|--------------------------------------------------------------------------
*/

document
    .getElementById("formEntrada")
    .addEventListener(
        "submit",
        function(evento) {

            const filas =
                document.querySelectorAll(
                    ".fila-articulo"
                );


            if (filas.length === 0) {

                evento.preventDefault();

                alert(
                    "Debes agregar por lo menos un artículo."
                );

                return;

            }


            let correcto = true;


            filas.forEach(function(fila) {

                const articulo =
                    fila.querySelector(
                        ".articulo"
                    ).value;


                const cantidad =
                    parseFloat(
                        fila.querySelector(
                            ".cantidad"
                        ).value
                    ) || 0;


                const costo =
                    parseFloat(
                        fila.querySelector(
                            ".costo-unitario"
                        ).value
                    );


                if (articulo === "") {

                    correcto = false;

                }


                if (cantidad <= 0) {

                    correcto = false;

                }


                if (
                    isNaN(costo) ||
                    costo < 0
                ) {

                    correcto = false;

                }

            });


            if (!correcto) {

                evento.preventDefault();

                alert(
                    "Revisa los artículos, cantidades y costos unitarios."
                );

                return;

            }


            /*
            |--------------------------------------------------------------------------
            | CONFIRMACIÓN
            |--------------------------------------------------------------------------
            */

            const tasaIva =
                parseFloat(
                    document.getElementById(
                        "tasa_iva"
                    ).value
                ) || 0;


            const total =
                document.getElementById(
                    "total"
                ).textContent;


            const folio =
                document.getElementById(
                    "folio"
                ).value;


            const confirmacion =
                confirm(

                    "¿Deseas registrar esta entrada?\n\n" +

                    "Factura: " +
                    folio +
                    "\n" +

                    "Artículos: " +
                    filas.length +
                    "\n" +

                    "IVA: " +
                    tasaIva +
                    "%\n" +

                    "Total: " +
                    total

                );


            if (!confirmacion) {

                evento.preventDefault();

            }

        }
    );


/*
|--------------------------------------------------------------------------
| CALCULAR AL CARGAR
|--------------------------------------------------------------------------
*/

calcularTotales();

</script>


</body>

</html>