<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();


/*
|--------------------------------------------------------------------------
| DATOS DEL USUARIO
|--------------------------------------------------------------------------
*/

$nombre_empleado =
    $_SESSION['nombre_empleado'] ?? 'Usuario';

$rol_usuario =
    $_SESSION['rol'] ?? 'USUARIO';


/*
|--------------------------------------------------------------------------
| FILTROS
|--------------------------------------------------------------------------
*/

$buscar =
    trim($_GET["buscar"] ?? "");

$tipo =
    trim($_GET["tipo"] ?? "");

$fecha_desde =
    trim($_GET["fecha_desde"] ?? "");

$fecha_hasta =
    trim($_GET["fecha_hasta"] ?? "");


/*
|--------------------------------------------------------------------------
| CONSULTA BASE
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT

        m.id AS movimiento_id,

        m.tipo,

        m.cantidad,

        m.cantidad_anterior,

        m.cantidad_nueva,

        m.observaciones,

        m.fecha_movimiento,

        i.codigo,

        i.articulo_descripcion,

        i.ubicacion,

        i.proveedor_marca,

        f.numero_factura,

        f.nombre_emisor

    FROM movimientos_inventario m

    INNER JOIN inventario i
        ON i.id = m.inventario_id

    LEFT JOIN facturas f
        ON f.id = m.factura_id

    WHERE 1=1
";


/*
|--------------------------------------------------------------------------
| PARÁMETROS
|--------------------------------------------------------------------------
*/

$parametros = [];

$tipos = "";


/*
|--------------------------------------------------------------------------
| BUSCADOR
|--------------------------------------------------------------------------
*/

if ($buscar !== "") {

    $sql .= "
        AND (
            i.codigo LIKE ?
            OR i.articulo_descripcion LIKE ?
            OR i.proveedor_marca LIKE ?
            OR f.numero_factura LIKE ?
            OR f.nombre_emisor LIKE ?
        )
    ";

    $texto =
        "%" . $buscar . "%";

    $parametros[] = $texto;
    $parametros[] = $texto;
    $parametros[] = $texto;
    $parametros[] = $texto;
    $parametros[] = $texto;

    $tipos .= "sssss";
}


/*
|--------------------------------------------------------------------------
| FILTRO TIPO
|--------------------------------------------------------------------------
*/

if ($tipo !== "") {

    $sql .= "
        AND m.tipo = ?
    ";

    $parametros[] = $tipo;

    $tipos .= "s";
}


/*
|--------------------------------------------------------------------------
| FECHA DESDE
|--------------------------------------------------------------------------
*/

if ($fecha_desde !== "") {

    $sql .= "
        AND DATE(m.fecha_movimiento) >= ?
    ";

    $parametros[] =
        $fecha_desde;

    $tipos .= "s";
}


/*
|--------------------------------------------------------------------------
| FECHA HASTA
|--------------------------------------------------------------------------
*/

if ($fecha_hasta !== "") {

    $sql .= "
        AND DATE(m.fecha_movimiento) <= ?
    ";

    $parametros[] =
        $fecha_hasta;

    $tipos .= "s";
}


/*
|--------------------------------------------------------------------------
| ORDEN
|--------------------------------------------------------------------------
*/

$sql .= "
    ORDER BY
        m.fecha_movimiento DESC,
        m.id DESC
";


/*
|--------------------------------------------------------------------------
| PREPARAR CONSULTA
|--------------------------------------------------------------------------
*/

$stmt =
    $conexion->prepare($sql);


if (!$stmt) {

    die(
        "Error en la consulta: " .
        $conexion->error
    );
}


/*
|--------------------------------------------------------------------------
| ASIGNAR PARÁMETROS
|--------------------------------------------------------------------------
*/

if (!empty($parametros)) {

    $stmt->bind_param(
        $tipos,
        ...$parametros
    );
}


/*
|--------------------------------------------------------------------------
| EJECUTAR
|--------------------------------------------------------------------------
*/

if (!$stmt->execute()) {

    die(
        "Error ejecutando la consulta: " .
        $stmt->error
    );
}


$resultado =
    $stmt->get_result();


/*
|--------------------------------------------------------------------------
| TOTAL DE MOVIMIENTOS
|--------------------------------------------------------------------------
*/

$total_movimientos =
    $resultado->num_rows;

?>


<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Historial de movimientos - Grupo Protec
    </title>


    <style>

        /*
        |--------------------------------------------------------------------------
        | GENERAL
        |--------------------------------------------------------------------------
        */

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            font-family:
                Arial,
                sans-serif;

            background: #f4f6f9;

            color: #212529;
        }


        /*
        |--------------------------------------------------------------------------
        | CONTENIDO PRINCIPAL
        |--------------------------------------------------------------------------
        */

        .contenido-principal {

            margin-left: 240px;

            min-height: 100vh;

            padding: 25px;
        }


        /*
        |--------------------------------------------------------------------------
        | BARRA SUPERIOR
        |--------------------------------------------------------------------------
        */

        .barra-superior {

            display: flex;

            justify-content:
                space-between;

            align-items: center;

            background: #ffffff;

            padding: 15px 20px;

            border-radius: 8px;

            margin-bottom: 20px;

            box-shadow:
                0 2px 8px rgba(0,0,0,0.08);
        }


        .titulo-superior {

            font-size: 22px;

            font-weight: bold;
        }


        .usuario-superior {

            font-size: 14px;

            color: #555;
        }


        /*
        |--------------------------------------------------------------------------
        | ENCABEZADO
        |--------------------------------------------------------------------------
        */

        .encabezado-pagina {

            margin-bottom: 20px;
        }


        .encabezado-pagina h1 {

            margin: 0 0 6px 0;

            font-size: 28px;
        }


        .encabezado-pagina p {

            margin: 0;

            color: #6c757d;

            font-size: 14px;
        }


        /*
        |--------------------------------------------------------------------------
        | CONTENEDOR
        |--------------------------------------------------------------------------
        */

        .contenedor-historial {

            background: #ffffff;

            padding: 20px;

            border-radius: 10px;

            box-shadow:
                0 2px 10px rgba(0,0,0,.10);
        }


        /*
        |--------------------------------------------------------------------------
        | FILTROS
        |--------------------------------------------------------------------------
        */

        .zona-filtros {

            background: #f8f9fa;

            border: 1px solid #e1e4e8;

            border-radius: 8px;

            padding: 15px;

            margin-bottom: 20px;
        }


        .titulo-filtros {

            font-size: 15px;

            font-weight: bold;

            margin-bottom: 12px;
        }


        .filtros {

            display: grid;

            grid-template-columns:
                2fr
                1fr
                1fr
                1fr
                auto;

            gap: 10px;

            align-items: end;
        }


        .filtro-campo {

            display: flex;

            flex-direction: column;
        }


        .filtro-campo label {

            font-size: 12px;

            font-weight: bold;

            margin-bottom: 5px;

            color: #495057;
        }


        .filtros input,
        .filtros select {

            width: 100%;

            padding: 10px;

            border:
                1px solid #ced4da;

            border-radius: 5px;

            background: white;

            font-family: Arial, sans-serif;

            font-size: 14px;
        }


        /*
        |--------------------------------------------------------------------------
        | BOTONES
        |--------------------------------------------------------------------------
        */

        .boton {

            border: none;

            padding: 10px 15px;

            border-radius: 5px;

            cursor: pointer;

            text-decoration: none;

            display: inline-block;

            font-family:
                Arial,
                sans-serif;

            font-size: 14px;
        }


        .buscar {

            background: #0d6efd;

            color: white;
        }


        .buscar:hover {

            background: #0b5ed7;
        }


        .limpiar {

            background: #6c757d;

            color: white;

            margin-top: 10px;
        }


        .limpiar:hover {

            background: #5c636a;
        }


        /*
        |--------------------------------------------------------------------------
        | RESUMEN
        |--------------------------------------------------------------------------
        */

        .resumen {

            display: flex;

            justify-content:
                space-between;

            align-items: center;

            background: #e9ecef;

            padding: 14px 16px;

            border-radius: 6px;

            margin-bottom: 15px;

            font-size: 14px;
        }


        .resumen-numero {

            font-size: 20px;

            font-weight: bold;
        }


        /*
        |--------------------------------------------------------------------------
        | TABLA
        |--------------------------------------------------------------------------
        */

        .tabla-contenedor {

            overflow-x: auto;

            border:
                1px solid #dee2e6;

            border-radius: 6px;
        }


        table {

            width: 100%;

            border-collapse: collapse;

            min-width: 1400px;

            background: #ffffff;
        }


        th {

            background: #212529;

            color: #ffffff;

            padding: 11px 10px;

            text-align: left;

            font-size: 13px;

            white-space: nowrap;
        }


        td {

            padding: 10px;

            border-bottom:
                1px solid #e1e4e8;

            font-size: 13px;

            vertical-align: middle;
        }


        tbody tr:hover {

            background: #f8f9fa;
        }


        tbody tr:last-child td {

            border-bottom: none;
        }


        /*
        |--------------------------------------------------------------------------
        | FECHA
        |--------------------------------------------------------------------------
        */

        .fecha {

            white-space: nowrap;

            color: #495057;
        }


        /*
        |--------------------------------------------------------------------------
        | CÓDIGO
        |--------------------------------------------------------------------------
        */

        .codigo {

            font-weight: bold;

            white-space: nowrap;
        }


        /*
        |--------------------------------------------------------------------------
        | DESCRIPCIÓN
        |--------------------------------------------------------------------------
        */

        .descripcion {

            min-width: 220px;

            max-width: 320px;
        }


        /*
        |--------------------------------------------------------------------------
        | TIPOS
        |--------------------------------------------------------------------------
        */

        .tipo-badge {

            display: inline-block;

            padding: 5px 9px;

            border-radius: 20px;

            font-size: 12px;

            font-weight: bold;

            white-space: nowrap;
        }


        .entrada {

            color: #0f5132;

            background: #d1e7dd;
        }


        .salida {

            color: #842029;

            background: #f8d7da;
        }


        /*
        |--------------------------------------------------------------------------
        | CANTIDADES
        |--------------------------------------------------------------------------
        */

        .cantidad {

            text-align: right;

            font-weight: bold;

            white-space: nowrap;
        }


        .cantidad-entrada {

            color: #198754;
        }


        .cantidad-salida {

            color: #dc3545;
        }


        /*
        |--------------------------------------------------------------------------
        | EXISTENCIA
        |--------------------------------------------------------------------------
        */

        .existencia-anterior {

            color: #6c757d;

            text-align: right;

            white-space: nowrap;
        }


        .existencia-nueva {

            font-weight: bold;

            text-align: right;

            white-space: nowrap;
        }


        /*
        |--------------------------------------------------------------------------
        | UBICACIÓN
        |--------------------------------------------------------------------------
        */

        .ubicacion {

            white-space: nowrap;
        }


        /*
        |--------------------------------------------------------------------------
        | PROVEEDOR
        |--------------------------------------------------------------------------
        */

        .proveedor {

            min-width: 180px;
        }


        .proveedor small {

            display: block;

            color: #6c757d;

            margin-top: 3px;
        }


        /*
        |--------------------------------------------------------------------------
        | FACTURA
        |--------------------------------------------------------------------------
        */

        .factura {

            white-space: nowrap;
        }


        .sin-factura {

            color: #999;

            font-style: italic;
        }


        /*
        |--------------------------------------------------------------------------
        | OBSERVACIONES
        |--------------------------------------------------------------------------
        */

        .observaciones {

            min-width: 220px;

            max-width: 350px;

            color: #495057;
        }


        /*
        |--------------------------------------------------------------------------
        | SIN RESULTADOS
        |--------------------------------------------------------------------------
        */

        .sin-resultados {

            text-align: center;

            padding: 45px 20px;

            color: #6c757d;

            font-size: 15px;
        }


        /*
        |--------------------------------------------------------------------------
        | RESPONSIVE
        |--------------------------------------------------------------------------
        */

        @media(max-width: 1100px) {

            .filtros {

                grid-template-columns:
                    1fr
                    1fr;
            }


            .boton-buscar {

                width: 100%;
            }
        }


        @media(max-width: 850px) {

            .contenido-principal {

                margin-left: 0;

                padding: 15px;
            }


            .barra-superior {

                flex-direction: column;

                align-items: flex-start;

                gap: 8px;
            }


            .filtros {

                grid-template-columns: 1fr;
            }


            .resumen {

                align-items: flex-start;

                flex-direction: column;

                gap: 5px;
            }
        }


        @media(max-width: 600px) {

            .contenido-principal {

                padding: 10px;
            }


            .contenedor-historial {

                padding: 12px;
            }


            .encabezado-pagina h1 {

                font-size: 22px;
            }
        }

    </style>

</head>


<body>


<?php include 'menu.php'; ?>


<main class="contenido-principal">


    <!-- ==========================================================
         BARRA SUPERIOR
    =========================================================== -->

    <header class="barra-superior">

        <div class="titulo-superior">

            📋 Historial de movimientos

        </div>


        <div class="usuario-superior">

            Usuario:

            <strong>

                <?= htmlspecialchars(
                    $nombre_empleado
                ) ?>

            </strong>

        </div>

    </header>


    <!-- ==========================================================
         ENCABEZADO
    =========================================================== -->

    <div class="encabezado-pagina">

        <h1>

            📋 Historial de movimientos

        </h1>

        <p>

            Consulta las entradas y salidas registradas
            en el almacén.

        </p>

    </div>


    <!-- ==========================================================
         CONTENEDOR
    =========================================================== -->

    <div class="contenedor-historial">


        <!-- ======================================================
             FILTROS
        ======================================================= -->

        <div class="zona-filtros">

            <div class="titulo-filtros">

                🔎 Buscar movimientos

            </div>


            <form
                method="GET"
                class="filtros"
            >


                <div class="filtro-campo">

                    <label for="buscar">

                        Buscar

                    </label>

                    <input
                        type="text"
                        name="buscar"
                        id="buscar"
                        placeholder="Código, descripción, proveedor o factura..."
                        value="<?= htmlspecialchars(
                            $buscar
                        ) ?>"
                    >

                </div>


                <div class="filtro-campo">

                    <label for="tipo">

                        Tipo de movimiento

                    </label>

                    <select
                        name="tipo"
                        id="tipo"
                    >

                        <option value="">

                            Todos los movimientos

                        </option>


                        <option
                            value="ENTRADA"
                            <?= $tipo === "ENTRADA"
                                ? "selected"
                                : "" ?>
                        >

                            🟢 Entradas

                        </option>


                        <option
                            value="SALIDA"
                            <?= $tipo === "SALIDA"
                                ? "selected"
                                : "" ?>
                        >

                            🔴 Salidas

                        </option>

                    </select>

                </div>


                <div class="filtro-campo">

                    <label for="fecha_desde">

                        Fecha desde

                    </label>

                    <input
                        type="date"
                        name="fecha_desde"
                        id="fecha_desde"
                        value="<?= htmlspecialchars(
                            $fecha_desde
                        ) ?>"
                    >

                </div>


                <div class="filtro-campo">

                    <label for="fecha_hasta">

                        Fecha hasta

                    </label>

                    <input
                        type="date"
                        name="fecha_hasta"
                        id="fecha_hasta"
                        value="<?= htmlspecialchars(
                            $fecha_hasta
                        ) ?>"
                    >

                </div>


                <div class="filtro-campo">

                    <button
                        type="submit"
                        class="boton buscar boton-buscar"
                    >

                        🔎 Buscar

                    </button>

                </div>


            </form>


            <a
                href="historial_movimientos.php"
                class="boton limpiar"
            >

                ↻ Limpiar filtros

            </a>

        </div>


        <!-- ======================================================
             RESUMEN
        ======================================================= -->

        <div class="resumen">

            <div>

                📊 Movimientos encontrados:

            </div>


            <div class="resumen-numero">

                <?= $total_movimientos ?>

            </div>

        </div>


        <!-- ======================================================
             TABLA
        ======================================================= -->

        <div class="tabla-contenedor">


            <table>


                <thead>

                    <tr>

                        <th>
                            Fecha
                        </th>

                        <th>
                            Código
                        </th>

                        <th>
                            Descripción
                        </th>

                        <th>
                            Tipo
                        </th>

                        <th>
                            Cantidad
                        </th>

                        <th>
                            Cantidad anterior
                        </th>

                        <th>
                            Cantidad nueva
                        </th>

                        <th>
                            Ubicación
                        </th>

                        <th>
                            Proveedor
                        </th>

                        <th>
                            Factura
                        </th>

                        <th>
                            Observaciones
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php if ($resultado->num_rows > 0): ?>


                    <?php while (
                        $mov =
                        $resultado->fetch_assoc()
                    ): ?>


                        <?php

                        $esEntrada =
                            strtoupper(
                                $mov["tipo"]
                            ) === "ENTRADA";

                        ?>


                        <tr>


                            <!-- ==================================
                                 FECHA
                            =================================== -->

                            <td class="fecha">

                                <?= htmlspecialchars(
                                    $mov["fecha_movimiento"]
                                ) ?>

                            </td>


                            <!-- ==================================
                                 CÓDIGO
                            =================================== -->

                            <td class="codigo">

                                <?= htmlspecialchars(
                                    $mov["codigo"]
                                ) ?>

                            </td>


                            <!-- ==================================
                                 DESCRIPCIÓN
                            =================================== -->

                            <td class="descripcion">

                                <?= htmlspecialchars(
                                    $mov[
                                        "articulo_descripcion"
                                    ]
                                ) ?>

                            </td>


                            <!-- ==================================
                                 TIPO
                            =================================== -->

                            <td>

                                <?php if ($esEntrada): ?>

                                    <span
                                        class="tipo-badge entrada"
                                    >

                                        🟢 ENTRADA

                                    </span>

                                <?php else: ?>

                                    <span
                                        class="tipo-badge salida"
                                    >

                                        🔴 SALIDA

                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- ==================================
                                 CANTIDAD
                            =================================== -->

                            <td
                                class="
                                    cantidad
                                    <?= $esEntrada
                                        ? 'cantidad-entrada'
                                        : 'cantidad-salida'
                                    ?>
                                "
                            >

                                <?= $esEntrada ? '+' : '-' ?>

                                <?= number_format(
                                    $mov["cantidad"],
                                    3
                                ) ?>

                            </td>


                            <!-- ==================================
                                 CANTIDAD ANTERIOR
                            =================================== -->

                            <td class="existencia-anterior">

                                <?= number_format(
                                    $mov["cantidad_anterior"],
                                    3
                                ) ?>

                            </td>


                            <!-- ==================================
                                 CANTIDAD NUEVA
                            =================================== -->

                            <td class="existencia-nueva">

                                <?= number_format(
                                    $mov["cantidad_nueva"],
                                    3
                                ) ?>

                            </td>


                            <!-- ==================================
                                 UBICACIÓN
                            =================================== -->

                            <td class="ubicacion">

                                <?= htmlspecialchars(
                                    $mov["ubicacion"] ?? ""
                                ) ?>

                            </td>


                            <!-- ==================================
                                 PROVEEDOR
                            =================================== -->

                            <td class="proveedor">

                                <?= htmlspecialchars(
                                    $mov[
                                        "proveedor_marca"
                                    ] ?? ""
                                ) ?>


                                <?php if (
                                    !empty(
                                        $mov[
                                            "nombre_emisor"
                                        ]
                                    )
                                ): ?>

                                    <small>

                                        <?= htmlspecialchars(
                                            $mov[
                                                "nombre_emisor"
                                            ]
                                        ) ?>

                                    </small>

                                <?php endif; ?>

                            </td>


                            <!-- ==================================
                                 FACTURA
                            =================================== -->

                            <td class="factura">

                                <?php if (
                                    !empty(
                                        $mov[
                                            "numero_factura"
                                        ]
                                    )
                                ): ?>

                                    <?= htmlspecialchars(
                                        $mov[
                                            "numero_factura"
                                        ]
                                    ) ?>

                                <?php else: ?>

                                    <span class="sin-factura">

                                        Sin factura

                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- ==================================
                                 OBSERVACIONES
                            =================================== -->

                            <td class="observaciones">

                                <?= htmlspecialchars(
                                    $mov[
                                        "observaciones"
                                    ] ?? ""
                                ) ?>

                            </td>


                        </tr>


                    <?php endwhile; ?>


                <?php else: ?>


                    <tr>

                        <td
                            colspan="11"
                            class="sin-resultados"
                        >

                            📭

                            <br><br>

                            No se encontraron movimientos
                            con los filtros seleccionados.

                        </td>

                    </tr>


                <?php endif; ?>


                </tbody>


            </table>


        </div>


    </div>


</main>


<?php

$stmt->close();

?>


</body>

</html>