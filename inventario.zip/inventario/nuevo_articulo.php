<?php

// ==========================================
// SEGURIDAD
// ==========================================

require_once __DIR__ . '/seguridad.php';

verificar_sesion();


// ==========================================
// CONEXIÓN
// ==========================================

require_once __DIR__ . '/conexion.php';


// ==========================================
// VARIABLES
// ==========================================

$mensaje = "";
$error = "";

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';


// ==========================================
// OBTENER ARTÍCULOS DEL INVENTARIO
// ==========================================

$articulos = [];

$sql_articulos = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        ubicacion,
        maximo,
        minimo,
        proveedor_marca
    FROM inventario
    ORDER BY articulo_descripcion ASC
";

$resultado_articulos = $conexion->query($sql_articulos);

if ($resultado_articulos) {

    while ($fila = $resultado_articulos->fetch_assoc()) {

        $articulos[] = $fila;

    }

}


// ==========================================
// OBTENER UBICACIONES ACTIVAS
// ==========================================

$ubicaciones = [];

$sql_ubicaciones = "
    SELECT
        id,
        codigo,
        descripcion,
        tipo
    FROM ubicaciones
    WHERE activo = 1
    ORDER BY
        tipo ASC,
        codigo ASC
";

$resultado_ubicaciones = $conexion->query($sql_ubicaciones);

if ($resultado_ubicaciones) {

    while ($fila = $resultado_ubicaciones->fetch_assoc()) {

        $ubicaciones[] = $fila;

    }

}


// ==========================================
// PROCESAR FORMULARIO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $accion = $_POST["accion"] ?? "";


    // ==================================================
    // ==================================================
    // INGRESO MÚLTIPLE DE ARTÍCULOS EXISTENTES
    // ==================================================
    // ==================================================

    if ($accion === "ingreso_existente") {

        $ids_articulos =
            $_POST["id_articulo"] ?? [];

        $cantidades =
            $_POST["cantidad"] ?? [];

        $ubicaciones_nuevas =
            $_POST["ubicacion"] ?? [];


        // ==========================================
        // VALIDAR QUE SE RECIBAN RENGLONES
        // ==========================================

        if (!is_array($ids_articulos)) {

            $ids_articulos = [];

        }

        if (!is_array($cantidades)) {

            $cantidades = [];

        }

        if (!is_array($ubicaciones_nuevas)) {

            $ubicaciones_nuevas = [];

        }


        if (count($ids_articulos) === 0) {

            $error =
                "Debes agregar al menos un artículo.";

        } else {

            $conexion->begin_transaction();


            try {

                $cantidad_renglones =
                    count($ids_articulos);


                for (
                    $i = 0;
                    $i < $cantidad_renglones;
                    $i++
                ) {


                    // ==================================
                    // DATOS DEL RENGLÓN
                    // ==================================

                    $id_articulo =
                        intval(
                            $ids_articulos[$i] ?? 0
                        );

                    $cantidad_reingreso =
                        intval(
                            $cantidades[$i] ?? 0
                        );

                    $ubicacion_nueva =
                        trim(
                            $ubicaciones_nuevas[$i] ?? ""
                        );


                    // ==================================
                    // VALIDACIONES
                    // ==================================

                    if ($id_articulo <= 0) {

                        throw new Exception(
                            "El renglón "
                            . ($i + 1)
                            . " no tiene un artículo seleccionado."
                        );

                    }

                    if ($cantidad_reingreso <= 0) {

                        throw new Exception(
                            "La cantidad del renglón "
                            . ($i + 1)
                            . " debe ser mayor a 0."
                        );

                    }


                    // ==================================
                    // BUSCAR ARTÍCULO
                    // ==================================

                    $buscar = $conexion->prepare("
                        SELECT
                            id,
                            codigo,
                            articulo_descripcion,
                            cantidad,
                            ubicacion,
                            maximo,
                            minimo,
                            proveedor_marca
                        FROM inventario
                        WHERE id = ?
                        LIMIT 1
                    ");


                    if (!$buscar) {

                        throw new Exception(
                            "Error al preparar la consulta del artículo: "
                            . $conexion->error
                        );

                    }


                    $buscar->bind_param(
                        "i",
                        $id_articulo
                    );

                    $buscar->execute();

                    $resultado =
                        $buscar->get_result();


                    if ($resultado->num_rows === 0) {

                        $buscar->close();

                        throw new Exception(
                            "El artículo del renglón "
                            . ($i + 1)
                            . " no existe en el inventario."
                        );

                    }


                    $articulo =
                        $resultado->fetch_assoc();

                    $buscar->close();


                    // ==================================
                    // CANTIDADES
                    // ==================================

                    $cantidad_actual =
                        intval(
                            $articulo["cantidad"]
                        );

                    $nueva_cantidad =
                        $cantidad_actual
                        + $cantidad_reingreso;


                    // ==================================
                    // UBICACIÓN
                    // ==================================

                    $ubicacion_final =
                        $articulo["ubicacion"];


                    if ($ubicacion_nueva !== "") {

                        $ubicacion_final =
                            $ubicacion_nueva;

                    }


                    // ==================================
                    // ACTUALIZAR INVENTARIO
                    // ==================================

                    $actualizar =
                        $conexion->prepare("
                            UPDATE inventario
                            SET
                                cantidad = ?,
                                ubicacion = ?
                            WHERE id = ?
                        ");


                    if (!$actualizar) {

                        throw new Exception(
                            "Error al preparar la actualización: "
                            . $conexion->error
                        );

                    }


                    $actualizar->bind_param(
                        "isi",
                        $nueva_cantidad,
                        $ubicacion_final,
                        $id_articulo
                    );


                    if (!$actualizar->execute()) {

                        $actualizar->close();

                        throw new Exception(
                            "Error al actualizar el artículo "
                            . $articulo["codigo"]
                            . ": "
                            . $actualizar->error
                        );

                    }


                    $actualizar->close();


                    // ==================================
                    // OBSERVACIONES
                    // ==================================

                    $observaciones =
                        "Ingreso múltiple de artículo existente. "
                        . "Código: "
                        . $articulo["codigo"]
                        . ". "
                        . "Descripción: "
                        . $articulo["articulo_descripcion"]
                        . ". "
                        . "Ubicación: "
                        . (
                            $ubicacion_final !== ""
                                ? $ubicacion_final
                                : "Sin ubicación"
                        );


                    // ==================================
                    // REGISTRAR MOVIMIENTO
                    // ==================================

                    $movimiento =
                        $conexion->prepare("
                            INSERT INTO movimientos_inventario
                            (
                                inventario_id,
                                tipo,
                                cantidad,
                                cantidad_anterior,
                                cantidad_nueva,
                                factura_id,
                                observaciones
                            )
                            VALUES
                            (
                                ?,
                                'ENTRADA',
                                ?,
                                ?,
                                ?,
                                NULL,
                                ?
                            )
                        ");


                    if (!$movimiento) {

                        throw new Exception(
                            "Error al preparar el movimiento: "
                            . $conexion->error
                        );

                    }


                    $cantidad_movimiento =
                        (float)$cantidad_reingreso;

                    $cantidad_anterior_movimiento =
                        (float)$cantidad_actual;

                    $cantidad_nueva_movimiento =
                        (float)$nueva_cantidad;


                    $movimiento->bind_param(
                        "iddds",
                        $id_articulo,
                        $cantidad_movimiento,
                        $cantidad_anterior_movimiento,
                        $cantidad_nueva_movimiento,
                        $observaciones
                    );


                    if (!$movimiento->execute()) {

                        $movimiento->close();

                        throw new Exception(
                            "Error al registrar el movimiento del artículo "
                            . $articulo["codigo"]
                            . ": "
                            . $movimiento->error
                        );

                    }


                    $movimiento->close();

                }


                // ==================================
                // CONFIRMAR TODO
                // ==================================

                $conexion->commit();


                header(
                    "Location: index.php?"
                    . "mensaje=reingreso_realizado"
                );

                exit;


            } catch (Exception $e) {

                $conexion->rollback();

                $error =
                    $e->getMessage();

            }

        }

    }


    // ==================================================
    // ==================================================
    // REGISTRAR MÚLTIPLES ARTÍCULOS NUEVOS
    // ==================================================
    // ==================================================

    elseif ($accion === "nuevo_articulo") {


        $codigos =
            $_POST["codigo_nuevo"] ?? [];

        $descripciones =
            $_POST["descripcion_nueva"] ?? [];

        $cantidades_nuevas =
            $_POST["cantidad_nueva"] ?? [];

        $ubicaciones_nuevas =
            $_POST["ubicacion_nueva"] ?? [];

        $maximos =
            $_POST["maximo_nuevo"] ?? [];

        $minimos =
            $_POST["minimo_nuevo"] ?? [];

        $proveedores =
            $_POST["proveedor_nuevo"] ?? [];


        // ==========================================
        // ASEGURAR ARRAYS
        // ==========================================

        if (!is_array($codigos)) {

            $codigos = [];

        }

        if (!is_array($descripciones)) {

            $descripciones = [];

        }

        if (!is_array($cantidades_nuevas)) {

            $cantidades_nuevas = [];

        }

        if (!is_array($ubicaciones_nuevas)) {

            $ubicaciones_nuevas = [];

        }

        if (!is_array($maximos)) {

            $maximos = [];

        }

        if (!is_array($minimos)) {

            $minimos = [];

        }

        if (!is_array($proveedores)) {

            $proveedores = [];

        }


        // ==========================================
        // VALIDAR RENGLONES
        // ==========================================

        if (count($codigos) === 0) {

            $error =
                "Debes agregar al menos un artículo nuevo.";

        } else {

            $conexion->begin_transaction();


            try {

                $cantidad_renglones =
                    count($codigos);


                // ==================================
                // PARA EVITAR CÓDIGOS REPETIDOS
                // EN LA MISMA OPERACIÓN
                // ==================================

                $codigos_procesados = [];


                for (
                    $i = 0;
                    $i < $cantidad_renglones;
                    $i++
                ) {


                    // ==================================
                    // DATOS DEL RENGLÓN
                    // ==================================

                    $codigo =
                        trim(
                            $codigos[$i] ?? ""
                        );

                    $descripcion_nueva =
                        trim(
                            $descripciones[$i] ?? ""
                        );

                    $cantidad_nueva =
                        intval(
                            $cantidades_nuevas[$i] ?? 0
                        );

                    $ubicacion_nueva =
                        trim(
                            $ubicaciones_nuevas[$i] ?? ""
                        );

                    $maximo_nuevo =
                        intval(
                            $maximos[$i] ?? 0
                        );

                    $minimo_nuevo =
                        intval(
                            $minimos[$i] ?? 0
                        );

                    $proveedor_nuevo =
                        trim(
                            $proveedores[$i] ?? ""
                        );


                    // ==================================
                    // VALIDACIONES
                    // ==================================

                    if ($codigo === "") {

                        throw new Exception(
                            "Debes ingresar el código "
                            . "del renglón "
                            . ($i + 1)
                            . "."
                        );

                    }


                    if ($descripcion_nueva === "") {

                        throw new Exception(
                            "Debes ingresar la descripción "
                            . "del renglón "
                            . ($i + 1)
                            . "."
                        );

                    }


                    if ($cantidad_nueva < 0) {

                        throw new Exception(
                            "La cantidad inicial del renglón "
                            . ($i + 1)
                            . " no puede ser negativa."
                        );

                    }


                    if ($maximo_nuevo < 0) {

                        throw new Exception(
                            "El máximo del renglón "
                            . ($i + 1)
                            . " no puede ser negativo."
                        );

                    }


                    if ($minimo_nuevo < 0) {

                        throw new Exception(
                            "El mínimo del renglón "
                            . ($i + 1)
                            . " no puede ser negativo."
                        );

                    }


                    // ==================================
                    // EVITAR CÓDIGO REPETIDO EN LA MISMA
                    // OPERACIÓN
                    // ==================================

                    $codigo_comparacion =
                        strtoupper($codigo);


                    if (
                        isset(
                            $codigos_procesados[
                                $codigo_comparacion
                            ]
                        )
                    ) {

                        throw new Exception(
                            "El código "
                            . $codigo
                            . " está repetido en el renglón "
                            . ($i + 1)
                            . "."
                        );

                    }


                    $codigos_procesados[
                        $codigo_comparacion
                    ] = true;


                    // ==================================
                    // VERIFICAR CÓDIGO EN BD
                    // ==================================

                    $verificar_codigo =
                        $conexion->prepare("
                            SELECT id
                            FROM inventario
                            WHERE codigo = ?
                            LIMIT 1
                        ");


                    if (!$verificar_codigo) {

                        throw new Exception(
                            "Error al verificar el código: "
                            . $conexion->error
                        );

                    }


                    $verificar_codigo->bind_param(
                        "s",
                        $codigo
                    );

                    $verificar_codigo->execute();

                    $resultado_codigo =
                        $verificar_codigo->get_result();


                    if ($resultado_codigo->num_rows > 0) {

                        $verificar_codigo->close();

                        throw new Exception(
                            "El código "
                            . $codigo
                            . " ya existe en el inventario."
                        );

                    }


                    $verificar_codigo->close();


                    // ==================================
                    // INSERTAR ARTÍCULO
                    // ==================================

                    $insertar =
                        $conexion->prepare("
                            INSERT INTO inventario
                            (
                                codigo,
                                articulo_descripcion,
                                cantidad,
                                costo_unitario,
                                ubicacion,
                                maximo,
                                minimo,
                                proveedor_marca
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?,
                                0,
                                ?,
                                ?,
                                ?,
                                ?
                            )
                        ");


                    if (!$insertar) {

                        throw new Exception(
                            "Error al preparar el nuevo artículo: "
                            . $conexion->error
                        );

                    }


                    $insertar->bind_param(
                        "ssisiis",
                        $codigo,
                        $descripcion_nueva,
                        $cantidad_nueva,
                        $ubicacion_nueva,
                        $maximo_nuevo,
                        $minimo_nuevo,
                        $proveedor_nuevo
                    );


                    if (!$insertar->execute()) {

                        $insertar->close();

                        throw new Exception(
                            "Error al registrar el artículo "
                            . $codigo
                            . ": "
                            . $insertar->error
                        );

                    }


                    // ==================================
                    // ID DEL ARTÍCULO
                    // ==================================

                    $id_nuevo =
                        $conexion->insert_id;


                    $insertar->close();


                    // ==================================
                    // REGISTRAR MOVIMIENTO
                    // SI TIENE CANTIDAD INICIAL
                    // ==================================

                    if ($cantidad_nueva > 0) {


                        $observaciones =
                            "Alta de artículo nuevo mediante "
                            . "ingreso múltiple. "
                            . "Código: "
                            . $codigo
                            . ". "
                            . "Descripción: "
                            . $descripcion_nueva
                            . ". "
                            . "Ubicación: "
                            . (
                                $ubicacion_nueva !== ""
                                    ? $ubicacion_nueva
                                    : "Sin ubicación"
                            );


                        $movimiento_nuevo =
                            $conexion->prepare("
                                INSERT INTO movimientos_inventario
                                (
                                    inventario_id,
                                    tipo,
                                    cantidad,
                                    cantidad_anterior,
                                    cantidad_nueva,
                                    factura_id,
                                    observaciones
                                )
                                VALUES
                                (
                                    ?,
                                    'ENTRADA',
                                    ?,
                                    0,
                                    ?,
                                    NULL,
                                    ?
                                )
                            ");


                        if (!$movimiento_nuevo) {

                            throw new Exception(
                                "Error al preparar el movimiento "
                                . "del nuevo artículo: "
                                . $conexion->error
                            );

                        }


                        $cantidad_inicial_movimiento =
                            (float)$cantidad_nueva;


                        $movimiento_nuevo->bind_param(
                            "idds",
                            $id_nuevo,
                            $cantidad_inicial_movimiento,
                            $cantidad_inicial_movimiento,
                            $observaciones
                        );


                        if (
                            !$movimiento_nuevo->execute()
                        ) {

                            $movimiento_nuevo->close();

                            throw new Exception(
                                "Error al registrar el movimiento "
                                . "del nuevo artículo "
                                . $codigo
                                . ": "
                                . $movimiento_nuevo->error
                            );

                        }


                        $movimiento_nuevo->close();

                    }

                }


                // ==================================
                // CONFIRMAR TODO
                // ==================================

                $conexion->commit();


                header(
                    "Location: index.php?"
                    . "mensaje=articulo_creado"
                );

                exit;


            } catch (Exception $e) {

                $conexion->rollback();

                $error =
                    $e->getMessage();

            }

        }

    }

    else {

        $error =
            "La operación seleccionada no es válida.";

    }

}

?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Ingreso de artículo</title>


    <style>

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            padding: 0;

            font-family: Arial, sans-serif;

            background: #f4f6f8;

            color: #333;

        }


        .contenido-principal {

            margin-left: 240px;

            min-height: 100vh;

        }


        .barra-superior {

            height: 70px;

            background: #ffffff;

            border-bottom: 1px solid #ddd;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 30px;

            box-shadow:
                0 1px 5px rgba(0,0,0,.08);

        }


        .titulo-superior {

            font-size: 20px;

            font-weight: bold;

            color: #212529;

        }


        .usuario-superior {

            font-size: 13px;

            color: #555;

        }


        .contenedor {

            max-width: 1000px;

            margin: 40px auto;

            background: white;

            padding: 30px;

            border-radius: 12px;

            box-shadow:
                0 3px 15px rgba(0,0,0,.15);

        }


        h1 {

            margin-top: 0;

            color: #333;

        }


        .descripcion-ayuda {

            color: #666;

            font-size: 14px;

            margin-bottom: 25px;

            line-height: 1.5;

        }


        /* ==========================================
           SELECTOR DE OPERACIÓN
        =========================================== */

        .selector-operacion {

            display: flex;

            gap: 10px;

            margin-bottom: 25px;

            flex-wrap: wrap;

        }


        .opcion-operacion {

            flex: 1;

            min-width: 220px;

        }


        .opcion-operacion input {

            display: none;

        }


        .opcion-operacion label {

            display: block;

            padding: 14px;

            border: 1px solid #ccc;

            border-radius: 7px;

            background: #f8f9fa;

            cursor: pointer;

            text-align: center;

            margin: 0;

        }


        .opcion-operacion input:checked + label {

            border-color: #0d6efd;

            background: #e9f2ff;

            color: #0d6efd;

        }


        /* ==========================================
           RENGLONES
        =========================================== */

        .lista-renglones {

            display: flex;

            flex-direction: column;

            gap: 15px;

        }


        .renglon {

            border: 1px solid #d9dee3;

            border-radius: 10px;

            padding: 18px;

            background: #fafbfc;

            position: relative;

        }


        .encabezado-renglon {

            display: flex;

            align-items: center;

            justify-content: space-between;

            margin-bottom: 15px;

        }


        .numero-renglon {

            font-weight: bold;

            color: #0d6efd;

            font-size: 15px;

        }


        .btn-eliminar-renglon {

            border: none;

            background: #dc3545;

            color: white;

            padding: 7px 12px;

            border-radius: 5px;

            cursor: pointer;

            font-size: 13px;

        }


        .btn-eliminar-renglon:hover {

            background: #bb2d3b;

        }


        .formulario {

            display: grid;

            grid-template-columns: 1fr 1fr;

            gap: 15px;

        }


        .campo {

            display: flex;

            flex-direction: column;

        }


        .campo-completo {

            grid-column: 1 / -1;

        }


        label {

            font-weight: bold;

            margin-bottom: 6px;

        }


        input,
        select {

            padding: 11px;

            border: 1px solid #ccc;

            border-radius: 6px;

            font-size: 15px;

            font-family: Arial, sans-serif;

            width: 100%;

        }


        input:focus,
        select:focus {

            outline: none;

            border-color: #0d6efd;

            box-shadow:
                0 0 0 2px rgba(13,110,253,.10);

        }


        input[readonly] {

            background: #f1f3f5;

            color: #555;

        }


        /* ==========================================
           INFORMACIÓN ARTÍCULO
        =========================================== */

        .informacion-articulo {

            margin-top: 15px;

            padding: 15px;

            background: #f8f9fa;

            border: 1px solid #ddd;

            border-radius: 8px;

        }


        .informacion-articulo h3 {

            margin-top: 0;

            margin-bottom: 15px;

            font-size: 16px;

            color: #212529;

        }


        /* ==========================================
           BOTONES
        =========================================== */

        .botones-renglon {

            margin-top: 15px;

            display: flex;

            justify-content: flex-start;

        }


        .btn-agregar {

            padding: 11px 18px;

            border: 1px dashed #0d6efd;

            border-radius: 6px;

            background: #e9f2ff;

            color: #0d6efd;

            cursor: pointer;

            font-size: 14px;

            font-weight: bold;

        }


        .btn-agregar:hover {

            background: #dceaff;

        }


        .botones {

            margin-top: 25px;

            display: flex;

            gap: 10px;

            flex-wrap: wrap;

        }


        button[type="submit"],
        .cancelar {

            padding: 12px 20px;

            border: none;

            border-radius: 6px;

            text-decoration: none;

            cursor: pointer;

            font-size: 15px;

            font-family: Arial, sans-serif;

        }


        button[type="submit"] {

            background: #198754;

            color: white;

        }


        button[type="submit"]:hover {

            background: #157347;

        }


        .cancelar {

            background: #6c757d;

            color: white;

        }


        .cancelar:hover {

            background: #5a6268;

        }


        /* ==========================================
           ERROR
        =========================================== */

        .error {

            background: #f8d7da;

            color: #842029;

            padding: 12px;

            margin-bottom: 20px;

            border-radius: 6px;

        }


        /* ==========================================
           SECCIONES
        =========================================== */

        .seccion-operacion {

            display: none;

        }


        .seccion-operacion.activa {

            display: block;

        }


        /* ==========================================
           RESPONSIVE
        =========================================== */

        @media (max-width: 850px) {

            .contenido-principal {

                margin-left: 210px;

            }

            .contenedor {

                margin-left: 20px;

                margin-right: 20px;

            }

        }


        @media (max-width: 650px) {

            .contenido-principal {

                margin-left: 0;

            }


            .barra-superior {

                height: auto;

                padding: 15px;

                flex-direction: column;

                align-items: flex-start;

                gap: 8px;

            }


            .contenedor {

                width: 92%;

                margin: 20px auto;

                padding: 20px;

            }


            .formulario {

                grid-template-columns: 1fr;

            }


            .campo-completo {

                grid-column: auto;

            }

        }

    </style>

</head>


<body>


<!-- ==========================================
     MENÚ LATERAL
========================================== -->

<?php include 'menu.php'; ?>


<!-- ==========================================
     CONTENIDO PRINCIPAL
========================================== -->

<main class="contenido-principal">


    <!-- ======================================
         BARRA SUPERIOR
    ======================================= -->

    <header class="barra-superior">

        <div class="titulo-superior">

            📥 Ingreso de artículo

        </div>


        <div class="usuario-superior">

            Usuario:

            <strong>

                <?= htmlspecialchars($nombre_empleado) ?>

            </strong>

        </div>

    </header>


    <!-- ======================================
         CONTENEDOR
    ======================================= -->

    <div class="contenedor">


        <h1>

            📥 Ingreso de artículos

        </h1>


        <p class="descripcion-ayuda">

            Puedes ingresar varios artículos existentes
            o registrar varios artículos nuevos en una sola operación.
            Cada renglón puede tener una cantidad, talla,
            ubicación o descripción diferente.

        </p>


        <!-- ==================================
             ERROR
        =================================== -->

        <?php if ($error !== ""): ?>

            <div class="error">

                ❌

                <?= htmlspecialchars($error) ?>

            </div>

        <?php endif; ?>


        <!-- ==================================
             SELECCIÓN DE OPERACIÓN
        =================================== -->

        <div class="selector-operacion">


            <div class="opcion-operacion">

                <input
                    type="radio"
                    name="tipo_operacion"
                    id="operacion_existente"
                    value="existente"
                    checked
                >

                <label for="operacion_existente">

                    📦 Ingresar artículos existentes

                </label>

            </div>


            <div class="opcion-operacion">

                <input
                    type="radio"
                    name="tipo_operacion"
                    id="operacion_nuevo"
                    value="nuevo"
                >

                <label for="operacion_nuevo">

                    ➕ Registrar artículos nuevos

                </label>

            </div>


        </div>


        <!-- ==================================================
             ==================================================
             ARTÍCULOS EXISTENTES
             ==================================================
             ================================================== -->

        <div
            id="seccion_existente"
            class="seccion-operacion activa"
        >


            <form method="POST" id="form_existentes">


                <input
                    type="hidden"
                    name="accion"
                    value="ingreso_existente"
                >


                <div
                    id="lista_existentes"
                    class="lista-renglones"
                >


                    <!-- ======================================
                         RENGLÓN EXISTENTE INICIAL
                    ======================================= -->

                    <div class="renglon fila-existente">


                        <div class="encabezado-renglon">

                            <span class="numero-renglon">

                                Artículo #1

                            </span>


                            <button
                                type="button"
                                class="btn-eliminar-renglon"
                                onclick="eliminarRenglon(this)"
                                style="display:none;"
                            >

                                🗑️ Eliminar

                            </button>

                        </div>


                        <div class="formulario">


                            <!-- ARTÍCULO -->

                            <div
                                class="campo campo-completo"
                            >

                                <label>

                                    Artículo

                                </label>


                                <select
                                    name="id_articulo[]"
                                    class="selector-articulo"
                                    required
                                >

                                    <option value="">

                                        -- Selecciona un artículo --

                                    </option>


                                    <?php foreach (
                                        $articulos
                                        as $item
                                    ): ?>

                                        <option
                                            value="<?= $item['id'] ?>"
                                            data-descripcion="<?= htmlspecialchars(
                                                $item['articulo_descripcion'],
                                                ENT_QUOTES
                                            ) ?>"
                                            data-ubicacion="<?= htmlspecialchars(
                                                $item['ubicacion'],
                                                ENT_QUOTES
                                            ) ?>"
                                            data-maximo="<?= $item['maximo'] ?>"
                                            data-minimo="<?= $item['minimo'] ?>"
                                            data-proveedor="<?= htmlspecialchars(
                                                $item['proveedor_marca'],
                                                ENT_QUOTES
                                            ) ?>"
                                        >

                                            <?= htmlspecialchars(
                                                $item['codigo']
                                            ) ?>

                                            -

                                            <?= htmlspecialchars(
                                                $item['articulo_descripcion']
                                            ) ?>

                                        </option>

                                    <?php endforeach; ?>

                                </select>

                            </div>


                            <!-- CANTIDAD -->

                            <div
                                class="campo"
                            >

                                <label>

                                    Cantidad a ingresar

                                </label>


                                <input
                                    type="number"
                                    name="cantidad[]"
                                    min="1"
                                    value="1"
                                    required
                                >

                            </div>


                            <!-- UBICACIÓN -->

                            <div
                                class="campo"
                            >

                                <label>

                                    Nueva ubicación

                                </label>


                                <select
                                    name="ubicacion[]"
                                    class="selector-ubicacion"
                                >

                                    <option value="">

                                        -- Conservar ubicación actual --

                                    </option>


                                    <?php

                                    $tipo_actual = "";

                                    foreach (
                                        $ubicaciones
                                        as $ubicacion_item
                                    ):

                                        if (
                                            $tipo_actual !==
                                            $ubicacion_item["tipo"]
                                        ):

                                            if (
                                                $tipo_actual !== ""
                                            ):

                                    ?>

                                                </optgroup>

                                    <?php

                                            endif;

                                            $tipo_actual =
                                                $ubicacion_item["tipo"];

                                    ?>

                                            <optgroup
                                                label="<?= htmlspecialchars(
                                                    $tipo_actual
                                                ) ?>"
                                            >

                                    <?php

                                        endif;

                                    ?>

                                        <option
                                            value="<?= htmlspecialchars(
                                                $ubicacion_item["codigo"],
                                                ENT_QUOTES
                                            ) ?>"
                                        >

                                            <?= htmlspecialchars(
                                                $ubicacion_item["codigo"]
                                            ) ?>

                                            <?php if (
                                                !empty(
                                                    $ubicacion_item["descripcion"]
                                                )
                                            ): ?>

                                                -

                                                <?= htmlspecialchars(
                                                    $ubicacion_item["descripcion"]
                                                ) ?>

                                            <?php endif; ?>

                                        </option>


                                    <?php endforeach; ?>


                                    <?php if (
                                        $tipo_actual !== ""
                                    ): ?>

                                        </optgroup>

                                    <?php endif; ?>

                                </select>

                            </div>


                            <!-- INFORMACIÓN -->

                            <div
                                class="informacion-articulo campo-completo"
                            >

                                <h3>

                                    Información del artículo

                                </h3>


                                <div class="formulario">


                                    <div
                                        class="campo campo-completo"
                                    >

                                        <label>

                                            Artículo / Descripción

                                        </label>


                                        <input
                                            type="text"
                                            class="articulo-descripcion"
                                            readonly
                                            placeholder="Se llenará automáticamente"
                                        >

                                    </div>


                                    <div class="campo">

                                        <label>

                                            Ubicación actual

                                        </label>


                                        <input
                                            type="text"
                                            class="ubicacion-actual"
                                            readonly
                                        >

                                    </div>


                                    <div class="campo">

                                        <label>

                                            Máximo

                                        </label>


                                        <input
                                            type="number"
                                            class="maximo"
                                            readonly
                                        >

                                    </div>


                                    <div class="campo">

                                        <label>

                                            Mínimo

                                        </label>


                                        <input
                                            type="number"
                                            class="minimo"
                                            readonly
                                        >

                                    </div>


                                    <div
                                        class="campo campo-completo"
                                    >

                                        <label>

                                            Proveedor / Marca

                                        </label>


                                        <input
                                            type="text"
                                            class="proveedor-marca"
                                            readonly
                                        >

                                    </div>


                                </div>

                            </div>


                        </div>

                    </div>


                </div>


                <!-- ======================================
                     AGREGAR OTRO
                ======================================= -->

                <div class="botones-renglon">

                    <button
                        type="button"
                        class="btn-agregar"
                        onclick="agregarExistente()"
                    >

                        ➕ Agregar otro artículo

                    </button>

                </div>


                <!-- ======================================
                     BOTONES
                ======================================= -->

                <div class="botones">

                    <button type="submit">

                        💾 Registrar todos los ingresos

                    </button>


                    <a
                        href="index.php"
                        class="cancelar"
                    >

                        ↩️ Volver al inventario

                    </a>

                </div>


            </form>

        </div>


        <!-- ==================================================
             ==================================================
             ARTÍCULOS NUEVOS
             ==================================================
             ================================================== -->

        <div
            id="seccion_nuevo"
            class="seccion-operacion"
        >


            <form method="POST" id="form_nuevos">


                <input
                    type="hidden"
                    name="accion"
                    value="nuevo_articulo"
                >


                <div
                    id="lista_nuevos"
                    class="lista-renglones"
                >


                    <!-- ======================================
                         RENGLÓN NUEVO INICIAL
                    ======================================= -->

                    <div class="renglon fila-nuevo">


                        <div class="encabezado-renglon">

                            <span class="numero-renglon">

                                Artículo nuevo #1

                            </span>


                            <button
                                type="button"
                                class="btn-eliminar-renglon"
                                onclick="eliminarRenglon(this)"
                                style="display:none;"
                            >

                                🗑️ Eliminar

                            </button>

                        </div>


                        <div class="formulario">


                            <!-- CÓDIGO -->

                            <div class="campo">

                                <label>

                                    Código

                                </label>


                                <input
                                    type="text"
                                    name="codigo_nuevo[]"
                                    maxlength="100"
                                    required
                                >

                            </div>


                            <!-- CANTIDAD -->

                            <div class="campo">

                                <label>

                                    Cantidad inicial

                                </label>


                                <input
                                    type="number"
                                    name="cantidad_nueva[]"
                                    min="0"
                                    value="0"
                                    required
                                >

                            </div>


                            <!-- DESCRIPCIÓN -->

                            <div
                                class="campo campo-completo"
                            >

                                <label>

                                    Artículo / Descripción

                                </label>


                                <input
                                    type="text"
                                    name="descripcion_nueva[]"
                                    maxlength="255"
                                    required
                                >

                            </div>


                            <!-- UBICACIÓN -->

                            <div
                                class="campo campo-completo"
                            >

                                <label>

                                    Ubicación

                                </label>


                                <select
                                    name="ubicacion_nueva[]"
                                >

                                    <option value="">

                                        -- Sin ubicación --

                                    </option>


                                    <?php

                                    $tipo_actual_nuevo = "";

                                    foreach (
                                        $ubicaciones
                                        as $ubicacion_item
                                    ):

                                        if (
                                            $tipo_actual_nuevo !==
                                            $ubicacion_item["tipo"]
                                        ):

                                            if (
                                                $tipo_actual_nuevo !== ""
                                            ):

                                    ?>

                                                </optgroup>

                                    <?php

                                            endif;

                                            $tipo_actual_nuevo =
                                                $ubicacion_item["tipo"];

                                    ?>

                                            <optgroup
                                                label="<?= htmlspecialchars(
                                                    $tipo_actual_nuevo
                                                ) ?>"
                                            >

                                    <?php

                                        endif;

                                    ?>

                                        <option
                                            value="<?= htmlspecialchars(
                                                $ubicacion_item["codigo"],
                                                ENT_QUOTES
                                            ) ?>"
                                        >

                                            <?= htmlspecialchars(
                                                $ubicacion_item["codigo"]
                                            ) ?>

                                            <?php if (
                                                !empty(
                                                    $ubicacion_item["descripcion"]
                                                )
                                            ): ?>

                                                -

                                                <?= htmlspecialchars(
                                                    $ubicacion_item["descripcion"]
                                                ) ?>

                                            <?php endif; ?>

                                        </option>


                                    <?php endforeach; ?>


                                    <?php if (
                                        $tipo_actual_nuevo !== ""
                                    ): ?>

                                        </optgroup>

                                    <?php endif; ?>

                                </select>

                            </div>


                            <!-- MÁXIMO -->

                            <div class="campo">

                                <label>

                                    Máximo

                                </label>


                                <input
                                    type="number"
                                    name="maximo_nuevo[]"
                                    min="0"
                                    value="0"
                                >

                            </div>


                            <!-- MÍNIMO -->

                            <div class="campo">

                                <label>

                                    Mínimo

                                </label>


                                <input
                                    type="number"
                                    name="minimo_nuevo[]"
                                    min="0"
                                    value="0"
                                >

                            </div>


                            <!-- PROVEEDOR -->

                            <div
                                class="campo campo-completo"
                            >

                                <label>

                                    Proveedor / Marca

                                </label>


                                <input
                                    type="text"
                                    name="proveedor_nuevo[]"
                                    maxlength="255"
                                >

                            </div>


                        </div>

                    </div>


                </div>


                <!-- ======================================
                     AGREGAR OTRO
                ======================================= -->

                <div class="botones-renglon">

                    <button
                        type="button"
                        class="btn-agregar"
                        onclick="agregarNuevo()"
                    >

                        ➕ Agregar otro artículo nuevo

                    </button>

                </div>


                <!-- ======================================
                     BOTONES
                ======================================= -->

                <div class="botones">

                    <button type="submit">

                        💾 Registrar todos los artículos

                    </button>


                    <a
                        href="index.php"
                        class="cancelar"
                    >

                        ↩️ Volver al inventario

                    </a>

                </div>


            </form>

        </div>


    </div>


</main>


<!-- ==========================================
     JAVASCRIPT
========================================== -->

<script>


// ==================================================
// SELECTORES PRINCIPALES
// ==================================================

const operacionExistente =
    document.getElementById(
        "operacion_existente"
    );

const operacionNuevo =
    document.getElementById(
        "operacion_nuevo"
    );

const seccionExistente =
    document.getElementById(
        "seccion_existente"
    );

const seccionNuevo =
    document.getElementById(
        "seccion_nuevo"
    );


// ==================================================
// CAMBIAR OPERACIÓN
// ==================================================

operacionExistente.addEventListener(
    "change",
    function () {

        if (this.checked) {

            seccionExistente.classList.add(
                "activa"
            );

            seccionNuevo.classList.remove(
                "activa"
            );

        }

    }
);


operacionNuevo.addEventListener(
    "change",
    function () {

        if (this.checked) {

            seccionNuevo.classList.add(
                "activa"
            );

            seccionExistente.classList.remove(
                "activa"
            );

        }

    }
);


// ==================================================
// ACTUALIZAR INFORMACIÓN DE UN ARTÍCULO EXISTENTE
// ==================================================

function actualizarInformacionArticulo(renglon) {


    const selector =
        renglon.querySelector(
            ".selector-articulo"
        );


    const descripcion =
        renglon.querySelector(
            ".articulo-descripcion"
        );


    const ubicacionActual =
        renglon.querySelector(
            ".ubicacion-actual"
        );


    const maximo =
        renglon.querySelector(
            ".maximo"
        );


    const minimo =
        renglon.querySelector(
            ".minimo"
        );


    const proveedor =
        renglon.querySelector(
            ".proveedor-marca"
        );


    if (!selector) {

        return;

    }


    const opcion =
        selector.options[
            selector.selectedIndex
        ];


    if (!selector.value) {

        descripcion.value = "";

        ubicacionActual.value = "";

        maximo.value = "";

        minimo.value = "";

        proveedor.value = "";

        return;

    }


    descripcion.value =
        opcion.dataset.descripcion || "";


    ubicacionActual.value =
        opcion.dataset.ubicacion || "";


    maximo.value =
        opcion.dataset.maximo || "0";


    minimo.value =
        opcion.dataset.minimo || "0";


    proveedor.value =
        opcion.dataset.proveedor || "";

}


// ==================================================
// EVENTO PARA SELECTORES EXISTENTES
// ==================================================

function prepararRenglonExistente(renglon) {


    const selector =
        renglon.querySelector(
            ".selector-articulo"
        );


    if (!selector) {

        return;

    }


    selector.addEventListener(
        "change",
        function () {

            actualizarInformacionArticulo(
                renglon
            );

        }
    );

}


// ==================================================
// PREPARAR RENGLONES EXISTENTES INICIALES
// ==================================================

document
    .querySelectorAll(
        ".fila-existente"
    )
    .forEach(
        function (renglon) {

            prepararRenglonExistente(
                renglon
            );

        }
    );


// ==================================================
// ACTUALIZAR NÚMEROS DE RENGLONES
// ==================================================

function actualizarNumerosExistentes() {


    const renglones =
        document.querySelectorAll(
            "#lista_existentes .fila-existente"
        );


    renglones.forEach(
        function (renglon, indice) {

            const numero =
                renglon.querySelector(
                    ".numero-renglon"
                );


            if (numero) {

                numero.textContent =
                    "Artículo #"
                    + (indice + 1);

            }

        }
    );


    actualizarBotonesEliminar(
        "#lista_existentes .fila-existente"
    );

}


// ==================================================
// NÚMEROS DE ARTÍCULOS NUEVOS
// ==================================================

function actualizarNumerosNuevos() {


    const renglones =
        document.querySelectorAll(
            "#lista_nuevos .fila-nuevo"
        );


    renglones.forEach(
        function (renglon, indice) {

            const numero =
                renglon.querySelector(
                    ".numero-renglon"
                );


            if (numero) {

                numero.textContent =
                    "Artículo nuevo #"
                    + (indice + 1);

            }

        }
    );


    actualizarBotonesEliminar(
        "#lista_nuevos .fila-nuevo"
    );

}


// ==================================================
// MOSTRAR / OCULTAR ELIMINAR
// ==================================================

function actualizarBotonesEliminar(selector) {


    const renglones =
        document.querySelectorAll(
            selector
        );


    renglones.forEach(
        function (renglon) {

            const boton =
                renglon.querySelector(
                    ".btn-eliminar-renglon"
                );


            if (!boton) {

                return;

            }


            if (renglones.length > 1) {

                boton.style.display =
                    "inline-block";

            } else {

                boton.style.display =
                    "none";

            }

        }
    );

}


// ==================================================
// AGREGAR ARTÍCULO EXISTENTE
// ==================================================

function agregarExistente() {


    const lista =
        document.getElementById(
            "lista_existentes"
        );


    const original =
        lista.querySelector(
            ".fila-existente"
        );


    const nuevo =
        original.cloneNode(true);


    // ==============================================
    // LIMPIAR SELECTOR
    // ==============================================

    const selector =
        nuevo.querySelector(
            ".selector-articulo"
        );


    if (selector) {

        selector.value = "";

    }


    // ==============================================
    // LIMPIAR CANTIDAD
    // ==============================================

    const cantidad =
        nuevo.querySelector(
            'input[name="cantidad[]"]'
        );


    if (cantidad) {

        cantidad.value = "1";

    }


    // ==============================================
    // LIMPIAR UBICACIÓN
    // ==============================================

    const ubicacion =
        nuevo.querySelector(
            ".selector-ubicacion"
        );


    if (ubicacion) {

        ubicacion.value = "";

    }


    // ==============================================
    // LIMPIAR INFORMACIÓN
    // ==============================================

    const descripcion =
        nuevo.querySelector(
            ".articulo-descripcion"
        );


    const ubicacionActual =
        nuevo.querySelector(
            ".ubicacion-actual"
        );


    const maximo =
        nuevo.querySelector(
            ".maximo"
        );


    const minimo =
        nuevo.querySelector(
            ".minimo"
        );


    const proveedor =
        nuevo.querySelector(
            ".proveedor-marca"
        );


    if (descripcion) {

        descripcion.value = "";

    }


    if (ubicacionActual) {

        ubicacionActual.value = "";

    }


    if (maximo) {

        maximo.value = "";

    }


    if (minimo) {

        minimo.value = "";

    }


    if (proveedor) {

        proveedor.value = "";

    }


    // ==============================================
    // AGREGAR
    // ==============================================

    lista.appendChild(
        nuevo
    );


    prepararRenglonExistente(
        nuevo
    );


    actualizarNumerosExistentes();

}


// ==================================================
// AGREGAR ARTÍCULO NUEVO
// ==================================================

function agregarNuevo() {


    const lista =
        document.getElementById(
            "lista_nuevos"
        );


    const original =
        lista.querySelector(
            ".fila-nuevo"
        );


    const nuevo =
        original.cloneNode(true);


    // ==============================================
    // LIMPIAR INPUTS
    // ==============================================

    nuevo
        .querySelectorAll(
            "input"
        )
        .forEach(
            function (input) {

                if (
                    input.name ===
                    "cantidad_nueva[]"
                ) {

                    input.value = "0";

                } else {

                    input.value = "";

                }

            }
        );


    // ==============================================
    // LIMPIAR SELECT
    // ==============================================

    nuevo
        .querySelectorAll(
            "select"
        )
        .forEach(
            function (select) {

                select.value = "";

            }
        );


    // ==============================================
    // AGREGAR
    // ==============================================

    lista.appendChild(
        nuevo
    );


    actualizarNumerosNuevos();

}


// ==================================================
// ELIMINAR RENGLÓN
// ==================================================

function eliminarRenglon(boton) {


    const renglon =
        boton.closest(
            ".renglon"
        );


    if (!renglon) {

        return;

    }


    const lista =
        renglon.parentElement;


    const renglones =
        lista.querySelectorAll(
            ".renglon"
        );


    if (renglones.length <= 1) {

        return;

    }


    renglon.remove();


    if (
        lista.id ===
        "lista_existentes"
    ) {

        actualizarNumerosExistentes();

    } else {

        actualizarNumerosNuevos();

    }

}


// ==================================================
// INICIALIZAR BOTONES
// ==================================================

actualizarNumerosExistentes();

actualizarNumerosNuevos();

</script>


</body>

</html>
