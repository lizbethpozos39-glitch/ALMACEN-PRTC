<?php
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

require "conexion.php";


// =====================================================
// FILTROS
// =====================================================

$buscar = trim($_GET["buscar"] ?? "");

$tipo = trim($_GET["tipo"] ?? "");

$fecha_desde = trim($_GET["fecha_desde"] ?? "");

$fecha_hasta = trim($_GET["fecha_hasta"] ?? "");


// =====================================================
// CONSULTA BASE
// =====================================================

$sql = "
    SELECT

        m.id AS movimiento_id,

        m.tipo,

        m.cantidad,

        m.cantidad_anterior,

        m.cantidad_nueva,

        m.observaciones,

        m.fecha_movimiento,

        i.codigo,

        i.articulo_descripcion,

        i.ubicacion,

        i.proveedor_marca,

        f.numero_factura,

        f.nombre_emisor

    FROM movimientos_inventario m

    INNER JOIN inventario i
        ON i.id = m.inventario_id

    LEFT JOIN facturas f
        ON f.id = m.factura_id

    WHERE 1=1
";


// =====================================================
// PARÁMETROS
// =====================================================

$parametros = [];

$tipos = "";


// =====================================================
// BUSCADOR
// =====================================================

if ($buscar !== "") {

    $sql .= "
        AND (
            i.codigo LIKE ?
            OR i.articulo_descripcion LIKE ?
            OR i.proveedor_marca LIKE ?
            OR f.numero_factura LIKE ?
            OR f.nombre_emisor LIKE ?
        )
    ";

    $texto = "%" . $buscar . "%";

    $parametros[] = $texto;
    $parametros[] = $texto;
    $parametros[] = $texto;
    $parametros[] = $texto;
    $parametros[] = $texto;

    $tipos .= "sssss";
}


// =====================================================
// FILTRO TIPO
// =====================================================

if ($tipo !== "") {

    $sql .= "
        AND m.tipo = ?
    ";

    $parametros[] = $tipo;

    $tipos .= "s";
}


// =====================================================
// FECHA DESDE
// =====================================================

if ($fecha_desde !== "") {

    $sql .= "
        AND DATE(m.fecha_movimiento) >= ?
    ";

    $parametros[] = $fecha_desde;

    $tipos .= "s";
}


// =====================================================
// FECHA HASTA
// =====================================================

if ($fecha_hasta !== "") {

    $sql .= "
        AND DATE(m.fecha_movimiento) <= ?
    ";

    $parametros[] = $fecha_hasta;

    $tipos .= "s";
}


// =====================================================
// ORDEN
// =====================================================

$sql .= "
    ORDER BY m.fecha_movimiento DESC,
             m.id DESC
";


// =====================================================
// PREPARAR
// =====================================================

$stmt = $conexion->prepare($sql);


if (!$stmt) {

    die(
        "Error en la consulta: "
        . $conexion->error
    );

}


// =====================================================
// ASIGNAR PARÁMETROS
// =====================================================

if (!empty($parametros)) {

    $stmt->bind_param(
        $tipos,
        ...$parametros
    );

}


// =====================================================
// EJECUTAR
// =====================================================

$stmt->execute();

$resultado = $stmt->get_result();


// =====================================================
// TOTAL DE MOVIMIENTOS
// =====================================================

$total_movimientos =
    $resultado->num_rows;

?>


<?php require "header.php"; ?>


<style>

/* =====================================================
   CONTENEDOR
===================================================== */

.contenedor-historial {

    background: white;

    padding: 20px;

    border-radius: 10px;

    box-shadow:
        0 2px 10px rgba(0,0,0,.10);

}


/* =====================================================
   FILTROS
===================================================== */

.filtros {

    display: grid;

    grid-template-columns:
        2fr
        1fr
        1fr
        1fr
        auto;

    gap: 10px;

    margin-bottom: 20px;

}


.filtros input,
.filtros select {

    padding: 10px;

    border: 1px solid #ccc;

    border-radius: 5px;

}


/* =====================================================
   BOTONES
===================================================== */

.boton {

    border: none;

    padding: 10px 15px;

    border-radius: 5px;

    cursor: pointer;

    text-decoration: none;

    display: inline-block;

}


.buscar {

    background: #0d6efd;

    color: white;

}


.limpiar {

    background: #6c757d;

    color: white;

}


/* =====================================================
   TABLA
===================================================== */

.tabla-contenedor {

    overflow-x: auto;

}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 1300px;

}


th {

    background: #212529;

    color: white;

    padding: 10px;

    text-align: left;

}


td {

    padding: 9px;

    border-bottom: 1px solid #ddd;

}


tr:hover {

    background: #f5f5f5;

}


/* =====================================================
   TIPOS
===================================================== */

.entrada {

    color: #198754;

    font-weight: bold;

}


.salida {

    color: #dc3545;

    font-weight: bold;

}


/* =====================================================
   CANTIDADES
===================================================== */

.cantidad {

    text-align: right;

    font-weight: bold;

}


/* =====================================================
   RESUMEN
===================================================== */

.resumen {

    background: #e9ecef;

    padding: 12px;

    border-radius: 5px;

    margin-bottom: 15px;

}


/* =====================================================
   RESPONSIVE
===================================================== */

@media(max-width:900px) {

    .filtros {

        grid-template-columns: 1fr;

    }

}

</style>


<h1>📋 Historial de movimientos</h1>


<div class="contenedor-historial">


    <!-- =================================================
         FILTROS
    ================================================== -->

    <form
        method="GET"
        class="filtros">


        <input
            type="text"
            name="buscar"
            placeholder="Código, descripción, proveedor o factura..."
            value="<?= htmlspecialchars($buscar) ?>">


        <select name="tipo">

            <option value="">
                Todos los movimientos
            </option>

            <option
                value="ENTRADA"
                <?= $tipo === "ENTRADA"
                    ? "selected"
                    : "" ?>>

                Entradas

            </option>

            <option
                value="SALIDA"
                <?= $tipo === "SALIDA"
                    ? "selected"
                    : "" ?>>

                Salidas

            </option>

        </select>


        <input
            type="date"
            name="fecha_desde"
            value="<?= htmlspecialchars($fecha_desde) ?>">


        <input
            type="date"
            name="fecha_hasta"
            value="<?= htmlspecialchars($fecha_hasta) ?>">


        <button
            type="submit"
            class="boton buscar">

            🔎 Buscar

        </button>


    </form>


    <a
        href="historial_movimientos.php"
        class="boton limpiar">

        ↻ Limpiar filtros

    </a>


    <br><br>


    <!-- =================================================
         RESUMEN
    ================================================== -->

    <div class="resumen">

        📊 Movimientos encontrados:

        <strong>
            <?= $total_movimientos ?>
        </strong>

    </div>


    <!-- =================================================
         TABLA
    ================================================== -->

    <div class="tabla-contenedor">


        <table>


            <thead>

                <tr>

                    <th>
                        Fecha
                    </th>

                    <th>
                        Código
                    </th>

                    <th>
                        Descripción
                    </th>

                    <th>
                        Tipo
                    </th>

                    <th>
                        Cantidad
                    </th>

                    <th>
                        Cantidad anterior
                    </th>

                    <th>
                        Cantidad nueva
                    </th>

                    <th>
                        Ubicación
                    </th>

                    <th>
                        Proveedor
                    </th>

                    <th>
                        Factura
                    </th>

                    <th>
                        Observaciones
                    </th>

                </tr>

            </thead>


            <tbody>


            <?php if ($resultado->num_rows > 0): ?>


                <?php while ($mov = $resultado->fetch_assoc()): ?>


                    <tr>


                        <td>

                            <?= htmlspecialchars(
                                $mov["fecha_movimiento"]
                            ) ?>

                        </td>


                        <td>

                            <strong>

                                <?= htmlspecialchars(
                                    $mov["codigo"]
                                ) ?>

                            </strong>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $mov["articulo_descripcion"]
                            ) ?>

                        </td>


                        <td>

                            <?php if (
                                strtoupper($mov["tipo"])
                                === "ENTRADA"
                            ): ?>

                                <span class="entrada">

                                    🟢 ENTRADA

                                </span>

                            <?php else: ?>

                                <span class="salida">

                                    🔴 SALIDA

                                </span>

                            <?php endif; ?>

                        </td>


                        <td class="cantidad">

                            <?= number_format(
                                $mov["cantidad"],
                                3
                            ) ?>

                        </td>


                        <td class="cantidad">

                            <?= number_format(
                                $mov["cantidad_anterior"],
                                3
                            ) ?>

                        </td>


                        <td class="cantidad">

                            <?= number_format(
                                $mov["cantidad_nueva"],
                                3
                            ) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $mov["ubicacion"] ?? ""
                            ) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $mov["proveedor_marca"] ?? ""
                            ) ?>


                            <?php if (
                                !empty($mov["nombre_emisor"])
                            ): ?>

                                <br>

                                <small>

                                    <?= htmlspecialchars(
                                        $mov["nombre_emisor"]
                                    ) ?>

                                </small>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?php if (
                                !empty($mov["numero_factura"])
                            ): ?>

                                <?= htmlspecialchars(
                                    $mov["numero_factura"]
                                ) ?>

                            <?php else: ?>

                                <span style="color:#999;">
                                    Sin factura
                                </span>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $mov["observaciones"] ?? ""
                            ) ?>

                        </td>


                    </tr>


                <?php endwhile; ?>


            <?php else: ?>


                <tr>

                    <td
                        colspan="11"
                        style="
                            text-align:center;
                            padding:30px;
                        ">

                        📭 No se encontraron movimientos.

                    </td>

                </tr>


            <?php endif; ?>


            </tbody>


        </table>


    </div>


</div>


<?php

$stmt->close();

?>


<?php require "footer.php"; ?>
