<?php

/*
|--------------------------------------------------------------------------
| Seguridad del encabezado
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Datos del usuario
|--------------------------------------------------------------------------
*/

$usuario_logueado = isset($_SESSION['usuario_id']);

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';

$rol_usuario = $_SESSION['rol'] ?? 'USUARIO';

?>

<!DOCTYPE html>

<html lang="es">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>

* {
    box-sizing: border-box;
}

body {

    margin: 0;

    font-family: Arial, sans-serif;

    background: #f4f6f8;

    color: #333;
}

.barra-superior {

    background: #212529;

    color: white;

    padding: 12px 30px;

    display: flex;

    justify-content: space-between;

    align-items: center;

    flex-wrap: wrap;

    gap: 15px;
}

.titulo-sistema {

    font-size: 20px;

    font-weight: bold;

    white-space: nowrap;
}

.menu {

    display: flex;

    gap: 8px;

    flex-wrap: wrap;

    align-items: center;
}

.menu a {

    color: white;

    text-decoration: none;

    padding: 8px 12px;

    border-radius: 5px;

    font-size: 14px;

    background: #343a40;
}

.menu a:hover {

    background: #495057;
}

.menu .administracion {

    background: #6f42c1;
}

.menu .administracion:hover {

    background: #5a32a3;
}

.usuario-conectado {

    display: flex;

    align-items: center;

    gap: 10px;

    padding-left: 10px;

    border-left: 1px solid #495057;

    font-size: 13px;
}

.usuario-info {

    display: flex;

    flex-direction: column;

    line-height: 1.3;
}

.usuario-nombre {

    font-weight: bold;

    color: #fff;
}

.usuario-rol {

    font-size: 11px;

    color: #ced4da;
}

.boton-salir {

    background: #dc3545 !important;
}

.boton-salir:hover {

    background: #bb2d3b !important;
}

.pagina {

    width: 95%;

    max-width: 1400px;

    margin: 30px auto;
}

</style>

</head>

<body>

<header class="barra-superior">

    <div class="titulo-sistema">
        📦 Sistema de Almacén
    </div>


    <nav class="menu">

        <a href="index.php">
            📋 Inventario
        </a>

        <a href="nuevo_articulo.php">
            ➕ Nuevo artículo
        </a>

        <a href="entrada.php">
            📥 Entrada
        </a>

        <a href="salida_almacen.php">
            📤 Salida
        </a>

        <a href="facturas.php">
            📄 Facturas
        </a>

        <a href="historial_movimientos.php">
            📋 Historial
        </a>

        <a href="panel.php">
            📊 Panel
        </a>

        <a href="empleados_areas.php">
            👥 Empleados
        </a>


        <?php if ($rol_usuario === 'ADMIN'): ?>

            <a
                href="admin_panel.php"
                class="administracion"
            >
                ⚙️ Administración
            </a>

        <?php endif; ?>


        <div class="usuario-conectado">

            <div class="usuario-info">

                <span class="usuario-nombre">

                    👤 <?= htmlspecialchars($nombre_empleado) ?>

                </span>

                <span class="usuario-rol">

                    <?= htmlspecialchars($rol_usuario) ?>

                </span>

            </div>


            <a
                href="logout.php"
                class="boton-salir"
            >
                🚪 Salir
            </a>

        </div>

    </nav>

</header>

<div class="pagina">
