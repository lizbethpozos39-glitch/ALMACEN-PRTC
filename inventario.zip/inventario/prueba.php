<?php

require "vendor/autoload.php";

echo "PhpSpreadsheet funciona correctamente.";

?>
