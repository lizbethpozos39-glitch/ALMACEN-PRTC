<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();


/*
|--------------------------------------------------------------------------
| FILTROS
|--------------------------------------------------------------------------
*/

$descripcion = $_GET["descripcion"] ?? "";
$cantidad    = $_GET["cantidad"] ?? "";
$ubicacion   = $_GET["ubicacion"] ?? "";
$maximo      = $_GET["maximo"] ?? "";
$minimo      = $_GET["minimo"] ?? "";
$proveedor   = $_GET["proveedor"] ?? "";


/*
|--------------------------------------------------------------------------
| CONSULTA
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        id,
        codigo,
        articulo_descripcion,
        cantidad,
        ubicacion,
        maximo,
        minimo,
        proveedor_marca
    FROM inventario
    WHERE 1=1
";

$tipos = "";
$valores = [];


/*
|--------------------------------------------------------------------------
| FILTRO DESCRIPCIÓN
|--------------------------------------------------------------------------
*/

if ($descripcion !== "") {

    $sql .= " AND articulo_descripcion LIKE ?";
    $tipos .= "s";
    $valores[] = "%" . $descripcion . "%";

}


/*
|--------------------------------------------------------------------------
| FILTRO CANTIDAD
|--------------------------------------------------------------------------
*/

if ($cantidad !== "") {

    $sql .= " AND cantidad = ?";
    $tipos .= "i";
    $valores[] = (int)$cantidad;

}


/*
|--------------------------------------------------------------------------
| FILTRO UBICACIÓN
|--------------------------------------------------------------------------
*/

if ($ubicacion !== "") {

    $sql .= " AND ubicacion LIKE ?";
    $tipos .= "s";
    $valores[] = "%" . $ubicacion . "%";

}


/*
|--------------------------------------------------------------------------
| FILTRO MÁXIMO
|--------------------------------------------------------------------------
*/

if ($maximo !== "") {

    $sql .= " AND maximo = ?";
    $tipos .= "i";
    $valores[] = (int)$maximo;

}


/*
|--------------------------------------------------------------------------
| FILTRO MÍNIMO
|--------------------------------------------------------------------------
*/

if ($minimo !== "") {

    $sql .= " AND minimo = ?";
    $tipos .= "i";
    $valores[] = (int)$minimo;

}


/*
|--------------------------------------------------------------------------
| FILTRO PROVEEDOR / MARCA
|--------------------------------------------------------------------------
*/

if ($proveedor !== "") {

    $sql .= " AND proveedor_marca LIKE ?";
    $tipos .= "s";
    $valores[] = "%" . $proveedor . "%";

}


/*
|--------------------------------------------------------------------------
| ORDEN
|--------------------------------------------------------------------------
*/

$sql .= " ORDER BY id DESC";


/*
|--------------------------------------------------------------------------
| PREPARAR
|--------------------------------------------------------------------------
*/

$stmt = $conexion->prepare($sql);

if (!$stmt) {

    die(
        "Error al preparar la consulta: " .
        $conexion->error
    );

}


/*
|--------------------------------------------------------------------------
| PARÁMETROS
|--------------------------------------------------------------------------
*/

if (!empty($valores)) {

    $stmt->bind_param(
        $tipos,
        ...$valores
    );

}


/*
|--------------------------------------------------------------------------
| EJECUTAR
|--------------------------------------------------------------------------
*/

if (!$stmt->execute()) {

    die(
        "Error al ejecutar la consulta: " .
        $stmt->error
    );

}


$resultado = $stmt->get_result();


/*
|--------------------------------------------------------------------------
| VERIFICAR ZIP
|--------------------------------------------------------------------------
*/

if (!class_exists('ZipArchive')) {

    $stmt->close();
    $conexion->close();

    die(
        "ERROR: La extensión ZipArchive de PHP no está habilitada. " .
        "Es necesaria para generar archivos Excel .xlsx."
    );

}


/*
|--------------------------------------------------------------------------
| FUNCIÓN PARA LIMPIAR XML
|--------------------------------------------------------------------------
*/

function escapar_xml($valor)
{

    if ($valor === null) {

        return "";

    }

    $valor = (string)$valor;


    /*
    |--------------------------------------------------------------------------
    | Eliminar caracteres no permitidos por XML 1.0
    |--------------------------------------------------------------------------
    */

    $valor = preg_replace(
        '/[^\x09\x0A\x0D\x20-\x7E\x80-\x{10FFFF}]/u',
        '',
        $valor
    );


    /*
    |--------------------------------------------------------------------------
    | Si hubo algún problema con UTF-8
    |--------------------------------------------------------------------------
    */

    if ($valor === null) {

        $valor = "";

    }


    /*
    |--------------------------------------------------------------------------
    | Escapar caracteres especiales
    |--------------------------------------------------------------------------
    */

    return htmlspecialchars(
        $valor,
        ENT_XML1 | ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );

}


/*
|--------------------------------------------------------------------------
| ARCHIVO TEMPORAL
|--------------------------------------------------------------------------
*/

$archivoTemporal = tempnam(
    sys_get_temp_dir(),
    'inventario_'
);


if ($archivoTemporal === false) {

    $stmt->close();
    $conexion->close();

    die(
        "No fue posible crear el archivo temporal."
    );

}


/*
|--------------------------------------------------------------------------
| CREAR ZIP
|--------------------------------------------------------------------------
*/

$zip = new ZipArchive();

$abrirZip = $zip->open(
    $archivoTemporal,
    ZipArchive::OVERWRITE
);


if ($abrirZip !== true) {

    unlink($archivoTemporal);

    $stmt->close();
    $conexion->close();

    die(
        "No fue posible crear el archivo Excel."
    );

}


/*
|--------------------------------------------------------------------------
| [Content_Types].xml
|--------------------------------------------------------------------------
*/

$contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">

<Default
    Extension="rels"
    ContentType="application/vnd.openxmlformats-package.relationships+xml"/>

<Default
    Extension="xml"
    ContentType="application/xml"/>

<Override
    PartName="/xl/workbook.xml"
    ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>

<Override
    PartName="/xl/worksheets/sheet1.xml"
    ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>

<Override
    PartName="/xl/styles.xml"
    ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>

</Types>';


$zip->addFromString(
    '[Content_Types].xml',
    $contentTypes
);


/*
|--------------------------------------------------------------------------
| _rels/.rels
|--------------------------------------------------------------------------
*/

$rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships
    xmlns="http://schemas.openxmlformats.org/package/2006/relationships">

<Relationship
    Id="rId1"
    Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
    Target="xl/workbook.xml"/>

</Relationships>';


$zip->addFromString(
    '_rels/.rels',
    $rels
);


/*
|--------------------------------------------------------------------------
| xl/_rels/workbook.xml.rels
|--------------------------------------------------------------------------
*/

$workbookRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships
    xmlns="http://schemas.openxmlformats.org/package/2006/relationships">

<Relationship
    Id="rId1"
    Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"
    Target="worksheets/sheet1.xml"/>

<Relationship
    Id="rId2"
    Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles"
    Target="styles.xml"/>

</Relationships>';


$zip->addFromString(
    'xl/_rels/workbook.xml.rels',
    $workbookRels
);


/*
|--------------------------------------------------------------------------
| xl/workbook.xml
|--------------------------------------------------------------------------
*/

$workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook
    xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">

<sheets>

<sheet
    name="Inventario"
    sheetId="1"
    r:id="rId1"/>

</sheets>

</workbook>';


$zip->addFromString(
    'xl/workbook.xml',
    $workbook
);


/*
|--------------------------------------------------------------------------
| xl/styles.xml
|--------------------------------------------------------------------------
*/

$styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>

<styleSheet
    xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">

<numFmts count="0"/>

<fonts count="2">

<font>
    <sz val="11"/>
    <name val="Calibri"/>
</font>

<font>
    <b/>
    <sz val="11"/>
    <name val="Calibri"/>
</font>

</fonts>

<fills count="2">

<fill>
    <patternFill patternType="none"/>
</fill>

<fill>
    <patternFill patternType="gray125"/>
</fill>

</fills>

<borders count="1">

<border>
    <left/>
    <right/>
    <top/>
    <bottom/>
    <diagonal/>
</border>

</borders>

<cellStyleXfs count="1">

<xf
    numFmtId="0"
    fontId="0"
    fillId="0"
    borderId="0"/>

</cellStyleXfs>

<cellXfs count="2">

<xf
    numFmtId="0"
    fontId="0"
    fillId="0"
    borderId="0"/>

<xf
    numFmtId="0"
    fontId="1"
    fillId="0"
    borderId="0"
    applyFont="1"/>

</cellXfs>

</styleSheet>';


$zip->addFromString(
    'xl/styles.xml',
    $styles
);


/*
|--------------------------------------------------------------------------
| HOJA DE EXCEL
|--------------------------------------------------------------------------
*/

$sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>

<worksheet
    xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">


<!-- IMPORTANTE:
     cols debe ir ANTES de sheetData
-->


<cols>

<col
    min="1"
    max="1"
    width="10"
    customWidth="1"/>

<col
    min="2"
    max="2"
    width="18"
    customWidth="1"/>

<col
    min="3"
    max="3"
    width="40"
    customWidth="1"/>

<col
    min="4"
    max="4"
    width="12"
    customWidth="1"/>

<col
    min="5"
    max="5"
    width="20"
    customWidth="1"/>

<col
    min="6"
    max="7"
    width="12"
    customWidth="1"/>

<col
    min="8"
    max="8"
    width="30"
    customWidth="1"/>

</cols>


<sheetData>';


/*
|--------------------------------------------------------------------------
| TÍTULO
|--------------------------------------------------------------------------
*/

$sheet .= '

<row r="1">

<c
    r="A1"
    t="inlineStr"
    s="1">

<is>

<t>REPORTE DE INVENTARIO</t>

</is>

</c>

</row>';


/*
|--------------------------------------------------------------------------
| FECHA
|--------------------------------------------------------------------------
*/

$fechaActual = date(
    'd/m/Y H:i:s'
);


$sheet .= '

<row r="2">

<c
    r="A2"
    t="inlineStr">

<is>

<t>Fecha de exportación: ' .
    escapar_xml($fechaActual) .
'</t>

</is>

</c>

</row>';


/*
|--------------------------------------------------------------------------
| ENCABEZADOS
|--------------------------------------------------------------------------
*/

$encabezados = [

    'A' => 'ID',
    'B' => 'Código',
    'C' => 'Descripción',
    'D' => 'Cantidad',
    'E' => 'Ubicación',
    'F' => 'Máximo',
    'G' => 'Mínimo',
    'H' => 'Proveedor / Marca'

];


$fila = 4;


$sheet .= '<row r="' .
    $fila .
'">';


foreach ($encabezados as $columna => $texto) {

    $sheet .= '

<c
    r="' .
        $columna .
        $fila .
    '"
    t="inlineStr"
    s="1">

<is>

<t>' .
        escapar_xml($texto) .
    '</t>

</is>

</c>';

}


$sheet .= '</row>';


/*
|--------------------------------------------------------------------------
| DATOS
|--------------------------------------------------------------------------
*/

$fila = 5;


while ($row = $resultado->fetch_assoc()) {

    $sheet .= '<row r="' .
        $fila .
    '">';


    /*
    |--------------------------------------------------------------------------
    | ID
    |--------------------------------------------------------------------------
    */

    $sheet .= '

<c
    r="A' .
        $fila .
    '"
    t="n">

<v>' .
        (int)$row['id'] .
    '</v>

</c>';


    /*
    |--------------------------------------------------------------------------
    | CÓDIGO
    |--------------------------------------------------------------------------
    */

    $sheet .= '

<c
    r="B' .
        $fila .
    '"
    t="inlineStr">

<is>

<t>' .
        escapar_xml($row['codigo']) .
    '</t>

</is>

</c>';


    /*
    |--------------------------------------------------------------------------
    | DESCRIPCIÓN
    |--------------------------------------------------------------------------
    */

    $sheet .= '

<c
    r="C' .
        $fila .
    '"
    t="inlineStr">

<is>

<t>' .
        escapar_xml($row['articulo_descripcion']) .
    '</t>

</is>

</c>';


    /*
    |--------------------------------------------------------------------------
    | CANTIDAD
    |--------------------------------------------------------------------------
    */

    $sheet .= '

<c
    r="D' .
        $fila .
    '"
    t="n">

<v>' .
        (int)$row['cantidad'] .
    '</v>

</c>';


    /*
    |--------------------------------------------------------------------------
    | UBICACIÓN
    |--------------------------------------------------------------------------
    */

    $sheet .= '

<c
    r="E' .
        $fila .
    '"
    t="inlineStr">

<is>

<t>' .
        escapar_xml($row['ubicacion']) .
    '</t>

</is>

</c>';


    /*
    |--------------------------------------------------------------------------
    | MÁXIMO
    |--------------------------------------------------------------------------
    */

    $sheet .= '

<c
    r="F' .
        $fila .
    '"
    t="n">

<v>' .
        (int)$row['maximo'] .
    '</v>

</c>';


    /*
    |--------------------------------------------------------------------------
    | MÍNIMO
    |--------------------------------------------------------------------------
    */

    $sheet .= '

<c
    r="G' .
        $fila .
    '"
    t="n">

<v>' .
        (int)$row['minimo'] .
    '</v>

</c>';


    /*
    |--------------------------------------------------------------------------
    | PROVEEDOR / MARCA
    |--------------------------------------------------------------------------
    */

    $sheet .= '

<c
    r="H' .
        $fila .
    '"
    t="inlineStr">

<is>

<t>' .
        escapar_xml($row['proveedor_marca']) .
    '</t>

</is>

</c>';


    /*
    |--------------------------------------------------------------------------
    | CERRAR FILA
    |--------------------------------------------------------------------------
    */

    $sheet .= '</row>';


    $fila++;

}


/*
|--------------------------------------------------------------------------
| CERRAR SHEETDATA Y WORKSHEET
|--------------------------------------------------------------------------
*/

$sheet .= '

</sheetData>

</worksheet>';


/*
|--------------------------------------------------------------------------
| GUARDAR HOJA
|--------------------------------------------------------------------------
*/

$zip->addFromString(
    'xl/worksheets/sheet1.xml',
    $sheet
);


/*
|--------------------------------------------------------------------------
| CERRAR XLSX
|--------------------------------------------------------------------------
*/

$zip->close();


/*
|--------------------------------------------------------------------------
| NOMBRE DEL ARCHIVO
|--------------------------------------------------------------------------
*/

$nombreArchivo =
    'inventario_' .
    date('Y-m-d_H-i-s') .
    '.xlsx';


/*
|--------------------------------------------------------------------------
| HEADERS
|--------------------------------------------------------------------------
*/

header(
    'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
);

header(
    'Content-Disposition: attachment; filename="' .
    $nombreArchivo .
    '"'
);

header(
    'Content-Length: ' .
    filesize($archivoTemporal)
);

header(
    'Cache-Control: max-age=0'
);

header(
    'Pragma: public'
);


/*
|--------------------------------------------------------------------------
| DESCARGAR
|--------------------------------------------------------------------------
*/

readfile(
    $archivoTemporal
);


/*
|--------------------------------------------------------------------------
| ELIMINAR TEMPORAL
|--------------------------------------------------------------------------
*/

unlink(
    $archivoTemporal
);


/*
|--------------------------------------------------------------------------
| CERRAR CONEXIONES
|--------------------------------------------------------------------------
*/

$stmt->close();

$conexion->close();

exit;