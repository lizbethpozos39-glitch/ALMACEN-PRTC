<?php
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

require "conexion.php";

// =====================================================
// BUSCADOR
// =====================================================

$buscar = trim($_GET["buscar"] ?? "");

if ($buscar !== "") {

    $sql = "
        SELECT
            id,
            rfc_emisor,
            nombre_emisor,
            rfc_receptor,
            nombre_receptor,
            numero_factura,
            fecha_factura,
            subtotal,
            iva,
            total,
            fecha_registro
        FROM facturas
        WHERE
            rfc_emisor LIKE ?
            OR nombre_emisor LIKE ?
            OR numero_factura LIKE ?
        ORDER BY id DESC
    ";

    $stmt = $conexion->prepare($sql);

    $texto = "%" . $buscar . "%";

    $stmt->bind_param(
        "sss",
        $texto,
        $texto,
        $texto
    );

    $stmt->execute();

    $facturas = $stmt->get_result();

} else {

    $sql = "
        SELECT
            id,
            rfc_emisor,
            nombre_emisor,
            rfc_receptor,
            nombre_receptor,
            numero_factura,
            fecha_factura,
            subtotal,
            iva,
            total,
            fecha_registro
        FROM facturas
        ORDER BY id DESC
    ";

    $facturas = $conexion->query($sql);
}

?>

<?php require "header.php"; ?>


<style>

.contenedor-facturas {

    background: white;

    padding: 25px;

    border-radius: 10px;

    box-shadow:
        0 2px 10px rgba(0,0,0,.10);

}


.barra-busqueda {

    display: flex;

    gap: 10px;

    margin-bottom: 25px;

    flex-wrap: wrap;

}


.barra-busqueda input {

    flex: 1;

    min-width: 250px;

    padding: 11px;

    border: 1px solid #ccc;

    border-radius: 5px;

}


.boton {

    display: inline-block;

    padding: 10px 15px;

    border: none;

    border-radius: 5px;

    text-decoration: none;

    cursor: pointer;

}


.buscar {

    background: #0d6efd;

    color: white;

}


.limpiar {

    background: #6c757d;

    color: white;

}


.ver {

    background: #198754;

    color: white;

}


.tabla-contenedor {

    overflow-x: auto;

}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 1100px;

}


th {

    background: #212529;

    color: white;

    padding: 12px;

    text-align: left;

}


td {

    padding: 10px;

    border-bottom: 1px solid #ddd;

}


tr:hover {

    background: #f5f5f5;

}


.total {

    font-weight: bold;

    color: #198754;

}


.sin-resultados {

    text-align: center;

    padding: 40px;

    color: #777;

}


</style>


<h1>📄 Facturas</h1>


<div class="contenedor-facturas">


    <!-- ==========================================
         BUSCADOR
    =========================================== -->

    <form
        method="GET"
        class="barra-busqueda">


        <input
            type="text"
            name="buscar"
            value="<?= htmlspecialchars($buscar) ?>"
            placeholder="Buscar por RFC, proveedor o número de factura">


        <button
            type="submit"
            class="boton buscar">

            🔎 Buscar

        </button>


        <a
            href="facturas.php"
            class="boton limpiar">

            🔄 Limpiar

        </a>


    </form>


    <!-- ==========================================
         TABLA
    =========================================== -->

    <div class="tabla-contenedor">


        <?php if ($facturas && $facturas->num_rows > 0): ?>


            <table>


                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Fecha</th>

                        <th>Factura / Folio</th>

                        <th>RFC Emisor</th>

                        <th>Proveedor</th>

                        <th>RFC Receptor</th>

                        <th>Subtotal</th>

                        <th>IVA</th>

                        <th>Total</th>

                        <th>Acción</th>

                    </tr>

                </thead>


                <tbody>


                <?php while ($factura = $facturas->fetch_assoc()): ?>


                    <tr>


                        <td>

                            <?= $factura["id"] ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $factura["fecha_factura"] ?? ""
                            ) ?>

                        </td>


                        <td>

                            <strong>

                                <?= htmlspecialchars(
                                    $factura["numero_factura"]
                                ) ?>

                            </strong>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $factura["rfc_emisor"]
                            ) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $factura["nombre_emisor"]
                            ) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $factura["rfc_receptor"] ?? ""
                            ) ?>

                        </td>


                        <td>

                            $<?= number_format(
                                $factura["subtotal"],
                                2
                            ) ?>

                        </td>


                        <td>

                            $<?= number_format(
                                $factura["iva"],
                                2
                            ) ?>

                        </td>


                        <td class="total">

                            $<?= number_format(
                                $factura["total"],
                                2
                            ) ?>

                        </td>


                        <td>

                            <a
                                href="detalle_factura.php?id=<?= $factura["id"] ?>"
                                class="boton ver">

                                👁️ Ver

                            </a>

                        </td>


                    </tr>


                <?php endwhile; ?>


                </tbody>


            </table>


        <?php else: ?>


            <div class="sin-resultados">

                📭 No se encontraron facturas.

            </div>


        <?php endif; ?>


    </div>


</div>


<?php require "footer.php"; ?>
