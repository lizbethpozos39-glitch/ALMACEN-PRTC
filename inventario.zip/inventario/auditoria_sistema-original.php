<?php

require_once 'conexion.php';
require_once 'seguridad.php';
require_once 'auditoria.php';

verificar_admin();

/*
|--------------------------------------------------------------------------
| Filtros
|--------------------------------------------------------------------------
*/

$usuario_filtro = $_GET['usuario'] ?? '';
$accion_filtro = $_GET['accion'] ?? '';
$modulo_filtro = $_GET['modulo'] ?? '';
$fecha_desde = $_GET['fecha_desde'] ?? '';
$fecha_hasta = $_GET['fecha_hasta'] ?? '';

/*
|--------------------------------------------------------------------------
| Construcción de consulta
|--------------------------------------------------------------------------
*/

$where = [];
$parametros = [];
$tipos = '';

if ($usuario_filtro !== '') {

    $where[] = "(usuario LIKE ? OR empleado LIKE ?)";

    $buscar = "%" . $usuario_filtro . "%";

    $parametros[] = $buscar;
    $parametros[] = $buscar;

    $tipos .= "ss";
}

if ($accion_filtro !== '') {

    $where[] = "accion = ?";

    $parametros[] = $accion_filtro;

    $tipos .= "s";
}

if ($modulo_filtro !== '') {

    $where[] = "modulo = ?";

    $parametros[] = $modulo_filtro;

    $tipos .= "s";
}

if ($fecha_desde !== '') {

    $where[] = "DATE(fecha_hora) >= ?";

    $parametros[] = $fecha_desde;

    $tipos .= "s";
}

if ($fecha_hasta !== '') {

    $where[] = "DATE(fecha_hora) <= ?";

    $parametros[] = $fecha_hasta;

    $tipos .= "s";
}

$sql = "
    SELECT
        id,
        usuario_id,
        empleado_id,
        usuario,
        empleado,
        rol,
        accion,
        modulo,
        descripcion,
        ip,
        fecha_hora
    FROM auditoria_sistema
";

if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY fecha_hora DESC, id DESC";

$stmt = $conexion->prepare($sql);

if (!$stmt) {
    die("Error al preparar la consulta: " . $conexion->error);
}

if (!empty($parametros)) {

    $stmt->bind_param(
        $tipos,
        ...$parametros
    );
}

$stmt->execute();

$resultado = $stmt->get_result();

/*
|--------------------------------------------------------------------------
| Obtener acciones y módulos para filtros
|--------------------------------------------------------------------------
*/

$acciones = $conexion->query("
    SELECT DISTINCT accion
    FROM auditoria_sistema
    WHERE accion IS NOT NULL
      AND accion <> ''
    ORDER BY accion
");

$modulos = $conexion->query("
    SELECT DISTINCT modulo
    FROM auditoria_sistema
    WHERE modulo IS NOT NULL
      AND modulo <> ''
    ORDER BY modulo
");

?>

<?php include 'menu.php'; ?>

<main class="contenido-principal">

    <div style="
        padding: 30px;
        font-family: Arial, sans-serif;
    ">

        <div style="
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:25px;
            gap:15px;
            flex-wrap:wrap;
        ">

            <div>

                <h1 style="
                    margin:0;
                    color:#212529;
                ">
                    📋 Auditoría del sistema
                </h1>

                <p style="
                    margin-top:8px;
                    color:#6c757d;
                ">
                    Historial de acciones realizadas por los usuarios.
                </p>

            </div>

        </div>


        <!-- FILTROS -->

        <div style="
            background:#ffffff;
            border:1px solid #dee2e6;
            border-radius:8px;
            padding:20px;
            margin-bottom:25px;
        ">

            <form method="GET">

                <div style="
                    display:grid;
                    grid-template-columns:
                        repeat(auto-fit, minmax(180px, 1fr));
                    gap:15px;
                    align-items:end;
                ">

                    <div>

                        <label style="
                            display:block;
                            font-weight:bold;
                            margin-bottom:6px;
                        ">
                            Usuario / empleado
                        </label>

                        <input
                            type="text"
                            name="usuario"
                            value="<?= htmlspecialchars($usuario_filtro) ?>"
                            placeholder="Buscar..."
                            style="
                                width:100%;
                                box-sizing:border-box;
                                padding:9px;
                                border:1px solid #ced4da;
                                border-radius:5px;
                            "
                        >

                    </div>


                    <div>

                        <label style="
                            display:block;
                            font-weight:bold;
                            margin-bottom:6px;
                        ">
                            Acción
                        </label>

                        <select
                            name="accion"
                            style="
                                width:100%;
                                padding:9px;
                                border:1px solid #ced4da;
                                border-radius:5px;
                            "
                        >

                            <option value="">
                                Todas
                            </option>

                            <?php if ($acciones): ?>

                                <?php while ($a = $acciones->fetch_assoc()): ?>

                                    <option
                                        value="<?= htmlspecialchars($a['accion']) ?>"
                                        <?= $accion_filtro === $a['accion'] ? 'selected' : '' ?>
                                    >
                                        <?= htmlspecialchars($a['accion']) ?>
                                    </option>

                                <?php endwhile; ?>

                            <?php endif; ?>

                        </select>

                    </div>


                    <div>

                        <label style="
                            display:block;
                            font-weight:bold;
                            margin-bottom:6px;
                        ">
                            Módulo
                        </label>

                        <select
                            name="modulo"
                            style="
                                width:100%;
                                padding:9px;
                                border:1px solid #ced4da;
                                border-radius:5px;
                            "
                        >

                            <option value="">
                                Todos
                            </option>

                            <?php if ($modulos): ?>

                                <?php while ($m = $modulos->fetch_assoc()): ?>

                                    <option
                                        value="<?= htmlspecialchars($m['modulo']) ?>"
                                        <?= $modulo_filtro === $m['modulo'] ? 'selected' : '' ?>
                                    >
                                        <?= htmlspecialchars($m['modulo']) ?>
                                    </option>

                                <?php endwhile; ?>

                            <?php endif; ?>

                        </select>

                    </div>


                    <div>

                        <label style="
                            display:block;
                            font-weight:bold;
                            margin-bottom:6px;
                        ">
                            Desde
                        </label>

                        <input
                            type="date"
                            name="fecha_desde"
                            value="<?= htmlspecialchars($fecha_desde) ?>"
                            style="
                                width:100%;
                                box-sizing:border-box;
                                padding:9px;
                                border:1px solid #ced4da;
                                border-radius:5px;
                            "
                        >

                    </div>


                    <div>

                        <label style="
                            display:block;
                            font-weight:bold;
                            margin-bottom:6px;
                        ">
                            Hasta
                        </label>

                        <input
                            type="date"
                            name="fecha_hasta"
                            value="<?= htmlspecialchars($fecha_hasta) ?>"
                            style="
                                width:100%;
                                box-sizing:border-box;
                                padding:9px;
                                border:1px solid #ced4da;
                                border-radius:5px;
                            "
                        >

                    </div>


                    <div style="
                        display:flex;
                        gap:8px;
                    ">

                        <button
                            type="submit"
                            style="
                                background:#0d6efd;
                                color:white;
                                border:none;
                                padding:10px 16px;
                                border-radius:5px;
                                cursor:pointer;
                            "
                        >
                            🔎 Buscar
                        </button>

                        <a
                            href="auditoria_sistema.php"
                            style="
                                background:#6c757d;
                                color:white;
                                padding:10px 16px;
                                border-radius:5px;
                                text-decoration:none;
                            "
                        >
                            Limpiar
                        </a>

                    </div>

                </div>

            </form>

        </div>


        <!-- TABLA -->

        <div style="
            background:#ffffff;
            border:1px solid #dee2e6;
            border-radius:8px;
            overflow:auto;
        ">

            <table style="
                width:100%;
                border-collapse:collapse;
                min-width:1000px;
            ">

                <thead>

                    <tr style="
                        background:#212529;
                        color:white;
                    ">

                        <th style="padding:12px; text-align:left;">
                            Fecha / hora
                        </th>

                        <th style="padding:12px; text-align:left;">
                            Usuario
                        </th>

                        <th style="padding:12px; text-align:left;">
                            Empleado
                        </th>

                        <th style="padding:12px; text-align:left;">
                            Rol
                        </th>

                        <th style="padding:12px; text-align:left;">
                            Acción
                        </th>

                        <th style="padding:12px; text-align:left;">
                            Módulo
                        </th>

                        <th style="padding:12px; text-align:left;">
                            Descripción
                        </th>

                        <th style="padding:12px; text-align:left;">
                            IP
                        </th>

                    </tr>

                </thead>

                <tbody>

                    <?php if ($resultado->num_rows > 0): ?>

                        <?php while ($fila = $resultado->fetch_assoc()): ?>

                            <tr style="
                                border-bottom:1px solid #dee2e6;
                            ">

                                <td style="padding:11px;">
                                    <?= htmlspecialchars($fila['fecha_hora']) ?>
                                </td>

                                <td style="padding:11px;">
                                    <strong>
                                        <?= htmlspecialchars($fila['usuario'] ?? '') ?>
                                    </strong>
                                </td>

                                <td style="padding:11px;">
                                    <?= htmlspecialchars($fila['empleado'] ?? '') ?>
                                </td>

                                <td style="padding:11px;">
                                    <?= htmlspecialchars($fila['rol'] ?? '') ?>
                                </td>

                                <td style="padding:11px;">

                                    <span style="
                                        display:inline-block;
                                        padding:5px 8px;
                                        background:#e9ecef;
                                        border-radius:4px;
                                        font-size:13px;
                                    ">
                                        <?= htmlspecialchars($fila['accion']) ?>
                                    </span>

                                </td>

                                <td style="padding:11px;">
                                    <?= htmlspecialchars($fila['modulo'] ?? '') ?>
                                </td>

                                <td style="
                                    padding:11px;
                                    max-width:400px;
                                ">
                                    <?= htmlspecialchars($fila['descripcion'] ?? '') ?>
                                </td>

                                <td style="padding:11px;">
                                    <?= htmlspecialchars($fila['ip'] ?? '') ?>
                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td
                                colspan="8"
                                style="
                                    padding:30px;
                                    text-align:center;
                                    color:#6c757d;
                                "
                            >
                                No se encontraron registros de auditoría.

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>


        <div style="
            margin-top:15px;
            color:#6c757d;
            font-size:14px;
        ">

            Registros encontrados:
            <strong><?= $resultado->num_rows ?></strong>

        </div>

    </div>

</main>

<?php include 'footer.php'; ?>