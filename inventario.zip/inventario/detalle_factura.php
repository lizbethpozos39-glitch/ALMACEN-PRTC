<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';


/* =========================================================
   VALIDAR ID DE FACTURA
========================================================= */

$id = intval($_GET["id"] ?? 0);

if ($id <= 0) {
    die("Factura no válida.");
}


/* =========================================================
   OBTENER FACTURA
========================================================= */

$stmt = $conexion->prepare("
    SELECT
        id,
        rfc_emisor,
        nombre_emisor,
        rfc_receptor,
        nombre_receptor,
        numero_factura,
        fecha_factura,
        subtotal,
        tasa_iva,
        iva,
        total,
        moneda,
        fecha_registro
    FROM facturas
    WHERE id = ?
");

if (!$stmt) {
    die("Error al preparar la consulta: " . $conexion->error);
}

$stmt->bind_param("i", $id);
$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    $stmt->close();
    die("La factura no existe.");
}

$factura = $resultado->fetch_assoc();

$stmt->close();


/* =========================================================
   OBTENER DETALLES
========================================================= */

$detalles = [];

$sql_detalles = "
    SELECT
        fd.*,
        i.codigo,
        i.articulo_descripcion,
        i.ubicacion
    FROM factura_detalles fd
    LEFT JOIN inventario i
        ON i.id = fd.inventario_id
    WHERE fd.factura_id = ?
    ORDER BY fd.id ASC
";

$stmt_detalles = $conexion->prepare($sql_detalles);

if ($stmt_detalles) {

    $stmt_detalles->bind_param("i", $id);

    $stmt_detalles->execute();

    $resultado_detalles = $stmt_detalles->get_result();

    while ($fila = $resultado_detalles->fetch_assoc()) {

        $detalles[] = $fila;

    }

    $stmt_detalles->close();
}


/* =========================================================
   FUNCIÓN PARA OBTENER CAMPOS
========================================================= */

function obtenerCampo($fila, $posibles, $default = 0)
{
    foreach ($posibles as $campo) {

        if (
            array_key_exists($campo, $fila) &&
            $fila[$campo] !== null &&
            $fila[$campo] !== ""
        ) {

            return $fila[$campo];

        }

    }

    return $default;
}


/* =========================================================
   IVA
========================================================= */

$tasa_iva = floatval(
    $factura["tasa_iva"] ?? 0
);


/* =========================================================
   MONEDA
========================================================= */

$moneda = strtoupper(
    trim($factura["moneda"] ?? "MXN")
);

$simbolo_moneda = "$";

if ($moneda === "USD") {

    $simbolo_moneda = "US$";

}


/* =========================================================
   LOGO
========================================================= */

$logo = "";

$posibles_logos = [

    "img/logo.png",
    "img/logo.jpg",
    "img/logo.jpeg",
    "img/logo.webp",
    "img/logo.gif"

];

foreach ($posibles_logos as $archivo_logo) {

    if (
        file_exists(
            __DIR__ . "/" . $archivo_logo
        )
    ) {

        $logo = $archivo_logo;

        break;

    }

}

?>

<?php include 'menu.php'; ?>


<main class="contenido-principal">


    <!-- =====================================================
         BARRA SUPERIOR
    ====================================================== -->

    <header class="barra-superior">

        <div class="titulo-superior">

            📄 Detalle de factura

        </div>


        <div class="usuario-superior">

            Usuario:

            <strong>

                <?= htmlspecialchars(
                    $nombre_empleado,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>

            </strong>

        </div>

    </header>


    <div class="pagina-contenido">


        <!-- =================================================
             BOTÓN REGRESAR
        ================================================== -->

        <div class="barra-navegacion">

            <a
                href="facturas.php"
                class="boton regresar"
            >

                ⬅️ Regresar a facturas

            </a>

        </div>


        <!-- =================================================
             DOCUMENTO DE FACTURA
        ================================================== -->

        <div class="factura-contenedor">


            <!-- =================================================
                 ENCABEZADO EMPRESA
            ================================================== -->

            <div class="encabezado-empresa">


                <?php if ($logo !== ""): ?>

                    <img
                        src="<?= htmlspecialchars($logo) ?>"
                        class="logo-empresa"
                        alt="Logo Grupo Protec"
                    >

                <?php endif; ?>


                <div class="datos-empresa">

                    <h1>

                        GRUPO PROTEC, S.A. DE C.V.

                    </h1>


                    <p>

                        16 Sta. Ma. de Aguayo No. 210,
                        Los Pinos

                        <br>

                        Tel. 834 312 01 29,
                        Cd. Victoria,
                        Tamaulipas, México

                    </p>

                </div>


                <div class="documento-identificacion">

                    <div class="etiqueta-documento">

                        FACTURA

                    </div>


                    <div class="numero-factura">

                        <?= htmlspecialchars(
                            $factura["numero_factura"] ?? ""
                        ) ?>

                    </div>

                </div>


            </div>


            <!-- =================================================
                 INFORMACIÓN PRINCIPAL
            ================================================== -->

            <div class="titulo-seccion">

                Información de la factura

            </div>


            <div class="info-grid">


                <!-- DATOS FACTURA -->

                <div class="info-bloque">

                    <h3>

                        📅 Datos de la factura

                    </h3>


                    <div class="info-linea">

                        <span>Fecha:</span>

                        <strong>

                            <?= htmlspecialchars(
                                $factura["fecha_factura"] ?? ""
                            ) ?>

                        </strong>

                    </div>


                    <div class="info-linea">

                        <span>ID interno:</span>

                        <strong>

                            #<?= intval(
                                $factura["id"]
                            ) ?>

                        </strong>

                    </div>


                    <div class="info-linea">

                        <span>Moneda:</span>

                        <strong>

                            <?= htmlspecialchars(
                                $moneda
                            ) ?>

                        </strong>

                    </div>


                    <div class="info-linea">

                        <span>Registrada:</span>

                        <strong>

                            <?= htmlspecialchars(
                                $factura["fecha_registro"] ?? ""
                            ) ?>

                        </strong>

                    </div>

                </div>


                <!-- PROVEEDOR -->

                <div class="info-bloque">

                    <h3>

                        🏢 Proveedor / Emisor

                    </h3>


                    <div class="info-linea">

                        <span>Nombre:</span>

                        <strong>

                            <?= htmlspecialchars(
                                $factura["nombre_emisor"] ?? ""
                            ) ?>

                        </strong>

                    </div>


                    <div class="info-linea">

                        <span>RFC:</span>

                        <strong>

                            <?= htmlspecialchars(
                                $factura["rfc_emisor"] ?? ""
                            ) ?>

                        </strong>

                    </div>

                </div>


            </div>


            <!-- =================================================
                 RECEPTOR
            ================================================== -->

            <?php if (
                !empty($factura["nombre_receptor"]) ||
                !empty($factura["rfc_receptor"])
            ): ?>

                <div class="info-bloque receptor">

                    <h3>

                        📋 Receptor

                    </h3>


                    <div class="receptor-grid">


                        <div class="info-linea">

                            <span>Nombre:</span>

                            <strong>

                                <?= htmlspecialchars(
                                    $factura["nombre_receptor"] ?? ""
                                ) ?>

                            </strong>

                        </div>


                        <div class="info-linea">

                            <span>RFC:</span>

                            <strong>

                                <?= htmlspecialchars(
                                    $factura["rfc_receptor"] ?? ""
                                ) ?>

                            </strong>

                        </div>


                    </div>

                </div>

            <?php endif; ?>


            <!-- =================================================
                 ARTÍCULOS
            ================================================== -->

            <div class="seccion-articulos">

                <div class="titulo-seccion">

                    📦 Artículos de la factura

                </div>


                <?php if (count($detalles) > 0): ?>


                    <div class="tabla-contenedor">

                        <table>

                            <thead>

                                <tr>

                                    <th class="col-numero">
                                        #
                                    </th>

                                    <th>
                                        Código
                                    </th>

                                    <th>
                                        Descripción
                                    </th>

                                    <th class="col-numero">
                                        Cantidad
                                    </th>

                                    <th class="col-numero">
                                        Costo unitario
                                    </th>

                                    <th class="col-numero">
                                        Importe
                                    </th>

                                </tr>

                            </thead>


                            <tbody>


                            <?php

                            $contador = 1;

                            foreach (
                                $detalles
                                as $detalle
                            ):


                                $cantidad = floatval(
                                    obtenerCampo(
                                        $detalle,
                                        [
                                            "cantidad",
                                            "cantidad_producto",
                                            "cantidad_ingresada"
                                        ],
                                        0
                                    )
                                );


                                $costo = floatval(
                                    obtenerCampo(
                                        $detalle,
                                        [
                                            "valor_unitario",
                                            "costo_unitario",
                                            "precio_unitario",
                                            "costo"
                                        ],
                                        0
                                    )
                                );


                                $importe = obtenerCampo(
                                    $detalle,
                                    [
                                        "importe",
                                        "subtotal",
                                        "total"
                                    ],
                                    null
                                );


                                if (
                                    $importe === null ||
                                    $importe === ""
                                ) {

                                    $importe =
                                        $cantidad *
                                        $costo;

                                } else {

                                    $importe =
                                        floatval($importe);

                                }


                                $descripcion =
                                    $detalle[
                                        "articulo_descripcion"
                                    ]
                                    ??
                                    $detalle[
                                        "descripcion"
                                    ]
                                    ??
                                    "Artículo";


                                $codigo =
                                    $detalle["codigo"]
                                    ??
                                    $detalle[
                                        "clave_producto"
                                    ]
                                    ??
                                    "";

                            ?>


                                <tr>

                                    <td class="col-numero">

                                        <?= $contador ?>

                                    </td>


                                    <td>

                                        <span class="codigo">

                                            <?= htmlspecialchars(
                                                $codigo
                                            ) ?>

                                        </span>

                                    </td>


                                    <td>

                                        <strong class="descripcion">

                                            <?= htmlspecialchars(
                                                $descripcion
                                            ) ?>

                                        </strong>

                                    </td>


                                    <td class="numero">

                                        <?= number_format(
                                            $cantidad,
                                            3
                                        ) ?>

                                    </td>


                                    <td class="numero">

                                        <?= $simbolo_moneda ?>

                                        <?= number_format(
                                            $costo,
                                            2
                                        ) ?>

                                    </td>


                                    <td class="numero importe">

                                        <?= $simbolo_moneda ?>

                                        <?= number_format(
                                            $importe,
                                            2
                                        ) ?>

                                    </td>

                                </tr>


                            <?php

                                $contador++;

                            endforeach;

                            ?>


                            </tbody>

                        </table>

                    </div>


                <?php else: ?>


                    <div class="sin-detalles">

                        <div class="icono">

                            📭

                        </div>

                        <strong>

                            Esta factura no tiene artículos registrados.

                        </strong>

                    </div>


                <?php endif; ?>

            </div>


            <!-- =================================================
                 TOTALES
            ================================================== -->

            <div class="zona-totales">

                <div class="totales">


                    <div class="total-linea">

                        <span>

                            Subtotal

                        </span>


                        <strong>

                            <?= $simbolo_moneda ?>

                            <?= number_format(
                                (float)$factura["subtotal"],
                                2
                            ) ?>

                        </strong>

                    </div>


                    <div class="total-linea">

                        <span>

                            IVA

                            <?php if ($tasa_iva > 0): ?>

                                (<?= number_format(
                                    $tasa_iva,
                                    2
                                ) ?>%)

                            <?php endif; ?>

                        </span>


                        <strong>

                            <?= $simbolo_moneda ?>

                            <?= number_format(
                                (float)$factura["iva"],
                                2
                            ) ?>

                        </strong>

                    </div>


                    <div class="total-final">

                        <span>

                            TOTAL

                        </span>


                        <strong>

                            <?= $simbolo_moneda ?>

                            <?= number_format(
                                (float)$factura["total"],
                                2
                            ) ?>

                        </strong>

                    </div>


                </div>

            </div>


            <!-- =================================================
                 BOTONES
            ================================================== -->

            <div class="botones">

                <a
                    href="facturas.php"
                    class="boton regresar"
                >

                    ⬅️ Regresar

                </a>


                <button
                    type="button"
                    class="boton imprimir"
                    onclick="window.print()"
                >

                    🖨️ Imprimir factura

                </button>

            </div>


        </div>

    </div>

</main>


<style>

/* =========================================================
   BASE
========================================================= */

* {
    box-sizing: border-box;
}

body {

    margin: 0;

    font-family: Arial, sans-serif;

    background: #f4f6f9;

}


/* =========================================================
   ESPACIO PARA EL MENÚ LATERAL
   IMPORTANTE: NO MODIFICAR EL MENÚ
========================================================= */

.contenido-principal {

    margin-left: 240px;

    width: calc(100% - 240px);

    min-height: 100vh;

}


/* =========================================================
   BARRA SUPERIOR
========================================================= */

.barra-superior {

    min-height: 60px;

    padding: 15px 25px;

    display: flex;

    justify-content: space-between;

    align-items: center;

    background: #ffffff;

    border-bottom: 1px solid #e5e5e5;

}


.titulo-superior {

    font-size: 16px;

    font-weight: bold;

    color: #212529;

}


.usuario-superior {

    font-size: 13px;

    color: #6c757d;

}


.usuario-superior strong {

    color: #212529;

}


/* =========================================================
   CONTENIDO
========================================================= */

.pagina-contenido {

    padding: 25px;

}


.barra-navegacion {

    margin-bottom: 15px;

}


/* =========================================================
   FACTURA
========================================================= */

.factura-contenedor {

    background: white;

    max-width: 1100px;

    margin: 0 auto;

    padding: 35px;

    border-radius: 10px;

    box-shadow:
        0 2px 10px rgba(0,0,0,.10);

}


/* =========================================================
   EMPRESA
========================================================= */

.encabezado-empresa {

    display: flex;

    align-items: center;

    gap: 20px;

    border-bottom: 2px solid #212529;

    padding-bottom: 20px;

    margin-bottom: 25px;

}


.logo-empresa {

    max-width: 130px;

    max-height: 80px;

    object-fit: contain;

}


.datos-empresa {

    flex: 1;

}


.datos-empresa h1 {

    margin: 0;

    font-size: 23px;

    color: #212529;

}


.datos-empresa p {

    margin: 6px 0 0 0;

    font-size: 12px;

    color: #555;

    line-height: 1.5;

}


/* =========================================================
   IDENTIFICACIÓN DOCUMENTO
========================================================= */

.documento-identificacion {

    text-align: right;

    min-width: 170px;

    border: 1px solid #ddd;

    padding: 12px;

    border-radius: 6px;

}


.etiqueta-documento {

    font-size: 12px;

    font-weight: bold;

    color: #6c757d;

    margin-bottom: 5px;

}


.numero-factura {

    font-size: 20px;

    font-weight: bold;

    color: #0d6efd;

    word-break: break-word;

}


/* =========================================================
   TÍTULOS
========================================================= */

.titulo-seccion {

    font-size: 17px;

    font-weight: bold;

    color: #212529;

    margin-bottom: 14px;

}


/* =========================================================
   INFORMACIÓN
========================================================= */

.info-grid {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 18px;

    margin-bottom: 20px;

}


.info-bloque {

    border: 1px solid #ddd;

    border-radius: 7px;

    padding: 16px;

    background: #fff;

}


.info-bloque h3 {

    margin: 0 0 13px 0;

    font-size: 15px;

    color: #212529;

    padding-bottom: 8px;

    border-bottom: 1px solid #eee;

}


.info-linea {

    display: flex;

    justify-content: space-between;

    gap: 15px;

    margin-bottom: 8px;

    font-size: 13px;

}


.info-linea:last-child {

    margin-bottom: 0;

}


.info-linea span {

    color: #6c757d;

}


.info-linea strong {

    color: #212529;

    text-align: right;

}


.receptor {

    margin-bottom: 25px;

}


.receptor-grid {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 20px;

}


/* =========================================================
   ARTÍCULOS
========================================================= */

.seccion-articulos {

    margin-top: 10px;

}


.tabla-contenedor {

    overflow-x: auto;

}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 750px;

}


th {

    background: #212529;

    color: white;

    padding: 11px;

    text-align: left;

    font-size: 13px;

    white-space: nowrap;

}


td {

    padding: 11px;

    border-bottom: 1px solid #ddd;

    font-size: 13px;

    vertical-align: middle;

}


tr:hover {

    background: #f5f5f5;

}


.col-numero {

    text-align: center;

    width: 50px;

}


.numero {

    text-align: right;

    white-space: nowrap;

}


.codigo {

    color: #0d6efd;

    font-weight: bold;

}


.descripcion {

    color: #212529;

}


.importe {

    font-weight: bold;

}


/* =========================================================
   SIN DETALLES
========================================================= */

.sin-detalles {

    text-align: center;

    padding: 35px;

    color: #777;

    background: #f8f9fa;

    border-radius: 6px;

}


.sin-detalles .icono {

    font-size: 38px;

    margin-bottom: 8px;

}


/* =========================================================
   TOTALES
========================================================= */

.zona-totales {

    display: flex;

    justify-content: flex-end;

}


.totales {

    width: 350px;

    max-width: 100%;

    margin-top: 25px;

}


.total-linea {

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 8px 0;

    border-bottom: 1px solid #ddd;

    font-size: 14px;

}


.total-linea strong {

    white-space: nowrap;

}


.total-final {

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 13px 0;

    font-size: 21px;

    font-weight: bold;

    color: #198754;

    border-bottom: 3px double #212529;

}


.total-final strong {

    white-space: nowrap;

}


/* =========================================================
   BOTONES
========================================================= */

.botones {

    display: flex;

    gap: 10px;

    margin-top: 30px;

    padding-top: 20px;

    border-top: 1px solid #eee;

    flex-wrap: wrap;

}


.boton {

    display: inline-block;

    padding: 10px 16px;

    border-radius: 5px;

    text-decoration: none;

    border: none;

    cursor: pointer;

    font-family: Arial, sans-serif;

    font-size: 14px;

}


.regresar {

    background: #6c757d;

    color: white;

}


.regresar:hover {

    background: #5c636a;

}


.imprimir {

    background: #0d6efd;

    color: white;

}


.imprimir:hover {

    background: #0b5ed7;

}


/* =========================================================
   IMPRESIÓN
========================================================= */

@media print {

    @page {

        size: auto;

        margin: 10mm;

    }


    body {

        background: white !important;

    }


    /* ESTE ES EL NOMBRE REAL DE TU MENÚ */

    .barra-lateral,
    .barra-superior,
    .barra-navegacion,
    .botones,
    .footer {

        display: none !important;

    }


    .contenido-principal {

        margin-left: 0 !important;

        width: 100% !important;

    }


    .pagina-contenido {

        padding: 0 !important;

    }


    .factura-contenedor {

        max-width: none !important;

        width: 100% !important;

        margin: 0 !important;

        padding: 10px !important;

        box-shadow: none !important;

        border-radius: 0 !important;

    }


    tr:hover {

        background: white !important;

    }

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 850px) {

    .contenido-principal {

        margin-left: 210px;

        width: calc(100% - 210px);

    }


    .pagina-contenido {

        padding: 15px;

    }

}


@media (max-width: 800px) {

    .encabezado-empresa {

        flex-wrap: wrap;

    }


    .documento-identificacion {

        width: 100%;

        text-align: left;

    }


    .info-grid {

        grid-template-columns: 1fr;

    }


    .receptor-grid {

        grid-template-columns: 1fr;

        gap: 8px;

    }

}


@media (max-width: 650px) {

    .contenido-principal {

        margin-left: 0;

        width: 100%;

    }


    .pagina-contenido {

        padding: 12px;

    }


    .factura-contenedor {

        padding: 20px;

    }


    .encabezado-empresa {

        align-items: flex-start;

    }


    .logo-empresa {

        max-width: 100px;

    }


    .datos-empresa h1 {

        font-size: 18px;

    }


    .info-linea {

        flex-direction: column;

        gap: 3px;

    }


    .info-linea strong {

        text-align: left;

    }

}

</style>