<?php

// ==========================================
// SEGURIDAD
// ==========================================

require_once __DIR__ . '/seguridad.php';

verificar_sesion();

// ==========================================
// PERMISOS DEL MÓDULO
// ==========================================
//
// Inventario físico:
// ADMIN    = permitido
// USUARIO  = permitido
// GERENCIA = bloqueado
// CONSULTA = bloqueado
//

$rol_usuario = strtoupper(
    trim($_SESSION['rol'] ?? '')
);

if (
    $rol_usuario !== 'ADMIN' &&
    $rol_usuario !== 'USUARIO'
) {

    http_response_code(403);

    die('
        <div style="
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 80px auto;
            padding: 30px;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #f8f9fa;
        ">

            <h2 style="color:#dc3545;">
                Acceso no autorizado
            </h2>

            <p>
                No tienes permisos para acceder al módulo
                de inventario físico.
            </p>

            <a href="index.php"
               style="
                   display:inline-block;
                   margin-top:15px;
                   padding:10px 18px;
                   background:#0d6efd;
                   color:white;
                   text-decoration:none;
                   border-radius:5px;
               ">
                Regresar
            </a>

        </div>
    ');
}
// ==========================================
// CONEXIÓN
// ==========================================

require_once __DIR__ . '/conexion.php';


// ==========================================
// VARIABLES
// ==========================================

$mensaje = "";
$error = "";

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';
$rol_usuario     = strtoupper($_SESSION['rol'] ?? 'USUARIO');


// ==========================================
// ID DE LA REVISIÓN
// ==========================================
//
// Puede llegar por:
//
// inventario_fisico.php?revision=5
//
// o por sesión.
//

if (isset($_GET['revision'])) {

    $inventario_fisico_id = intval($_GET['revision']);

    if ($inventario_fisico_id > 0) {

        $_SESSION['inventario_fisico_id'] =
            $inventario_fisico_id;
    }

} else {

    $inventario_fisico_id = intval(
        $_SESSION['inventario_fisico_id'] ?? 0
    );
}


// ==========================================
// FUNCIONES
// ==========================================

function h($valor)
{
    return htmlspecialchars(
        (string)$valor,
        ENT_QUOTES,
        'UTF-8'
    );
}


function determinar_estado($cantidad_sistema, $cantidad_fisica)
{
    if ($cantidad_fisica === null || $cantidad_fisica === '') {

        return 'NO_REPORTADO';
    }

    $diferencia =
        (float)$cantidad_fisica -
        (float)$cantidad_sistema;


    if ($diferencia == 0) {

        return 'CORRECTO';

    } elseif ($diferencia < 0) {

        return 'FALTANTE';

    } else {

        return 'SOBRANTE';
    }
}


// ==========================================
// OBTENER INFORMACIÓN DE LA REVISIÓN
// ==========================================

$revision = null;

if ($inventario_fisico_id > 0) {

    $stmt = $conexion->prepare("
        SELECT *
        FROM inventarios_fisicos
        WHERE id = ?
        LIMIT 1
    ");

    if ($stmt) {

        $stmt->bind_param(
            "i",
            $inventario_fisico_id
        );

        $stmt->execute();

        $resultado =
            $stmt->get_result();

        $revision =
            $resultado->fetch_assoc();

        $stmt->close();
    }
}


// ==========================================
// ESTADO DE LA REVISIÓN
// ==========================================

$revisionFinalizada = false;

if ($revision) {

    $revisionFinalizada =
        (
            $revision['estado'] === 'FINALIZADO' ||
            $revision['estado'] === 'AJUSTADO'
        );
}


// ==========================================
// PROCESAR POST
// ==========================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $accion = $_POST['accion'] ?? '';


    // =====================================================
    // NUEVA REVISIÓN
    // =====================================================

    if ($accion === 'nueva_revision') {

        unset(
            $_SESSION['inventario_fisico_id']
        );

        header(
            "Location: inventario_fisico.php"
        );

        exit;
    }


    // =====================================================
    // VALIDAR REVISIÓN PARA MODIFICACIONES
    // =====================================================

    if (
        (
            $accion === 'guardar_detalle' ||
            $accion === 'guardar_todos' ||
            $accion === 'finalizar_revision'
        )
        &&
        $inventario_fisico_id <= 0
    ) {

        $error =
            "No existe una revisión activa.";
    }


    // =====================================================
    // NO PERMITIR MODIFICAR REVISIONES FINALIZADAS
    // =====================================================

    if (
        (
            $accion === 'guardar_detalle' ||
            $accion === 'guardar_todos'
        )
        &&
        $revisionFinalizada
    ) {

        $error =
            "La revisión ya fue finalizada y no puede modificarse.";
    }


    // =====================================================
    // GUARDAR CANTIDAD FÍSICA + COMENTARIO
    // =====================================================

    if (
        $accion === 'guardar_detalle' &&
        $error === ""
    ) {

        $detalle_id = intval(
            $_POST['detalle_id'] ?? 0
        );

        $cantidad_fisica_raw =
            trim(
                $_POST['cantidad_fisica'] ?? ''
            );

        $comentario =
            trim(
                $_POST['comentario'] ?? ''
            );


        if ($detalle_id <= 0) {

            $error =
                "Registro inválido.";

        } else {

            // ==========================================
            // VALIDAR QUE PERTENEZCA A LA REVISIÓN
            // ==========================================

            $stmt = $conexion->prepare("
                SELECT
                    id,
                    cantidad_sistema,
                    cantidad_fisica,
                    estado
                FROM inventario_fisico_detalle
                WHERE id = ?
                  AND inventario_fisico_id = ?
                LIMIT 1
            ");

            if (!$stmt) {

                $error =
                    "Error al preparar la consulta: " .
                    $conexion->error;

            } else {

                $stmt->bind_param(
                    "ii",
                    $detalle_id,
                    $inventario_fisico_id
                );

                $stmt->execute();

                $resultado =
                    $stmt->get_result();

                $detalle =
                    $resultado->fetch_assoc();

                $stmt->close();


                if (!$detalle) {

                    $error =
                        "El artículo no pertenece a la revisión actual.";

                } else {

                    // ==========================================
                    // VALIDAR CANTIDAD
                    // ==========================================

                    if ($cantidad_fisica_raw === '') {

                        $cantidad_fisica = null;

                    } else {

                        $cantidad_normalizada =
                            str_replace(
                                ',',
                                '.',
                                $cantidad_fisica_raw
                            );


                        if (
                            !is_numeric(
                                $cantidad_normalizada
                            )
                        ) {

                            $error =
                                "La cantidad física no es válida.";

                            $cantidad_fisica = null;

                        } else {

                            $cantidad_fisica =
                                (float)$cantidad_normalizada;


                            if ($cantidad_fisica < 0) {

                                $error =
                                    "La cantidad física no puede ser negativa.";
                            }
                        }
                    }


                    // ==========================================
                    // GUARDAR SI NO HUBO ERROR
                    // ==========================================

                    if ($error === "") {

                        $cantidad_sistema =
                            (float)$detalle['cantidad_sistema'];


                        // ======================================
                        // CALCULAR DIFERENCIA
                        // ======================================

                        if ($cantidad_fisica === null) {

                            $diferencia = null;

                        } else {

                            $diferencia =
                                $cantidad_fisica -
                                $cantidad_sistema;
                        }


                        // ======================================
                        // DETERMINAR ESTADO
                        // ======================================

                        $estado =
                            determinar_estado(
                                $cantidad_sistema,
                                $cantidad_fisica
                            );


                        // ======================================
                        // ACTUALIZAR
                        // ======================================

                        $stmt = $conexion->prepare("
                            UPDATE inventario_fisico_detalle
                            SET
                                cantidad_fisica = ?,
                                diferencia = ?,
                                estado = ?,
                                comentario = ?
                            WHERE id = ?
                              AND inventario_fisico_id = ?
                        ");

                        if (!$stmt) {

                            $error =
                                "No fue posible preparar el guardado: " .
                                $conexion->error;

                        } else {

                            $stmt->bind_param(
                                "ddssii",
                                $cantidad_fisica,
                                $diferencia,
                                $estado,
                                $comentario,
                                $detalle_id,
                                $inventario_fisico_id
                            );


                            if ($stmt->execute()) {

                                $mensaje =
                                    "Artículo actualizado correctamente.";

                            } else {

                                $error =
                                    "No fue posible guardar el artículo: " .
                                    $stmt->error;
                            }


                            $stmt->close();
                        }
                    }
                }
            }
        }
    }


    // =====================================================
    // GUARDAR TODOS LOS DETALLES
    // =====================================================

    if (
        $accion === 'guardar_todos' &&
        $error === ""
    ) {

        $detalles_post =
            $_POST['detalles'] ?? [];


        if (
            !is_array($detalles_post) ||
            empty($detalles_post)
        ) {

            $error =
                "No se recibieron registros para guardar.";

        } else {

            try {

                $conexion->begin_transaction();


                // ==========================================
                // PREPARAR CONSULTA DE DETALLE
                // ==========================================

                $stmtDetalle = $conexion->prepare("
                    SELECT
                        id,
                        cantidad_sistema
                    FROM inventario_fisico_detalle
                    WHERE id = ?
                      AND inventario_fisico_id = ?
                    LIMIT 1
                ");

                if (!$stmtDetalle) {

                    throw new Exception(
                        "No fue posible preparar la consulta de detalle."
                    );
                }


                // ==========================================
                // PREPARAR ACTUALIZACIÓN
                // ==========================================

                $stmtUpdate = $conexion->prepare("
                    UPDATE inventario_fisico_detalle
                    SET
                        cantidad_fisica = ?,
                        diferencia = ?,
                        estado = ?,
                        comentario = ?
                    WHERE id = ?
                      AND inventario_fisico_id = ?
                ");

                if (!$stmtUpdate) {

                    throw new Exception(
                        "No fue posible preparar la actualización."
                    );
                }


                // ==========================================
                // PROCESAR TODOS LOS REGISTROS
                // ==========================================

                foreach (
                    $detalles_post
                    as $detalle_id => $datos
                ) {

                    $detalle_id =
                        intval($detalle_id);


                    if ($detalle_id <= 0) {
                        continue;
                    }


                    $cantidad_fisica_raw =
                        trim(
                            $datos['cantidad_fisica'] ?? ''
                        );


                    $comentario =
                        trim(
                            $datos['comentario'] ?? ''
                        );


                    // ======================================
                    // OBTENER CANTIDAD DEL SISTEMA
                    // ======================================

                    $stmtDetalle->bind_param(
                        "ii",
                        $detalle_id,
                        $inventario_fisico_id
                    );

                    $stmtDetalle->execute();

                    $resultado =
                        $stmtDetalle->get_result();

                    $detalle =
                        $resultado->fetch_assoc();


                    if (!$detalle) {
                        continue;
                    }


                    $cantidad_sistema =
                        (float)$detalle['cantidad_sistema'];


                    // ======================================
                    // CANTIDAD FÍSICA
                    // ======================================

                    if ($cantidad_fisica_raw === '') {

                        $cantidad_fisica = null;

                        $diferencia = null;

                        $estado =
                            'NO_REPORTADO';

                    } else {

                        $cantidad_normalizada =
                            str_replace(
                                ',',
                                '.',
                                $cantidad_fisica_raw
                            );


                        if (
                            !is_numeric(
                                $cantidad_normalizada
                            )
                        ) {

                            throw new Exception(
                                "La cantidad física del registro " .
                                $detalle_id .
                                " no es válida."
                            );
                        }


                        $cantidad_fisica =
                            (float)$cantidad_normalizada;


                        if ($cantidad_fisica < 0) {

                            throw new Exception(
                                "La cantidad física del registro " .
                                $detalle_id .
                                " no puede ser negativa."
                            );
                        }


                        $diferencia =
                            $cantidad_fisica -
                            $cantidad_sistema;


                        $estado =
                            determinar_estado(
                                $cantidad_sistema,
                                $cantidad_fisica
                            );
                    }


                    // ======================================
                    // ACTUALIZAR DETALLE
                    // ======================================

                    $stmtUpdate->bind_param(
                        "ddssii",
                        $cantidad_fisica,
                        $diferencia,
                        $estado,
                        $comentario,
                        $detalle_id,
                        $inventario_fisico_id
                    );


                    if (!$stmtUpdate->execute()) {

                        throw new Exception(
                            "No fue posible guardar el registro " .
                            $detalle_id .
                            "."
                        );
                    }
                }


                $stmtDetalle->close();
                $stmtUpdate->close();


                // ==========================================
                // ACTUALIZAR RESUMEN
                // ==========================================

                $sqlResumen = "
                    SELECT

                        COUNT(*) AS total,

                        SUM(
                            CASE
                                WHEN estado = 'CORRECTO'
                                THEN 1
                                ELSE 0
                            END
                        ) AS correctos,

                        SUM(
                            CASE
                                WHEN estado = 'FALTANTE'
                                THEN 1
                                ELSE 0
                            END
                        ) AS faltantes,

                        SUM(
                            CASE
                                WHEN estado = 'SOBRANTE'
                                THEN 1
                                ELSE 0
                            END
                        ) AS sobrantes,

                        SUM(
                            CASE
                                WHEN estado = 'NO_ENCONTRADO'
                                THEN 1
                                ELSE 0
                            END
                        ) AS no_encontrados,

                        SUM(
                            CASE
                                WHEN estado = 'NO_REPORTADO'
                                THEN 1
                                ELSE 0
                            END
                        ) AS no_reportados

                    FROM inventario_fisico_detalle

                    WHERE inventario_fisico_id = ?
                ";


                $stmtResumen =
                    $conexion->prepare(
                        $sqlResumen
                    );


                if (!$stmtResumen) {

                    throw new Exception(
                        "No fue posible preparar el resumen."
                    );
                }


                $stmtResumen->bind_param(
                    "i",
                    $inventario_fisico_id
                );


                $stmtResumen->execute();

                $resultadoResumen =
                    $stmtResumen->get_result();

                $datosResumen =
                    $resultadoResumen->fetch_assoc();

                $stmtResumen->close();


                $total =
                    (int)(
                        $datosResumen['total'] ?? 0
                    );

                $correctos =
                    (int)(
                        $datosResumen['correctos'] ?? 0
                    );

                $faltantes =
                    (int)(
                        $datosResumen['faltantes'] ?? 0
                    );

                $sobrantes =
                    (int)(
                        $datosResumen['sobrantes'] ?? 0
                    );

                $no_encontrados =
                    (int)(
                        $datosResumen['no_encontrados'] ?? 0
                    );


                // ==========================================
                // GUARDAR RESUMEN
                // ==========================================

                $stmtActualizar =
                    $conexion->prepare("
                        UPDATE inventarios_fisicos
                        SET
                            total_articulos = ?,
                            total_correctos = ?,
                            total_faltantes = ?,
                            total_sobrantes = ?,
                            total_no_encontrados = ?
                        WHERE id = ?
                    ");


                if (!$stmtActualizar) {

                    throw new Exception(
                        "No fue posible actualizar el resumen de la revisión."
                    );
                }


                $stmtActualizar->bind_param(
                    "iiiiii",
                    $total,
                    $correctos,
                    $faltantes,
                    $sobrantes,
                    $no_encontrados,
                    $inventario_fisico_id
                );


                if (!$stmtActualizar->execute()) {

                    throw new Exception(
                        "No fue posible actualizar el resumen."
                    );
                }


                $stmtActualizar->close();


                // ==========================================
                // CONFIRMAR
                // ==========================================

                $conexion->commit();


                $mensaje =
                    "Todos los registros fueron guardados correctamente.";

            } catch (Throwable $e) {

                try {

                    $conexion->rollback();

                } catch (Throwable $rollbackError) {

                    // No hacemos nada.
                }


                $error =
                    "No fue posible guardar los registros: " .
                    $e->getMessage();
            }
        }
    }


    // =====================================================
    // FINALIZAR REVISIÓN
    // =====================================================

    if (
        $accion === 'finalizar_revision' &&
        $error === ""
    ) {

        try {

            // ==========================================
            // VERIFICAR PENDIENTES
            // ==========================================

            $stmt = $conexion->prepare("
                SELECT COUNT(*) AS pendientes
                FROM inventario_fisico_detalle
                WHERE inventario_fisico_id = ?
                  AND estado = 'NO_REPORTADO'
            ");


            if (!$stmt) {

                throw new Exception(
                    "No fue posible verificar los registros pendientes."
                );
            }


            $stmt->bind_param(
                "i",
                $inventario_fisico_id
            );


            $stmt->execute();

            $resultado =
                $stmt->get_result();

            $filaPendientes =
                $resultado->fetch_assoc();

            $pendientes =
                (int)(
                    $filaPendientes['pendientes'] ?? 0
                );

            $stmt->close();


            // ==========================================
            // FINALIZAR
            // ==========================================

            $stmt = $conexion->prepare("
                UPDATE inventarios_fisicos
                SET
                    estado = 'FINALIZADO',
                    fecha_finalizacion = NOW()
                WHERE id = ?
                  AND estado = 'EN_REVISION'
            ");


            if (!$stmt) {

                throw new Exception(
                    "No fue posible finalizar la revisión."
                );
            }


            $stmt->bind_param(
                "i",
                $inventario_fisico_id
            );


            if (!$stmt->execute()) {

                throw new Exception(
                    "No fue posible finalizar la revisión."
                );
            }


            if ($stmt->affected_rows <= 0) {

                throw new Exception(
                    "La revisión ya fue finalizada o no está disponible."
                );
            }


            $stmt->close();


            if ($pendientes > 0) {

                $mensaje =
                    "La revisión fue finalizada. " .
                    "Quedaron " .
                    $pendientes .
                    " artículos como NO REPORTADOS.";

            } else {

                $mensaje =
                    "La revisión fue finalizada correctamente.";
            }


        } catch (Throwable $e) {

            $error =
                $e->getMessage();
        }
    }
}


// ==========================================
// OBTENER DETALLE DE LA REVISIÓN
// ==========================================

$detalles = [];

$resumen = [
    'total'          => 0,
    'correctos'      => 0,
    'faltantes'      => 0,
    'sobrantes'      => 0,
    'no_encontrados' => 0,
    'no_reportados'  => 0
];


if ($inventario_fisico_id > 0) {

    $stmt = $conexion->prepare("
        SELECT
            id,
            codigo,
            articulo_descripcion,
            cantidad_sistema,
            cantidad_fisica,
            diferencia,
            estado,
            comentario,
            incluir_ajuste,
            ajuste_aplicado
        FROM inventario_fisico_detalle
        WHERE inventario_fisico_id = ?
        ORDER BY
            CASE estado
                WHEN 'FALTANTE' THEN 1
                WHEN 'SOBRANTE' THEN 2
                WHEN 'NO_ENCONTRADO' THEN 3
                WHEN 'NO_REPORTADO' THEN 4
                WHEN 'CORRECTO' THEN 5
                ELSE 6
            END,
            articulo_descripcion ASC,
            codigo ASC
    ");


    if ($stmt) {

        $stmt->bind_param(
            "i",
            $inventario_fisico_id
        );


        $stmt->execute();

        $resultado =
            $stmt->get_result();


        while (
            $fila =
            $resultado->fetch_assoc()
        ) {

            $detalles[] = $fila;

            $resumen['total']++;


            switch ($fila['estado']) {

                case 'CORRECTO':

                    $resumen['correctos']++;

                    break;


                case 'FALTANTE':

                    $resumen['faltantes']++;

                    break;


                case 'SOBRANTE':

                    $resumen['sobrantes']++;

                    break;


                case 'NO_ENCONTRADO':

                    $resumen['no_encontrados']++;

                    break;


                case 'NO_REPORTADO':

                    $resumen['no_reportados']++;

                    break;
            }
        }


        $stmt->close();
    }
}


// ==========================================
// INFORMACIÓN DE LA REVISIÓN
// ==========================================

$revision = null;


if ($inventario_fisico_id > 0) {

    $stmt = $conexion->prepare("
        SELECT *
        FROM inventarios_fisicos
        WHERE id = ?
        LIMIT 1
    ");


    if ($stmt) {

        $stmt->bind_param(
            "i",
            $inventario_fisico_id
        );


        $stmt->execute();

        $resultado =
            $stmt->get_result();

        $revision =
            $resultado->fetch_assoc();

        $stmt->close();
    }
}


// ==========================================
// ESTADO DE LA REVISIÓN
// ==========================================

$revisionFinalizada = false;

if ($revision) {

    $revisionFinalizada =
        (
            $revision['estado'] === 'FINALIZADO' ||
            $revision['estado'] === 'AJUSTADO'
        );
}

?>

<!DOCTYPE html>

<html lang="es">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"

>

<title>Inventario físico</title>

<style>

* {
    box-sizing: border-box;
}


body {

    margin: 0;

    padding: 0;

    font-family: Arial, sans-serif;

    background: #f4f6f8;

    color: #333;
}


.contenido-principal {

    margin-left: 240px;

    min-height: 100vh;
}


.barra-superior {

    height: 70px;

    background: #ffffff;

    border-bottom: 1px solid #ddd;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;
}


.titulo-superior {

    font-size: 20px;

    font-weight: bold;
}


.usuario-superior {

    font-size: 14px;
}


.contenedor {

    width: 95%;

    margin: 25px auto;

    background: #ffffff;

    padding: 25px;

    border-radius: 8px;

    box-shadow: 0 2px 8px rgba(0,0,0,.08);
}


h1 {

    margin-top: 0;

    font-size: 24px;
}


.descripcion {

    color: #666;

    margin-bottom: 25px;
}


/* ==========================================
   ALERTAS
========================================== */

.alerta {

    padding: 12px 15px;

    border-radius: 5px;

    margin-bottom: 20px;
}


.exito {

    background: #dff0d8;

    color: #2e6b2e;
}


.error {

    background: #f8d7da;

    color: #842029;
}


/* ==========================================
   IMPORTAR
========================================== */

.importar {

    border: 2px dashed #bbb;

    padding: 25px;

    text-align: center;

    border-radius: 8px;

    margin-bottom: 25px;

    background: #fafafa;
}


.importar input[type="file"] {

    margin: 15px;
}


/* ==========================================
   BOTONES
========================================== */

.botones-superiores {

    display: flex;

    gap: 10px;

    flex-wrap: wrap;

    margin-bottom: 20px;
}


.boton {

    border: none;

    border-radius: 5px;

    padding: 10px 18px;

    cursor: pointer;

    font-weight: bold;

    font-family: Arial, sans-serif;
}


.boton-principal {

    background: #343a40;

    color: white;
}


.boton-principal:hover {

    background: #23272b;
}


.boton-secundario {

    background: #6c757d;

    color: white;
}


.boton-secundario:hover {

    background: #545b62;
}


.boton-finalizar {

    background: #198754;

    color: white;
}


.boton-finalizar:hover {

    background: #146c43;
}


/* ==========================================
   INFORMACIÓN REVISIÓN
========================================== */

.info-revision {

    background: #f8f9fa;

    padding: 15px;

    border-radius: 6px;

    margin-bottom: 20px;

    border: 1px solid #ddd;

    line-height: 1.7;
}


.estado-revision {

    display: inline-block;

    padding: 5px 10px;

    border-radius: 15px;

    font-size: 12px;

    font-weight: bold;

    margin-left: 5px;
}


.estado-en-revision {

    background: #fff3cd;

    color: #856404;
}


.estado-finalizado {

    background: #d1e7dd;

    color: #0f5132;
}


.estado-ajustado {

    background: #cfe2ff;

    color: #084298;
}


/* ==========================================
   RESUMEN
========================================== */

.resumen {

    display: grid;

    grid-template-columns:
        repeat(6, 1fr);

    gap: 12px;

    margin-bottom: 25px;
}


.tarjeta {

    padding: 15px;

    border-radius: 7px;

    background: #f8f9fa;

    border: 1px solid #ddd;

    text-align: center;
}


.tarjeta strong {

    display: block;

    font-size: 25px;

    margin-top: 5px;
}


/* ==========================================
   TABLA
========================================== */

.tabla-contenedor {

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse: collapse;
}


th {

    background: #343a40;

    color: white;

    padding: 10px;

    text-align: left;

    white-space: nowrap;
}


td {

    padding: 9px;

    border-bottom: 1px solid #ddd;

    vertical-align: middle;
}


tr:hover {

    background: #f8f9fa;
}


/* ==========================================
   CANTIDAD FÍSICA
========================================== */

.input-cantidad {

    width: 90px;

    padding: 8px;

    border: 1px solid #bbb;

    border-radius: 4px;

    font-family: Arial, sans-serif;

    text-align: center;

    font-weight: bold;
}


.input-cantidad:focus {

    outline: none;

    border-color: #343a40;
}


/* ==========================================
   COMENTARIO
========================================== */

.form-detalle {

    display: flex;

    gap: 7px;

    min-width: 300px;

    align-items: flex-start;
}


.form-detalle textarea {

    width: 270px;

    min-height: 62px;

    resize: vertical;

    padding: 7px;

    border: 1px solid #ccc;

    border-radius: 4px;

    font-family: Arial, sans-serif;
}


.form-detalle textarea:focus {

    outline: none;

    border-color: #343a40;
}


/* ==========================================
   ESTADOS
========================================== */

.estado {

    display: inline-block;

    padding: 5px 9px;

    border-radius: 15px;

    font-size: 12px;

    font-weight: bold;

    white-space: nowrap;
}


.correcto {

    background: #dff0d8;

    color: #2e7d32;
}


.faltante {

    background: #f8d7da;

    color: #b71c1c;
}


.sobrante {

    background: #fff3cd;

    color: #856404;
}


.no-encontrado {

    background: #cfe2ff;

    color: #084298;
}


.no-reportado {

    background: #e2e3e5;

    color: #41464b;
}


/* ==========================================
   DIFERENCIA
========================================== */

.diferencia-negativa {

    color: #b71c1c;

    font-weight: bold;
}


.diferencia-positiva {

    color: #856404;

    font-weight: bold;
}


.diferencia-cero {

    color: #2e7d32;

    font-weight: bold;
}


/* ==========================================
   AVISO
========================================== */

.aviso {

    background: #fff3cd;

    color: #664d03;

    border: 1px solid #ffecb5;

    padding: 13px;

    border-radius: 6px;

    margin-bottom: 20px;

    font-size: 14px;
}


/* ==========================================
   SIN DATOS
========================================== */

.sin-datos {

    text-align: center;

    padding: 35px;

    color: #777;
}


/* ==========================================
   RESPONSIVE
========================================== */

@media (max-width: 1200px) {

    .resumen {

        grid-template-columns:
            repeat(3, 1fr);
    }

}


@media (max-width: 650px) {

    .contenido-principal {

        margin-left: 0;
    }


    .barra-superior {

        height: auto;

        padding: 15px;

        flex-direction: column;

        align-items: flex-start;

        gap: 8px;
    }


    .contenedor {

        width: 94%;

        padding: 15px;
    }


    .resumen {

        grid-template-columns:
            1fr 1fr;
    }

}

</style>

</head>

<body>

<!-- ==========================================
     MENÚ LATERAL
========================================== -->

<?php include 'menu.php'; ?>

<!-- ==========================================
     CONTENIDO
========================================== -->

<main class="contenido-principal">

<header class="barra-superior">

<div class="titulo-superior">

    📋 Inventario físico

</div>


<div class="usuario-superior">

    Usuario:

    <strong>

        <?= h($nombre_empleado) ?>

    </strong>

</div>

</header>

<div class="contenedor">

<h1>

📋 Comparación de inventario físico

</h1>

<p class="descripcion">

Importa el archivo Excel del conteo físico para
compararlo contra las existencias registradas en el sistema.

</p>

<!-- ==========================================
     MENSAJES
========================================== -->

<?php if ($mensaje !== ""): ?>

<div class="alerta exito">

✓ <?= h($mensaje) ?>

</div>

<?php endif; ?>

<?php if ($error !== ""): ?>

<div class="alerta error">

❌ <?= h($error) ?>

</div>

<?php endif; ?>

<!-- ==========================================
     SIN REVISIÓN
========================================== -->

<?php if ($inventario_fisico_id <= 0): ?>

<div class="importar">

<h2>

    📥 Importar inventario físico

</h2>


<p>

    Selecciona el mismo archivo Excel que
    utilizas para exportar tu inventario.

</p>


<form
    method="POST"
    action="importar_inventario_fisico.php"
    enctype="multipart/form-data"
>

    <input
        type="file"
        name="archivo_excel"
        accept=".xlsx,.xls"
        required
    >


    <br>


    <button
        type="submit"
        class="boton boton-principal"
    >

        📥 Importar y comparar

    </button>

</form>


<p style="
    font-size:13px;
    color:#777;
    margin-top:15px;
">

    El sistema utilizará la columna
    <strong>Cantidad</strong>
    del Excel como la cantidad física encontrada.

</p>

</div>

<?php else: ?>

<!-- ==========================================
     INFORMACIÓN DE LA REVISIÓN
========================================== -->

<?php if ($revision): ?>

<div class="info-revision">

<strong>
    Revisión #<?= intval($revision['id']) ?>
</strong>

&nbsp; | &nbsp;

Fecha:

<?= h($revision['fecha_revision']) ?>

&nbsp; | &nbsp;

Archivo:

<?= h($revision['archivo_nombre'] ?? '') ?>

&nbsp; | &nbsp;

Estado:

<?php

if ($revision['estado'] === 'EN_REVISION') {

    echo '<span class="estado-revision estado-en-revision">
            EN REVISIÓN
          </span>';

} elseif ($revision['estado'] === 'FINALIZADO') {

    echo '<span class="estado-revision estado-finalizado">
            FINALIZADO
          </span>';

} elseif ($revision['estado'] === 'AJUSTADO') {

    echo '<span class="estado-revision estado-ajustado">
            AJUSTADO
          </span>';
}

?>

</div>

<?php endif; ?>

<!-- ==========================================
     AVISO
========================================== -->

<?php if (!$revisionFinalizada): ?>

<div class="aviso">

<strong>Importante:</strong>

La columna <strong>Físico</strong> es editable.
Captura ahí la cantidad realmente encontrada
durante el conteo.

El sistema calculará automáticamente la
diferencia y el estado del artículo.

<br><br>

<strong>
    Esta pantalla NO modifica todavía el inventario.
</strong>

</div>

<?php else: ?>

<div class="aviso">

<strong>Revisión finalizada.</strong>

Los datos ya no deben modificarse en esta etapa.
El siguiente paso será revisar y aplicar,
si corresponde, los ajustes autorizados.

</div>

<?php endif; ?>

<!-- ==========================================
     RESUMEN
========================================== -->

<div class="resumen">

<div class="tarjeta">

Artículos

<strong>

    <?= $resumen['total'] ?>

</strong>

</div>

<div class="tarjeta">

Correctos

<strong>

    <?= $resumen['correctos'] ?>

</strong>

</div>

<div class="tarjeta">

Faltantes

<strong>

    <?= $resumen['faltantes'] ?>

</strong>

</div>

<div class="tarjeta">

Sobrantes

<strong>

    <?= $resumen['sobrantes'] ?>

</strong>

</div>

<div class="tarjeta">

No registrados

<strong>

    <?= $resumen['no_encontrados'] ?>

</strong>

</div>

<div class="tarjeta">

No reportados

<strong>

    <?= $resumen['no_reportados'] ?>

</strong>

</div>

</div>

<!-- ==========================================
     BOTONES
========================================== -->

<div class="botones-superiores">

<?php if (!$revisionFinalizada): ?>

<form
    method="POST"
    action="inventario_fisico.php"
    id="formGuardarTodos"
    style="display:inline;"
>

<input
    type="hidden"
    name="accion"
    value="guardar_todos"
>

</form>

<button
type="submit"
form="formGuardarTodos"
class="boton boton-principal"

>

💾 Guardar todos

</button>

<form
    method="POST"
    action="inventario_fisico.php"
    style="display:inline;"
    onsubmit="
        return confirm(
            '¿Deseas finalizar esta revisión? Después de finalizarla ya no se deberán modificar sus cantidades.'
        );
    "
>

<input
    type="hidden"
    name="accion"
    value="finalizar_revision"
>


<button
    type="submit"
    class="boton boton-finalizar"
>

    ✓ Finalizar revisión

</button>

</form>

<?php endif; ?>

<form
    method="POST"
    action="inventario_fisico.php"
    style="display:inline;"
    onsubmit="
        return confirm(
            '¿Deseas iniciar una nueva revisión? La revisión actual permanecerá guardada.'
        );
    "
>

<input
    type="hidden"
    name="accion"
    value="nueva_revision"
>


<button
    type="submit"
    class="boton boton-secundario"
>

    🔄 Nueva revisión

</button>

</form>

</div>

<!-- ==========================================
     TABLA
========================================== -->

<div class="tabla-contenedor">

<?php if (empty($detalles)): ?>

<table>

<thead>

<tr>

<th>
    Código
</th>

<th>
    Artículo
</th>

<th>
    Sistema
</th>

<th>
    Físico
</th>

<th>
    Diferencia
</th>

<th>
    Estado
</th>

<th>
    Comentario / motivo
</th>

</tr>

</thead>

<tbody>

<tr>

<td
    colspan="7"
    class="sin-datos"
>

No existen registros
en esta revisión.

</td>

</tr>

</tbody>

</table>

<?php else: ?>

<!-- ==========================================
     FORMULARIO VÁLIDO PARA TODA LA TABLA
========================================== -->

<form
    method="POST"
    action="inventario_fisico.php"
    id="formDatosTabla"
>

<input
type="hidden"
name="accion"
value="guardar_todos"

>

<table>

<thead>

<tr>

<th>
    Código
</th>

<th>
    Artículo
</th>

<th>
    Sistema
</th>

<th>
    Físico
</th>

<th>
    Diferencia
</th>

<th>
    Estado
</th>

<th>
    Comentario / motivo
</th>


</tr>

</thead>

<tbody>

<?php foreach ($detalles as $fila): ?>

<?php

$detalleId =
    intval($fila['id']);

$cantidadSistema =
    (float)$fila['cantidad_sistema'];

$cantidadFisica =
    $fila['cantidad_fisica'];

$diferencia =
    $fila['diferencia'];

$estado =
    $fila['estado'];

$esNoEncontrado =
    ($estado === 'NO_ENCONTRADO');

?>

<tr>

<!-- ======================================
     CÓDIGO
====================================== -->

<td>

<strong>

    <?= h($fila['codigo']) ?>

</strong>

</td>

<!-- ======================================
     ARTÍCULO
====================================== -->

<td>

<?= h(
    $fila['articulo_descripcion'] ?? ''
) ?>

</td>

<!-- ======================================
     SISTEMA
====================================== -->

<td>

<?= number_format(
    $cantidadSistema,
    2
) ?>

</td>

<!-- ======================================
     FÍSICO
====================================== -->

<td>

<?php if ($revisionFinalizada): ?>

<?php if ($cantidadFisica !== null): ?>

    <?= number_format(
        (float)$cantidadFisica,
        2
    ) ?>

<?php else: ?>

    —

<?php endif; ?>

<?php else: ?>

<input
    type="number"
    step="0.01"
    min="0"
    class="input-cantidad"
    name="detalles[<?= $detalleId ?>][cantidad_fisica]"
    value="<?=
        $cantidadFisica !== null
        ? h($cantidadFisica)
        : ''
    ?>"
    title="Cantidad física encontrada"
>

<?php endif; ?>

</td>

<!-- ======================================
     DIFERENCIA
====================================== -->

<td>

<?php if ($diferencia === null): ?>

<span style="color:#777;">
    —
</span>

<?php else: ?>

<?php

$diferenciaFloat =
    (float)$diferencia;


if ($diferenciaFloat < 0) {

    echo '<span class="diferencia-negativa">';

    echo number_format(
        $diferenciaFloat,
        2
    );

    echo '</span>';

} elseif ($diferenciaFloat > 0) {

    echo '<span class="diferencia-positiva">';

    echo '+';

    echo number_format(
        $diferenciaFloat,
        2
    );

    echo '</span>';

} else {

    echo '<span class="diferencia-cero">';

    echo '0.00';

    echo '</span>';
}

?>

<?php endif; ?>

</td>

<!-- ======================================
     ESTADO
====================================== -->

<td>

<?php

switch ($estado) {

    case 'CORRECTO':

        echo '<span class="estado correcto">
                ✓ Correcto
              </span>';

        break;


    case 'FALTANTE':

        echo '<span class="estado faltante">
                ⚠ Faltante
              </span>';

        break;


    case 'SOBRANTE':

        echo '<span class="estado sobrante">
                ⚠ Sobrante
              </span>';

        break;


    case 'NO_ENCONTRADO':

        echo '<span class="estado no-encontrado">
                ⚠ No registrado
              </span>';

        break;


    case 'NO_REPORTADO':

        echo '<span class="estado no-reportado">
                ⚠ No reportado
              </span>';

        break;


    default:

        echo '<span class="estado no-reportado">
                Sin determinar
              </span>';

        break;
}

?>

</td>

<!-- ======================================
     COMENTARIO
====================================== -->

<td>

<?php if ($revisionFinalizada): ?>

<?php if (
    trim(
        (string)(
            $fila['comentario'] ?? ''
        )
    ) !== ''
): ?>

    <?= nl2br(
        h($fila['comentario'])
    ) ?>

<?php else: ?>

    <span style="color:#999;">
        Sin comentario
    </span>

<?php endif; ?>

<?php else: ?>

<div class="form-detalle">

    <textarea
        name="detalles[<?= $detalleId ?>][comentario]"
        placeholder="Escribe el motivo de la diferencia..."
    ><?= h(
        $fila['comentario'] ?? ''
    ) ?></textarea>

</div>

<?php endif; ?>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</form>

<?php endif; ?>

</div>

<?php endif; ?>

</div>

</main>

</body>

</html>
