<?php

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/seguridad.php';

verificar_sesion();

$nombre_empleado = $_SESSION['nombre_empleado'] ?? 'Usuario';

// =====================================================
// BUSCADOR
// =====================================================

$buscar = trim($_GET["buscar"] ?? "");

if ($buscar !== "") {

    $sql = "
        SELECT
            id,
            rfc_emisor,
            nombre_emisor,
            rfc_receptor,
            nombre_receptor,
            numero_factura,
            fecha_factura,
            subtotal,
            iva,
            total,
            fecha_registro
        FROM facturas
        WHERE
            rfc_emisor LIKE ?
            OR nombre_emisor LIKE ?
            OR numero_factura LIKE ?
        ORDER BY id DESC
    ";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        die("Error en la consulta: " . $conexion->error);
    }

    $texto = "%" . $buscar . "%";

    $stmt->bind_param(
        "sss",
        $texto,
        $texto,
        $texto
    );

    $stmt->execute();

    $facturas = $stmt->get_result();

} else {

    $sql = "
        SELECT
            id,
            rfc_emisor,
            nombre_emisor,
            rfc_receptor,
            nombre_receptor,
            numero_factura,
            fecha_factura,
            subtotal,
            iva,
            total,
            fecha_registro
        FROM facturas
        ORDER BY id DESC
    ";

    $facturas = $conexion->query($sql);

    if (!$facturas) {
        die("Error en la consulta: " . $conexion->error);
    }
}

?>

<?php include 'menu.php'; ?>

<main class="contenido-principal">

<!-- =====================================================
     ENCABEZADO
====================================================== -->

<header class="barra-superior">

    <div class="titulo-superior">
        📄 Facturas
    </div>

    <div class="usuario-superior">

        Usuario:
        <strong>
            <?= htmlspecialchars($nombre_empleado) ?>
        </strong>

    </div>

</header>


<div class="pagina-contenido">


    <!-- =====================================================
         TÍTULO
    ====================================================== -->

    <div class="encabezado-pagina">

        <div>

            <h1>📄 Facturas</h1>

            <p>
                Consulta y búsqueda de facturas registradas
                en el sistema.
            </p>

        </div>

    </div>


    <!-- =====================================================
         CONTENEDOR PRINCIPAL
    ====================================================== -->

    <div class="contenedor-facturas">


        <!-- =================================================
             BUSCADOR
        ================================================== -->

        <div class="titulo-seccion">

            🔎 Buscar factura

        </div>


        <form
            method="GET"
            class="barra-busqueda"
        >

            <input
                type="text"
                name="buscar"
                value="<?= htmlspecialchars($buscar) ?>"
                placeholder="Buscar por RFC, proveedor o número de factura"
            >


            <button
                type="submit"
                class="boton buscar"
            >

                🔎 Buscar

            </button>


            <a
                href="facturas.php"
                class="boton limpiar"
            >

                🔄 Limpiar

            </a>

        </form>


        <!-- =================================================
             RESULTADOS
        ================================================== -->

        <div class="encabezado-resultados">

            <div>

                <strong>
                    Facturas registradas
                </strong>

            </div>

            <div class="contador">

                <?= ($facturas) ? $facturas->num_rows : 0 ?>

                resultado(s)

            </div>

        </div>


        <!-- =================================================
             TABLA
        ================================================== -->

        <div class="tabla-contenedor">

            <?php if ($facturas && $facturas->num_rows > 0): ?>


                <table>

                    <thead>

                        <tr>

                            <th>ID</th>

                            <th>Fecha</th>

                            <th>Factura / Folio</th>

                            <th>RFC Emisor</th>

                            <th>Proveedor</th>

                            <th>RFC Receptor</th>

                            <th>Subtotal</th>

                            <th>IVA</th>

                            <th>Total</th>

                            <th>Acción</th>

                        </tr>

                    </thead>


                    <tbody>


                    <?php while ($factura = $facturas->fetch_assoc()): ?>


                        <tr>


                            <!-- ID -->

                            <td>

                                <span class="id-factura">

                                    #<?= (int)$factura["id"] ?>

                                </span>

                            </td>


                            <!-- FECHA -->

                            <td>

                                <?= htmlspecialchars(
                                    $factura["fecha_factura"] ?? ""
                                ) ?>

                            </td>


                            <!-- NUMERO FACTURA -->

                            <td>

                                <strong class="folio-factura">

                                    <?= htmlspecialchars(
                                        $factura["numero_factura"] ?? ""
                                    ) ?>

                                </strong>

                            </td>


                            <!-- RFC EMISOR -->

                            <td>

                                <?= htmlspecialchars(
                                    $factura["rfc_emisor"] ?? ""
                                ) ?>

                            </td>


                            <!-- PROVEEDOR -->

                            <td>

                                <strong>

                                    <?= htmlspecialchars(
                                        $factura["nombre_emisor"] ?? ""
                                    ) ?>

                                </strong>

                            </td>


                            <!-- RFC RECEPTOR -->

                            <td>

                                <?= htmlspecialchars(
                                    $factura["rfc_receptor"] ?? ""
                                ) ?>

                            </td>


                            <!-- SUBTOTAL -->

                            <td class="importe">

                                $<?= number_format(
                                    (float)$factura["subtotal"],
                                    2
                                ) ?>

                            </td>


                            <!-- IVA -->

                            <td class="importe">

                                $<?= number_format(
                                    (float)$factura["iva"],
                                    2
                                ) ?>

                            </td>


                            <!-- TOTAL -->

                            <td class="total">

                                $<?= number_format(
                                    (float)$factura["total"],
                                    2
                                ) ?>

                            </td>


                            <!-- ACCIÓN -->

                            <td>

                                <a
                                    href="detalle_factura.php?id=<?= (int)$factura["id"] ?>"
                                    class="boton ver"
                                >

                                    👁️ Ver

                                </a>

                            </td>


                        </tr>


                    <?php endwhile; ?>


                    </tbody>

                </table>


            <?php else: ?>


                <div class="sin-resultados">

                    <div class="icono-sin-resultados">
                        📭
                    </div>

                    <strong>
                        No se encontraron facturas
                    </strong>

                    <p>

                        <?php if ($buscar !== ""): ?>

                            No existen facturas que coincidan
                            con la búsqueda
                            <strong>
                                "<?= htmlspecialchars($buscar) ?>"
                            </strong>.

                        <?php else: ?>

                            Aún no hay facturas registradas
                            en el sistema.

                        <?php endif; ?>

                    </p>

                </div>


            <?php endif; ?>

        </div>


    </div>

</div>

</main>

<style>

/* =========================================================
   FACTURAS
========================================================= */

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6f9;
}


/* =========================================================
   ESPACIO PARA EL MENÚ LATERAL
========================================================= */

.contenido-principal {

    margin-left: 240px;

    width: calc(100% - 240px);

    min-height: 100vh;

}


/* =========================================================
   CONTENIDO DE LA PÁGINA
========================================================= */

.pagina-contenido {

    padding: 25px;

}


/* =========================================================
   CONTENIDO
========================================================= */

.pagina-contenido {
    padding: 25px;
}


/* =========================================================
   ENCABEZADO
========================================================= */

.encabezado-pagina {
    margin-bottom: 20px;
}

.encabezado-pagina h1 {
    margin: 0 0 6px 0;
    font-size: 28px;
    color: #212529;
}

.encabezado-pagina p {
    margin: 0;
    color: #6c757d;
    font-size: 14px;
}


/* =========================================================
   CONTENEDOR
========================================================= */

.contenedor-facturas {

    background: white;

    padding: 25px;

    border-radius: 10px;

    box-shadow:
        0 2px 10px rgba(0,0,0,.10);

}


/* =========================================================
   TÍTULO DE SECCIÓN
========================================================= */

.titulo-seccion {

    font-size: 18px;

    font-weight: bold;

    color: #212529;

    margin-bottom: 15px;

}


/* =========================================================
   BARRA DE BÚSQUEDA
========================================================= */

.barra-busqueda {

    display: flex;

    gap: 10px;

    margin-bottom: 25px;

    flex-wrap: wrap;

}


.barra-busqueda input {

    flex: 1;

    min-width: 250px;

    padding: 11px 12px;

    border: 1px solid #ccc;

    border-radius: 5px;

    font-family: Arial, sans-serif;

    font-size: 14px;

}


.barra-busqueda input:focus {

    outline: none;

    border-color: #0d6efd;

    box-shadow:
        0 0 0 2px rgba(13,110,253,.10);

}


/* =========================================================
   BOTONES
========================================================= */

.boton {

    display: inline-block;

    padding: 10px 15px;

    border: none;

    border-radius: 5px;

    text-decoration: none;

    cursor: pointer;

    font-family: Arial, sans-serif;

    font-size: 14px;

    white-space: nowrap;

}


.buscar {

    background: #0d6efd;

    color: white;

}


.buscar:hover {

    background: #0b5ed7;

}


.limpiar {

    background: #6c757d;

    color: white;

}


.limpiar:hover {

    background: #5c636a;

}


.ver {

    background: #198754;

    color: white;

}


.ver:hover {

    background: #157347;

}


/* =========================================================
   ENCABEZADO DE RESULTADOS
========================================================= */

.encabezado-resultados {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 12px;

    padding-bottom: 10px;

    border-bottom: 1px solid #e5e5e5;

}


.contador {

    font-size: 13px;

    color: #6c757d;

}


/* =========================================================
   TABLA
========================================================= */

.tabla-contenedor {

    overflow-x: auto;

}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 1100px;

}


th {

    background: #212529;

    color: white;

    padding: 12px;

    text-align: left;

    font-size: 13px;

    white-space: nowrap;

}


td {

    padding: 10px;

    border-bottom: 1px solid #ddd;

    font-size: 13px;

    vertical-align: middle;

}


tr:hover {

    background: #f5f5f5;

}


/* =========================================================
   DATOS DESTACADOS
========================================================= */

.id-factura {

    color: #6c757d;

    font-weight: bold;

}


.folio-factura {

    color: #0d6efd;

}


.importe {

    white-space: nowrap;

}


.total {

    font-weight: bold;

    color: #198754;

    white-space: nowrap;

}


/* =========================================================
   SIN RESULTADOS
========================================================= */

.sin-resultados {

    text-align: center;

    padding: 60px 20px;

    color: #777;

}


.icono-sin-resultados {

    font-size: 42px;

    margin-bottom: 10px;

}


.sin-resultados strong {

    color: #495057;

}


.sin-resultados p {

    margin-top: 8px;

    font-size: 14px;

}


/* =========================================================
   RESPONSIVE
========================================================= */


@media (max-width: 850px) {

    .contenido-principal {

        margin-left: 210px;

        width: calc(100% - 210px);

    }


    .pagina-contenido {

        padding: 15px;

    }

}


@media (max-width: 650px) {

    .contenido-principal {

        margin-left: 0;

        width: 100%;

    }


    .encabezado-resultados {

        flex-direction: column;

        align-items: flex-start;

        gap: 5px;

    }


    .barra-busqueda {

        flex-direction: column;

    }


    .barra-busqueda input {

        width: 100%;

        min-width: 0;

    }


    .boton {

        text-align: center;

    }

}